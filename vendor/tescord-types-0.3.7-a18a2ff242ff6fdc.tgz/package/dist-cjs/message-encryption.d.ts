export interface MessageDeviceIdentity {
    userId: string;
    deviceId: string;
    signingPublicKey: string;
    agreementPublicKey: string;
    fingerprint: string;
}
export type SignedMessageContext = {
    purpose: "edit";
    messageId: string;
    revision: number;
} | {
    purpose: "interaction" | "ephemeral";
    interactionId: string;
    commandId: string;
    botId: string;
    callerId: string;
    revision: number;
    ephemeral: boolean;
};
export interface SecureMessageEnvelope {
    context?: SignedMessageContext;
    version: 2;
    channelId: string;
    senderId: string;
    senderDeviceId: string;
    messageId: string;
    senderSigningPublicKey: string;
    senderAgreementPublicKey: string;
    fingerprint: string;
    iv: string;
    ciphertext: string;
    recipients: Array<{
        userId: string;
        deviceId: string;
        fingerprint: string;
        ephemeralPublicKey: string;
        iv: string;
        ciphertext: string;
    }>;
    signature: string;
}
export declare function messageDeviceFingerprint(signingPublicKey: string, agreementPublicKey: string): Promise<string>;
export declare function getValidatedDeviceKeys(device: MessageDeviceIdentity): Promise<{
    verifyKey: CryptoKey;
    agreementPublicKey: CryptoKey;
}>;
export declare function validateMessageDevice(device: MessageDeviceIdentity): Promise<void>;
export declare function validateSecureMessageEnvelope(value: unknown): asserts value is SecureMessageEnvelope;
export declare function encryptSecureMessage(channelId: string, plaintext: string, sender: MessageDeviceIdentity, signingPrivateKey: CryptoKey, recipients: MessageDeviceIdentity[], context?: SignedMessageContext): Promise<SecureMessageEnvelope>;
export declare function verifySecureMessageSignature(envelope: SecureMessageEnvelope, expectedSender: MessageDeviceIdentity): Promise<void>;
export declare function decryptSecureMessage(envelope: SecureMessageEnvelope, channelId: string, local: MessageDeviceIdentity, agreementPrivateKey: CryptoKey, expectedSender: MessageDeviceIdentity): Promise<string>;
export declare function unwrapSecureMessageKey(envelope: SecureMessageEnvelope, channelId: string, local: MessageDeviceIdentity, agreementPrivateKey: CryptoKey, expectedSender: MessageDeviceIdentity): Promise<Uint8Array>;
export declare function decryptSecureMessageWithKey(envelope: SecureMessageEnvelope, channelId: string, keyBytes: Uint8Array, expectedSender: MessageDeviceIdentity): Promise<string>;
//# sourceMappingURL=message-encryption.d.ts.map