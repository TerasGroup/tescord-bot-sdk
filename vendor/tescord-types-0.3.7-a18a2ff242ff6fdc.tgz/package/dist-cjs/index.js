"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.STORAGE_IPC_CHANNELS = exports.MAX_ENCRYPTED_ENVELOPE_LENGTH = exports.MAX_MESSAGE_CONTENT_LENGTH = exports.ErrorCode = exports.SUPPORTED_LOCALES = exports.ClientSideFtsEngine = exports.DoubleRatchetSession = exports.SFrameReplayFilter = exports.DEFAULT_USER_NOTIFICATION_SETTINGS = exports.SCREEN_SHARE_PRESETS = exports.FPS_OPTIONS = exports.RESOLUTION_OPTIONS = exports.P2PErrorCode = exports.P2P_IPC_CHANNELS = exports.VoiceChannelEventType = exports.GatewayEvents = exports.GUILD_MUTE_DURATION_OPTIONS = exports.CHANNEL_MUTE_DURATION_OPTIONS = exports.MAX_CUSTOM_BITRATE = exports.MIN_CUSTOM_BITRATE = exports.DEFAULT_VIDEO_CODEC = exports.GatewayCloseCode = exports.GatewayOpCode = exports.AuditLogAction = exports.CHANNEL_CATEGORY_PERMISSIONS = exports.CHANNEL_VOICE_PERMISSIONS = exports.CHANNEL_TEXT_PERMISSIONS = exports.ALL_PERMISSIONS = exports.PermissionFlags = void 0;
exports.calcVagueTime = calcVagueTime;
exports.isSelfDeleteAccountDTO = isSelfDeleteAccountDTO;
exports.isCancelDeletionDTO = isCancelDeletionDTO;
exports.hasPermission = hasPermission;
exports.computePermissions = computePermissions;
exports.parseRoleIds = parseRoleIds;
exports.computeEffectivePermissions = computeEffectivePermissions;
exports.isMessageEmbed = isMessageEmbed;
exports.isChannelMuted = isChannelMuted;
exports.isGuildMuted = isGuildMuted;
exports.clampVolume = clampVolume;
exports.computeGain = computeGain;
exports.evaluateNetworkQuality = evaluateNetworkQuality;
exports.calculateSNRReduction = calculateSNRReduction;
exports.calculateTripleSNRReduction = calculateTripleSNRReduction;
exports.calculateQuadSNRReduction = calculateQuadSNRReduction;
exports.getRecommendedBitrate = getRecommendedBitrate;
exports.getMaxAllowed16x9Resolution = getMaxAllowed16x9Resolution;
exports.isResolutionAllowed = isResolutionAllowed;
exports.computeSimulcastLayers = computeSimulcastLayers;
exports.bytesToBase64 = bytesToBase64;
exports.base64ToBytes = base64ToBytes;
exports.bytesToHex = bytesToHex;
exports.hexToBytes = hexToBytes;
exports.buildSecurityHeaders = buildSecurityHeaders;
exports.validateDtlsSrtpParameters = validateDtlsSrtpParameters;
exports.encodeSFrameHeader = encodeSFrameHeader;
exports.decodeSFrameHeader = decodeSFrameHeader;
exports.deriveSFrameKey = deriveSFrameKey;
exports.encryptSFramePacket = encryptSFramePacket;
exports.decryptSFramePacket = decryptSFramePacket;
exports.generateDhKeyPair = generateDhKeyPair;
exports.exportDhPublicKey = exportDhPublicKey;
exports.importDhPublicKey = importDhPublicKey;
exports.computeDhSecret = computeDhSecret;
exports.kdfRootKey = kdfRootKey;
exports.kdfChainKey = kdfChainKey;
exports.computeFingerprint = computeFingerprint;
exports.computeSafetyNumber = computeSafetyNumber;
exports.encryptMessageWithKey = encryptMessageWithKey;
exports.decryptMessageWithKey = decryptMessageWithKey;
exports.tokenizeText = tokenizeText;
exports.isAdminUpdateUserDTO = isAdminUpdateUserDTO;
exports.parseTrustedDomains = parseTrustedDomains;
exports.isAdminEditUserProfileDTO = isAdminEditUserProfileDTO;
exports.isAdminSoftDeleteUserDTO = isAdminSoftDeleteUserDTO;
exports.isAdminDataPruneDTO = isAdminDataPruneDTO;
exports.isStorageClearOptions = isStorageClearOptions;
// ==========================================
// Tescord 统一协议与核心数据类型定义 (Contracts)
// ==========================================
__exportStar(require("./message-encryption.js"), exports);
__exportStar(require("./history-recovery.js"), exports);
__exportStar(require("./bot.js"), exports);
__exportStar(require("./interactions.js"), exports);
const interactions_js_1 = require("./interactions.js");
function calcVagueTime(date, nowMs = Date.now()) {
    if (!date)
        return undefined;
    const timeMs = typeof date === "number" ? date : new Date(date).getTime();
    if (Number.isNaN(timeMs))
        return undefined;
    const diffMs = Math.max(0, nowMs - timeMs);
    const diffSec = Math.floor(diffMs / 1000);
    if (diffSec < 60) {
        return { unit: "just_now" };
    }
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) {
        return { unit: "minute", value: diffMin };
    }
    const diffHour = Math.floor(diffMin / 60);
    if (diffHour < 24) {
        return { unit: "hour", value: diffHour };
    }
    const diffDay = Math.floor(diffHour / 24);
    if (diffDay < 30) {
        return { unit: "day", value: diffDay };
    }
    const diffMonth = Math.floor(diffDay / 30);
    if (diffMonth < 12) {
        return { unit: "month", value: diffMonth };
    }
    const diffYear = Math.floor(diffDay / 365);
    return { unit: "year", value: Math.max(1, diffYear) };
}
function isSelfDeleteAccountDTO(value) {
    return ((0, interactions_js_1.isRecord)(value) &&
        typeof value.password === "string" &&
        value.password.length > 0 &&
        value.password.length <= 1024);
}
function isCancelDeletionDTO(value) {
    return (isSelfDeleteAccountDTO(value) &&
        "emailOrUsername" in value &&
        typeof value.emailOrUsername === "string" &&
        value.emailOrUsername.trim().length > 0 &&
        value.emailOrUsername.length <= 320);
}
// 2. 位掩码权限体系与角色 (Bitwise Permissions & Roles)
var PermissionFlags;
(function (PermissionFlags) {
    PermissionFlags[PermissionFlags["CREATE_INVITE"] = 1] = "CREATE_INVITE";
    PermissionFlags[PermissionFlags["KICK_MEMBERS"] = 2] = "KICK_MEMBERS";
    PermissionFlags[PermissionFlags["BAN_MEMBERS"] = 4] = "BAN_MEMBERS";
    PermissionFlags[PermissionFlags["ADMINISTRATOR"] = 8] = "ADMINISTRATOR";
    PermissionFlags[PermissionFlags["MANAGE_CHANNELS"] = 16] = "MANAGE_CHANNELS";
    PermissionFlags[PermissionFlags["MANAGE_GUILD"] = 32] = "MANAGE_GUILD";
    PermissionFlags[PermissionFlags["ADD_REACTIONS"] = 64] = "ADD_REACTIONS";
    PermissionFlags[PermissionFlags["VIEW_AUDIT_LOG"] = 128] = "VIEW_AUDIT_LOG";
    PermissionFlags[PermissionFlags["VIEW_CHANNEL"] = 1024] = "VIEW_CHANNEL";
    PermissionFlags[PermissionFlags["SEND_MESSAGES"] = 2048] = "SEND_MESSAGES";
    PermissionFlags[PermissionFlags["MANAGE_MESSAGES"] = 8192] = "MANAGE_MESSAGES";
    PermissionFlags[PermissionFlags["ATTACH_FILES"] = 32768] = "ATTACH_FILES";
    PermissionFlags[PermissionFlags["READ_MESSAGE_HISTORY"] = 65536] = "READ_MESSAGE_HISTORY";
    PermissionFlags[PermissionFlags["CONNECT"] = 1048576] = "CONNECT";
    PermissionFlags[PermissionFlags["SPEAK"] = 2097152] = "SPEAK";
    PermissionFlags[PermissionFlags["MUTE_MEMBERS"] = 4194304] = "MUTE_MEMBERS";
    PermissionFlags[PermissionFlags["DEAFEN_MEMBERS"] = 8388608] = "DEAFEN_MEMBERS";
    PermissionFlags[PermissionFlags["MOVE_MEMBERS"] = 16777216] = "MOVE_MEMBERS";
    PermissionFlags[PermissionFlags["STREAM"] = 33554432] = "STREAM";
    PermissionFlags[PermissionFlags["MANAGE_ROLES"] = 67108864] = "MANAGE_ROLES";
    PermissionFlags[PermissionFlags["CHANGE_NICKNAME"] = 134217728] = "CHANGE_NICKNAME";
    PermissionFlags[PermissionFlags["MANAGE_NICKNAMES"] = 268435456] = "MANAGE_NICKNAMES";
})(PermissionFlags || (exports.PermissionFlags = PermissionFlags = {}));
exports.ALL_PERMISSIONS = [
    // 通用管理
    {
        flag: PermissionFlags.VIEW_AUDIT_LOG,
        name: "查看审计日志",
        description: "允许成员查看服务器管理操作的记录流水。",
        category: "GENERAL",
    },
    {
        flag: PermissionFlags.MANAGE_GUILD,
        name: "管理服务器",
        description: "允许成员修改服务器名称、更换图标和全局设置。",
        category: "GENERAL",
    },
    {
        flag: PermissionFlags.MANAGE_ROLES,
        name: "管理角色",
        description: "允许成员创建新角色并编辑低于此职级的角色与权限。",
        category: "GENERAL",
    },
    {
        flag: PermissionFlags.MANAGE_CHANNELS,
        name: "管理频道",
        description: "允许成员创建、编辑或删除频道与分类。",
        category: "GENERAL",
    },
    // 成员处置与邀请
    {
        flag: PermissionFlags.KICK_MEMBERS,
        name: "踢出成员",
        description: "允许成员将低于此职级的成员移出此服务器。",
        category: "MEMBERSHIP",
    },
    {
        flag: PermissionFlags.BAN_MEMBERS,
        name: "封禁成员",
        description: "允许成员将低于此职级的成员永久封禁并列入黑名单。",
        category: "MEMBERSHIP",
    },
    {
        flag: PermissionFlags.CREATE_INVITE,
        name: "创建邀请",
        description: "允许成员创建服务器邀请码邀请新用户加入。",
        category: "MEMBERSHIP",
    },
    {
        flag: PermissionFlags.CHANGE_NICKNAME,
        name: "修改昵称",
        description: "允许成员修改自己在服务器内的专属昵称。",
        category: "MEMBERSHIP",
    },
    {
        flag: PermissionFlags.MANAGE_NICKNAMES,
        name: "管理昵称",
        description: "允许成员修改其他成员的昵称。",
        category: "MEMBERSHIP",
    },
    // 文本频道权限
    {
        flag: PermissionFlags.VIEW_CHANNEL,
        name: "查看频道",
        description: "允许成员查看频道列表并阅读文本频道内容。",
        category: "TEXT",
    },
    {
        flag: PermissionFlags.SEND_MESSAGES,
        name: "发送消息",
        description: "允许成员在文字频道中发送消息。",
        category: "TEXT",
    },
    {
        flag: PermissionFlags.ATTACH_FILES,
        name: "发送附件",
        description: "允许成员在文字频道中上传图片、文件或媒体附件。",
        category: "TEXT",
    },
    {
        flag: PermissionFlags.ADD_REACTIONS,
        name: "添加反应",
        description: "允许成员在已有消息上添加表情反应。",
        category: "TEXT",
    },
    {
        flag: PermissionFlags.READ_MESSAGE_HISTORY,
        name: "阅读历史消息",
        description: "允许成员查看频道过去的聊天记录。",
        category: "TEXT",
    },
    {
        flag: PermissionFlags.MANAGE_MESSAGES,
        name: "管理消息",
        description: "允许成员删除或置顶其他成员发送的消息。",
        category: "TEXT",
    },
    // 语音频道权限
    {
        flag: PermissionFlags.CONNECT,
        name: "连接语音",
        description: "允许成员加入并收听语音频道。",
        category: "VOICE",
    },
    {
        flag: PermissionFlags.SPEAK,
        name: "说话开麦",
        description: "允许成员在语音频道中自由开麦发言。",
        category: "VOICE",
    },
    {
        flag: PermissionFlags.STREAM,
        name: "屏幕共享",
        description: "允许成员在语音频道中分享屏幕或摄像头视频流。",
        category: "VOICE",
    },
    {
        flag: PermissionFlags.MUTE_MEMBERS,
        name: "禁言闭麦成员",
        description: "允许成员在语音频道中静音闭麦其他成员。",
        category: "VOICE",
    },
    {
        flag: PermissionFlags.DEAFEN_MEMBERS,
        name: "禁听成员",
        description: "允许成员在语音频道中抑制其他成员的收听状态。",
        category: "VOICE",
    },
    {
        flag: PermissionFlags.MOVE_MEMBERS,
        name: "移动成员",
        description: "允许成员在不同语音频道之间拖拽转移成员。",
        category: "VOICE",
    },
    // 高级管理
    {
        flag: PermissionFlags.ADMINISTRATOR,
        name: "管理员 (最高特权)",
        description: "拥有服务器的全部最高特权，无视其他所有权限限制，请极其慎重授予！",
        category: "ADVANCED",
    },
];
function hasPermission(userPermissions, flag) {
    if ((userPermissions & PermissionFlags.ADMINISTRATOR) ===
        PermissionFlags.ADMINISTRATOR) {
        return true;
    }
    return (userPermissions & flag) === flag;
}
function computePermissions(roles) {
    return roles.reduce((acc, r) => acc | r.permissions, 0);
}
function parseRoleIds(raw) {
    if (Array.isArray(raw))
        return raw.filter((id) => typeof id === "string");
    if (typeof raw === "string") {
        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return parsed.filter((id) => typeof id === "string");
            }
        }
        catch {
            return [];
        }
    }
    return [];
}
exports.CHANNEL_TEXT_PERMISSIONS = [
    PermissionFlags.VIEW_CHANNEL,
    PermissionFlags.MANAGE_CHANNELS,
    PermissionFlags.MANAGE_ROLES,
    PermissionFlags.SEND_MESSAGES,
    PermissionFlags.ATTACH_FILES,
    PermissionFlags.READ_MESSAGE_HISTORY,
    PermissionFlags.ADD_REACTIONS,
    PermissionFlags.MANAGE_MESSAGES,
    PermissionFlags.CREATE_INVITE,
];
exports.CHANNEL_VOICE_PERMISSIONS = [
    PermissionFlags.VIEW_CHANNEL,
    PermissionFlags.MANAGE_CHANNELS,
    PermissionFlags.MANAGE_ROLES,
    PermissionFlags.CONNECT,
    PermissionFlags.SPEAK,
    PermissionFlags.STREAM,
    PermissionFlags.MUTE_MEMBERS,
    PermissionFlags.DEAFEN_MEMBERS,
    PermissionFlags.MOVE_MEMBERS,
];
exports.CHANNEL_CATEGORY_PERMISSIONS = [
    ...Array.from(new Set([...exports.CHANNEL_TEXT_PERMISSIONS, ...exports.CHANNEL_VOICE_PERMISSIONS])),
];
function computeEffectivePermissions(context) {
    if (context.isOwner || context.isSuperAdmin) {
        return ~0;
    }
    const everyoneRole = context.guildRoles.find((r) => r.isDefault);
    let perms = everyoneRole ? everyoneRole.permissions : 0;
    for (const roleId of context.userRoleIds) {
        const role = context.guildRoles.find((r) => r.id === roleId);
        if (role) {
            perms |= role.permissions;
        }
    }
    if ((perms & PermissionFlags.ADMINISTRATOR) ===
        PermissionFlags.ADMINISTRATOR) {
        return ~0;
    }
    if (context.categoryOverwrites && context.categoryOverwrites.length > 0) {
        if (everyoneRole) {
            const catEveryone = context.categoryOverwrites.find((o) => o.targetType === "ROLE" && o.targetId === everyoneRole.id);
            if (catEveryone) {
                perms = (perms & ~catEveryone.deny) | catEveryone.allow;
            }
        }
        let catRoleAllow = 0;
        let catRoleDeny = 0;
        for (const roleId of context.userRoleIds) {
            const catRoleOw = context.categoryOverwrites.find((o) => o.targetType === "ROLE" && o.targetId === roleId);
            if (catRoleOw) {
                catRoleAllow |= catRoleOw.allow;
                catRoleDeny |= catRoleOw.deny;
            }
        }
        perms = (perms & ~catRoleDeny) | catRoleAllow;
        const catMemberOw = context.categoryOverwrites.find((o) => o.targetType === "MEMBER" && o.targetId === context.userId);
        if (catMemberOw) {
            perms = (perms & ~catMemberOw.deny) | catMemberOw.allow;
        }
    }
    if (context.channelOverwrites && context.channelOverwrites.length > 0) {
        if (everyoneRole) {
            const chEveryone = context.channelOverwrites.find((o) => o.targetType === "ROLE" && o.targetId === everyoneRole.id);
            if (chEveryone) {
                perms = (perms & ~chEveryone.deny) | chEveryone.allow;
            }
        }
        let chRoleAllow = 0;
        let chRoleDeny = 0;
        for (const roleId of context.userRoleIds) {
            const chRoleOw = context.channelOverwrites.find((o) => o.targetType === "ROLE" && o.targetId === roleId);
            if (chRoleOw) {
                chRoleAllow |= chRoleOw.allow;
                chRoleDeny |= chRoleOw.deny;
            }
        }
        perms = (perms & ~chRoleDeny) | chRoleAllow;
        const chMemberOw = context.channelOverwrites.find((o) => o.targetType === "MEMBER" && o.targetId === context.userId);
        if (chMemberOw) {
            perms = (perms & ~chMemberOw.deny) | chMemberOw.allow;
        }
    }
    return perms;
}
var AuditLogAction;
(function (AuditLogAction) {
    AuditLogAction["GUILD_UPDATE"] = "GUILD_UPDATE";
    AuditLogAction["ROLE_CREATE"] = "ROLE_CREATE";
    AuditLogAction["ROLE_UPDATE"] = "ROLE_UPDATE";
    AuditLogAction["ROLE_DELETE"] = "ROLE_DELETE";
    AuditLogAction["MEMBER_KICK"] = "MEMBER_KICK";
    AuditLogAction["MEMBER_BAN_ADD"] = "MEMBER_BAN_ADD";
    AuditLogAction["MEMBER_BAN_REMOVE"] = "MEMBER_BAN_REMOVE";
    AuditLogAction["MEMBER_ROLE_UPDATE"] = "MEMBER_ROLE_UPDATE";
    AuditLogAction["INVITE_CREATE"] = "INVITE_CREATE";
    AuditLogAction["INVITE_DELETE"] = "INVITE_DELETE";
    AuditLogAction["CHANNEL_CREATE"] = "CHANNEL_CREATE";
    AuditLogAction["CHANNEL_UPDATE"] = "CHANNEL_UPDATE";
    AuditLogAction["CHANNEL_DELETE"] = "CHANNEL_DELETE";
})(AuditLogAction || (exports.AuditLogAction = AuditLogAction = {}));
const video_embeds_js_1 = require("./video-embeds.js");
__exportStar(require("./video-embeds.js"), exports);
function isMessageEmbed(value) {
    if (!value || typeof value !== "object")
        return false;
    const embed = value;
    if (embed.video !== undefined && !(0, video_embeds_js_1.isVideoEmbedDescriptor)(embed.video))
        return false;
    if (embed.thumbnailUrl !== undefined &&
        (!(0, video_embeds_js_1.isVideoEmbedDescriptor)(embed.video) ||
            !(0, video_embeds_js_1.isVideoThumbnailUrl)(embed.thumbnailUrl, embed.video.provider)))
        return false;
    for (const key of ["url", "originalUrl"]) {
        if (typeof embed[key] !== "string")
            return false;
        try {
            const url = new URL(embed[key]);
            if (!["http:", "https:"].includes(url.protocol) ||
                url.username ||
                url.password)
                return false;
        }
        catch {
            return false;
        }
    }
    for (const [key, max] of [
        ["title", 256],
        ["description", 512],
        ["siteName", 128],
    ]) {
        if (embed[key] !== undefined &&
            (typeof embed[key] !== "string" || embed[key].length > max))
            return false;
    }
    if (embed.video !== undefined) {
        const parsedVideo = (0, video_embeds_js_1.parseVideoUrl)(embed.url);
        if (!parsedVideo ||
            (0, video_embeds_js_1.getCanonicalVideoUrl)(parsedVideo) !==
                (0, video_embeds_js_1.getCanonicalVideoUrl)(embed.video))
            return false;
    }
    return (embed.themeColor === undefined ||
        (typeof embed.themeColor === "string" &&
            /^#(?:[0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(embed.themeColor)));
}
// 5. 网关信令协议 (WebSocket Gateway)
var GatewayOpCode;
(function (GatewayOpCode) {
    GatewayOpCode[GatewayOpCode["DISPATCH"] = 0] = "DISPATCH";
    GatewayOpCode[GatewayOpCode["HEARTBEAT"] = 1] = "HEARTBEAT";
    GatewayOpCode[GatewayOpCode["IDENTIFY"] = 2] = "IDENTIFY";
    GatewayOpCode[GatewayOpCode["STATUS_UPDATE"] = 3] = "STATUS_UPDATE";
    GatewayOpCode[GatewayOpCode["VOICE_STATE_UPDATE"] = 4] = "VOICE_STATE_UPDATE";
    GatewayOpCode[GatewayOpCode["RESUME"] = 6] = "RESUME";
    GatewayOpCode[GatewayOpCode["RECONNECT"] = 7] = "RECONNECT";
    GatewayOpCode[GatewayOpCode["INVALID_SESSION"] = 9] = "INVALID_SESSION";
    GatewayOpCode[GatewayOpCode["HELLO"] = 10] = "HELLO";
    GatewayOpCode[GatewayOpCode["HEARTBEAT_ACK"] = 11] = "HEARTBEAT_ACK";
    GatewayOpCode[GatewayOpCode["SERVER_PING"] = 12] = "SERVER_PING";
    GatewayOpCode[GatewayOpCode["CLIENT_PONG"] = 13] = "CLIENT_PONG";
})(GatewayOpCode || (exports.GatewayOpCode = GatewayOpCode = {}));
var GatewayCloseCode;
(function (GatewayCloseCode) {
    GatewayCloseCode[GatewayCloseCode["NORMAL"] = 1000] = "NORMAL";
    GatewayCloseCode[GatewayCloseCode["TOKEN_EXPIRED"] = 4001] = "TOKEN_EXPIRED";
    GatewayCloseCode[GatewayCloseCode["UNAUTHORIZED"] = 4002] = "UNAUTHORIZED";
    GatewayCloseCode[GatewayCloseCode["ACCOUNT_BANNED"] = 4003] = "ACCOUNT_BANNED";
    GatewayCloseCode[GatewayCloseCode["SESSION_INVALID"] = 4004] = "SESSION_INVALID";
    GatewayCloseCode[GatewayCloseCode["MAINTENANCE_MODE"] = 4013] = "MAINTENANCE_MODE";
})(GatewayCloseCode || (exports.GatewayCloseCode = GatewayCloseCode = {}));
exports.DEFAULT_VIDEO_CODEC = "h264";
exports.MIN_CUSTOM_BITRATE = 500_000; // 500 kbps
exports.MAX_CUSTOM_BITRATE = 25_000_000; // 25 Mbps (支持 4K 60fps)
exports.CHANNEL_MUTE_DURATION_OPTIONS = [
    {
        label: "15 分钟",
        durationMs: 15 * 60 * 1000,
        i18nKey: "contextMenu:channel.mute15m",
    },
    {
        label: "1 小时",
        durationMs: 60 * 60 * 1000,
        i18nKey: "contextMenu:channel.mute1h",
    },
    {
        label: "3 小时",
        durationMs: 3 * 60 * 60 * 1000,
        i18nKey: "contextMenu:channel.mute3h",
    },
    {
        label: "8 小时",
        durationMs: 8 * 60 * 60 * 1000,
        i18nKey: "contextMenu:channel.mute8h",
    },
    {
        label: "24 小时",
        durationMs: 24 * 60 * 60 * 1000,
        i18nKey: "contextMenu:channel.mute24h",
    },
    {
        label: "直到重新开启",
        durationMs: null,
        i18nKey: "contextMenu:channel.muteUntilTurnedOn",
    },
];
/**
 * 判定频道配置当前是否处于有效静音状态（毫秒级判断）
 */
function isChannelMuted(config) {
    if (!config || !config.muted)
        return false;
    if (config.mutedUntil === null ||
        config.mutedUntil === undefined ||
        config.mutedUntil === -1) {
        return true;
    }
    return Date.now() < config.mutedUntil;
}
// 服务器静音预设时长选项与常量
exports.GUILD_MUTE_DURATION_OPTIONS = [
    {
        label: "15 分钟",
        durationMs: 15 * 60 * 1000,
        i18nKey: "contextMenu:channel.mute15m",
    },
    {
        label: "1 小时",
        durationMs: 60 * 60 * 1000,
        i18nKey: "contextMenu:channel.mute1h",
    },
    {
        label: "3 小时",
        durationMs: 3 * 60 * 60 * 1000,
        i18nKey: "contextMenu:channel.mute3h",
    },
    {
        label: "8 小时",
        durationMs: 8 * 60 * 60 * 1000,
        i18nKey: "contextMenu:channel.mute8h",
    },
    {
        label: "24 小时",
        durationMs: 24 * 60 * 60 * 1000,
        i18nKey: "contextMenu:channel.mute24h",
    },
    {
        label: "直到重新开启",
        durationMs: null,
        i18nKey: "contextMenu:channel.muteUntilTurnedOn",
    },
];
/**
 * 判定服务器配置当前是否处于有效静音状态（毫秒级判断）
 */
function isGuildMuted(config) {
    if (!config || !config.muted)
        return false;
    if (config.mutedUntil === null ||
        config.mutedUntil === undefined ||
        config.mutedUntil === -1) {
        return true;
    }
    return Date.now() < config.mutedUntil;
}
// 7.1 音频算法与工具函数 (Audio Utilities & Helpers)
function clampVolume(vol) {
    if (isNaN(vol))
        return 100;
    return Math.max(0, Math.min(200, Math.round(vol)));
}
function computeGain(volumePercent, isMuted) {
    if (isMuted)
        return 0;
    return clampVolume(volumePercent) / 100;
}
function evaluateNetworkQuality(rtt, packetLoss) {
    if (rtt < 60 && packetLoss < 2)
        return "excellent";
    if (rtt < 150 && packetLoss < 6)
        return "good";
    return "poor";
}
function calculateSNRReduction(rawRms, cleanRms) {
    const safeRaw = Math.max(1e-6, rawRms);
    const safeClean = Math.max(1e-6, cleanRms);
    if (safeRaw <= safeClean)
        return 0;
    const db = 20 * Math.log10(safeRaw / safeClean);
    return Math.max(0, +db.toFixed(1));
}
function calculateTripleSNRReduction(rawRms, rnnoiseRms, dtlnRms) {
    return {
        rawRms,
        rnnoiseRms,
        dtlnRms,
        rnnoiseDbReduction: calculateSNRReduction(rawRms, rnnoiseRms),
        dtlnDbReduction: calculateSNRReduction(rawRms, dtlnRms),
    };
}
function calculateQuadSNRReduction(rawRms, rnnoiseRms, dtlnRms, dfn3Rms) {
    return {
        rawRms,
        rnnoiseRms,
        dtlnRms,
        dfn3Rms,
        rnnoiseDbReduction: calculateSNRReduction(rawRms, rnnoiseRms),
        dtlnDbReduction: calculateSNRReduction(rawRms, dtlnRms),
        dfn3DbReduction: calculateSNRReduction(rawRms, dfn3Rms),
    };
}
// 9. 网关事件常量 (Gateway Event Constants)
exports.GatewayEvents = {
    READY: "READY",
    BOT_CONFIG_UPDATE: "BOT_CONFIG_UPDATE",
    BOT_COMMANDS_UPDATE: "BOT_COMMANDS_UPDATE",
    INTERACTION_CREATE: "INTERACTION_CREATE",
    INTERACTION_THINKING: "INTERACTION_THINKING",
    INTERACTION_MODAL: "INTERACTION_MODAL",
    EPHEMERAL_MESSAGE: "EPHEMERAL_MESSAGE",
    EPHEMERAL_DELETE: "EPHEMERAL_DELETE",
    MESSAGE_SEND: "MESSAGE_SEND",
    MESSAGE_SEND_RESULT: "MESSAGE_SEND_RESULT",
    MESSAGE_CREATE: "MESSAGE_CREATE",
    MESSAGE_UPDATE: "MESSAGE_UPDATE",
    MESSAGE_DELETE: "MESSAGE_DELETE",
    MESSAGE_REACTION_ADD: "MESSAGE_REACTION_ADD",
    MESSAGE_REACTION_REMOVE: "MESSAGE_REACTION_REMOVE",
    MESSAGE_PIN_UPDATE: "MESSAGE_PIN_UPDATE",
    VOICE_STATE_UPDATE: "VOICE_STATE_UPDATE",
    VOICE_SERVER_DISCONNECT: "VOICE_SERVER_DISCONNECT",
    CF_MEDIA_TRACKS: "CF_MEDIA_TRACKS",
    CF_STREAM_VIEWERS: "CF_STREAM_VIEWERS",
    USER_UPDATE: "USER_UPDATE",
    PRESENCE_UPDATE: "PRESENCE_UPDATE",
    GUILD_CREATE: "GUILD_CREATE",
    GUILD_UPDATE: "GUILD_UPDATE",
    GUILD_DELETE: "GUILD_DELETE",
    GUILD_MEMBER_ADD: "GUILD_MEMBER_ADD",
    GUILD_MEMBER_REMOVE: "GUILD_MEMBER_REMOVE",
    GUILD_MEMBER_UPDATE: "GUILD_MEMBER_UPDATE",
    GUILD_ROLE_CREATE: "GUILD_ROLE_CREATE",
    GUILD_ROLE_UPDATE: "GUILD_ROLE_UPDATE",
    GUILD_ROLE_DELETE: "GUILD_ROLE_DELETE",
    GUILD_BAN_ADD: "GUILD_BAN_ADD",
    GUILD_BAN_REMOVE: "GUILD_BAN_REMOVE",
    CHANNEL_CREATE: "CHANNEL_CREATE",
    CHANNEL_UPDATE: "CHANNEL_UPDATE",
    CHANNEL_DELETE: "CHANNEL_DELETE",
    CATEGORY_CREATE: "CATEGORY_CREATE",
    CATEGORY_UPDATE: "CATEGORY_UPDATE",
    CATEGORY_DELETE: "CATEGORY_DELETE",
    CATEGORY_POSITIONS_UPDATE: "CATEGORY_POSITIONS_UPDATE",
    CHANNEL_POSITIONS_UPDATE: "CHANNEL_POSITIONS_UPDATE",
    STREAM_START: "STREAM_START",
    STREAM_STOP: "STREAM_STOP",
    // 文本 E2EE 信令（Double Ratchet）
    E2EE_KEY_EXCHANGE: "E2EE_KEY_EXCHANGE",
    E2EE_CHANNEL_UPDATE: "E2EE_CHANNEL_UPDATE",
    TYPING_START: "TYPING_START",
    TYPING_STOP: "TYPING_STOP",
    // 媒体端到端加密（SFrame）实时推送与确认信令
    MEDIA_KEY_ENVELOPE: "MEDIA_KEY_ENVELOPE",
    MEDIA_KEY_ACK: "MEDIA_KEY_ACK",
    MEDIA_EPOCH_UPDATE: "MEDIA_EPOCH_UPDATE",
    MEDIA_MEMBER_LEFT: "MEDIA_MEMBER_LEFT",
    MEDIA_KEY_RESYNC_REQUEST: "MEDIA_KEY_RESYNC_REQUEST",
    MEDIA_ENCRYPTION_SYNC: "MEDIA_ENCRYPTION_SYNC",
    MEDIA_ENCRYPTION_SYNC_RESULT: "MEDIA_ENCRYPTION_SYNC_RESULT",
    // P2P 直连与智能接力信令
    P2P_SIGNAL: "P2P_SIGNAL",
    P2P_TOPOLOGY_UPDATE: "P2P_TOPOLOGY_UPDATE",
    P2P_QUALITY_REPORT: "P2P_QUALITY_REPORT",
    P2P_FALLBACK_REQUEST: "P2P_FALLBACK_REQUEST",
    // 私信与 1v1 音视频呼叫信令
    DM_CHANNEL_CREATE: "DM_CHANNEL_CREATE",
    DM_CHANNEL_UPDATE: "DM_CHANNEL_UPDATE",
    DM_CHANNEL_DELETE: "DM_CHANNEL_DELETE",
    CALL_OFFER: "CALL_OFFER",
    CALL_ANSWER: "CALL_ANSWER",
    CALL_REJECT: "CALL_REJECT",
    CALL_END: "CALL_END",
    CALL_STATE_UPDATE: "CALL_STATE_UPDATE",
    CALL_MISSED: "CALL_MISSED",
    // 好友关系与申请信令
    RELATIONSHIP_ADD: "RELATIONSHIP_ADD",
    RELATIONSHIP_REMOVE: "RELATIONSHIP_REMOVE",
    RELATIONSHIP_UPDATE: "RELATIONSHIP_UPDATE",
    ACCOUNT_SESSION_REVOKED: "ACCOUNT_SESSION_REVOKED",
    HISTORY_RECOVERY_UPDATED: "HISTORY_RECOVERY_UPDATED",
    AUTH_SESSION_EXPIRED: "AUTH_SESSION_EXPIRED",
    MAINTENANCE_UPDATE: "MAINTENANCE_UPDATE",
    // 全网系统广播
    SYSTEM_BROADCAST: "SYSTEM_BROADCAST",
    // 语音频道事件信令 (进出与踢出等活动)
    VOICE_CHANNEL_EVENT: "VOICE_CHANNEL_EVENT",
    // 好友间 P2P 直连大文件传输信令
    P2P_FILE_OFFER: "P2P_FILE_OFFER",
    P2P_FILE_RESPONSE: "P2P_FILE_RESPONSE",
    P2P_FILE_SIGNAL: "P2P_FILE_SIGNAL",
    P2P_FILE_CANCEL: "P2P_FILE_CANCEL",
};
var VoiceChannelEventType;
(function (VoiceChannelEventType) {
    VoiceChannelEventType["JOIN"] = "JOIN";
    VoiceChannelEventType["LEAVE"] = "LEAVE";
    VoiceChannelEventType["KICKED"] = "KICKED";
})(VoiceChannelEventType || (exports.VoiceChannelEventType = VoiceChannelEventType = {}));
exports.P2P_IPC_CHANNELS = {
    SELECT_SAVE_PATH: "desktop:p2p:select-save-path",
    SELECT_SAVE_DIRECTORY: "desktop:p2p:select-save-directory",
    START_WRITE_STREAM: "desktop:p2p:start-write-stream",
    WRITE_CHUNK: "desktop:p2p:write-chunk",
    CLOSE_STREAM: "desktop:p2p:close-stream",
    CANCEL_STREAM: "desktop:p2p:cancel-stream",
};
exports.P2PErrorCode = {
    ICE_TIMEOUT: "p2p_ice_timeout",
    ICE_FAILED: "p2p_ice_failed",
    CHANNEL_ERROR: "p2p_channel_error",
    CHANNEL_CLOSED: "p2p_channel_closed",
    PEER_REJECTED: "p2p_peer_rejected",
    REJECTED_BY_SELF: "p2p_rejected_by_self",
    PEER_CANCELLED: "p2p_peer_cancelled",
    CANCELLED_BY_SELF: "p2p_cancelled_by_self",
};
exports.RESOLUTION_OPTIONS = [
    {
        id: "480p",
        label: "480P (标清)",
        width: 854,
        height: 480,
        description: "极低带宽开销，适合弱网及文档阅读",
    },
    {
        id: "720p",
        label: "720P (高清)",
        width: 1280,
        height: 720,
        description: "省流低带宽，适合日常文档与演示",
    },
    {
        id: "1080p",
        label: "1080P (超清)",
        width: 1920,
        height: 1080,
        description: "细腻清晰，代码与文本展示首选",
    },
    {
        id: "1440p",
        label: "2K 1440P (极清)",
        width: 2560,
        height: 1440,
        description: "2K 细腻画质，高清大屏演示",
    },
    {
        id: "4k",
        label: "4K 2160P (原画)",
        width: 3840,
        height: 2160,
        description: "4K 视网膜级原生画质呈现",
    },
];
exports.FPS_OPTIONS = [15, 30, 60];
function getRecommendedBitrate(resolution, fps) {
    const table = {
        "480p": { 15: 500_000, 30: 800_000, 60: 1_200_000 },
        "720p": { 15: 1_000_000, 30: 1_500_000, 60: 2_500_000 },
        "1080p": { 15: 2_000_000, 30: 3_000_000, 60: 5_000_000 },
        "1440p": { 15: 3_500_000, 30: 5_000_000, 60: 8_000_000 },
        "4k": { 15: 6_000_000, 30: 10_000_000, 60: 16_000_000 },
    };
    return table[resolution]?.[fps] ?? 3_000_000;
}
/**
 * 根据屏幕物理像素尺寸 (宽, 高)，按 16:9 比例计算该屏幕所支持的最大标准 16:9 分辨率档位。
 * 支持 16:10、21:9、3:2 等非标比例屏幕安全等比内接映射。
 */
function getMaxAllowed16x9Resolution(screenWidth, screenHeight) {
    if (!screenWidth || !screenHeight || screenWidth <= 0 || screenHeight <= 0) {
        return "1080p"; // 默认安全回退
    }
    // 横屏归一化（防止竖屏取反）
    const w = Math.max(screenWidth, screenHeight);
    const h = Math.min(screenWidth, screenHeight);
    // 计算最大内接 16:9 尺寸的高（纵向像素）
    // H_avail = min(H, floor(W * 9 / 16))
    const hAvail = Math.min(h, Math.floor((w * 9) / 16));
    // 按照阶梯划分 (带 32px 容差缓冲)
    if (hAvail < 688) {
        return "480p";
    }
    else if (hAvail < 1048) {
        return "720p";
    }
    else if (hAvail < 1408) {
        return "1080p";
    }
    else if (hAvail < 2128) {
        return "1440p";
    }
    else {
        return "4k";
    }
}
/**
 * 判定目标分辨率是否被最大允许分辨率支持 (基于 480p < 720p < 1080p < 1440p < 4k 顺序)
 */
function isResolutionAllowed(target, maxAllowed) {
    const order = [
        "480p",
        "720p",
        "1080p",
        "1440p",
        "4k",
    ];
    const targetIdx = order.indexOf(target);
    const maxIdx = order.indexOf(maxAllowed);
    if (targetIdx === -1)
        return true;
    if (maxIdx === -1)
        return true;
    return targetIdx <= maxIdx;
}
exports.SCREEN_SHARE_PRESETS = {
    "480p15": {
        id: "480p15",
        name: "省流极低 (480p 15fps)",
        width: 854,
        height: 480,
        frameRate: 15,
        bitrate: 500_000,
        description: "极限省流模式，超低带宽开销",
    },
    "480p30": {
        id: "480p30",
        name: "流畅标清 (480p 30fps)",
        width: 854,
        height: 480,
        frameRate: 30,
        bitrate: 800_000,
        description: "极低带宽开销，适合弱网及文档阅读",
    },
    "480p60": {
        id: "480p60",
        name: "流畅高帧 (480p 60fps)",
        width: 854,
        height: 480,
        frameRate: 60,
        bitrate: 1_200_000,
        description: "低带宽下的高帧率分享",
    },
    "720p15": {
        id: "720p15",
        name: "文档标清 (720p 15fps)",
        width: 1280,
        height: 720,
        frameRate: 15,
        bitrate: 1_000_000,
        description: "清晰文字展示，低帧率省流",
    },
    "720p30": {
        id: "720p30",
        name: "流畅标清 (720p 30fps)",
        width: 1280,
        height: 720,
        frameRate: 30,
        bitrate: 1_500_000,
        description: "省流低带宽，适合日常文档与演示",
    },
    "720p60": {
        id: "720p60",
        name: "流畅电竞 (720p 60fps)",
        width: 1280,
        height: 720,
        frameRate: 60,
        bitrate: 2_500_000,
        description: "兼顾高帧率与画质，竞技游戏优先",
    },
    "1080p15": {
        id: "1080p15",
        name: "静态高清 (1080p 15fps)",
        width: 1920,
        height: 1080,
        frameRate: 15,
        bitrate: 2_000_000,
        description: "高分辨率代码与文档阅读首选",
    },
    "1080p30": {
        id: "1080p30",
        name: "高清演示 (1080p 30fps)",
        width: 1920,
        height: 1080,
        frameRate: 30,
        bitrate: 3_000_000,
        description: "细腻清晰，代码与文本展示首选",
    },
    "1080p60": {
        id: "1080p60",
        name: "极清高帧 (1080p 60fps)",
        width: 1920,
        height: 1080,
        frameRate: 60,
        bitrate: 5_000_000,
        description: "极致画质与丝滑流畅，高画质游戏直播",
    },
    "1440p15": {
        id: "1440p15",
        name: "2K静态 (1440p 15fps)",
        width: 2560,
        height: 1440,
        frameRate: 15,
        bitrate: 3_500_000,
        description: "2K 超高解析度静态画面",
    },
    "1440p30": {
        id: "1440p30",
        name: "2K极清 (1440p 30fps)",
        width: 2560,
        height: 1440,
        frameRate: 30,
        bitrate: 5_000_000,
        description: "2K 细腻画质，高清大屏演示",
    },
    "1440p60": {
        id: "1440p60",
        name: "2K高刷 (1440p 60fps)",
        width: 2560,
        height: 1440,
        frameRate: 60,
        bitrate: 8_000_000,
        description: "2K 电竞高刷直播，超高解析度",
    },
    "4k15": {
        id: "4k15",
        name: "4K静态 (4K 15fps)",
        width: 3840,
        height: 2160,
        frameRate: 15,
        bitrate: 6_000_000,
        description: "4K 视网膜级超精细文本与绘图",
    },
    "4k30": {
        id: "4k30",
        name: "4K原画 (4K 30fps)",
        width: 3840,
        height: 2160,
        frameRate: 30,
        bitrate: 10_000_000,
        description: "4K 视网膜级原生画质呈现",
    },
    "4k60": {
        id: "4k60",
        name: "4K极限 (4K 60fps)",
        width: 3840,
        height: 2160,
        frameRate: 60,
        bitrate: 16_000_000,
        description: "4K 60fps 旗舰级画质分享",
    },
};
function computeSimulcastLayers(baseWidth, baseHeight, baseFps, baseBitrate) {
    // 强制将分辨率对齐到偶数 (2 的倍数)，以防 H.264 / VP8 硬件编码器因奇数宽度或高度崩溃
    const safeBaseW = Math.max(2, (Math.round(baseWidth) >> 1) << 1);
    const safeBaseH = Math.max(2, (Math.round(baseHeight) >> 1) << 1);
    const halfW = Math.max(2, (Math.round(safeBaseW / 2) >> 1) << 1);
    const halfH = Math.max(2, (Math.round(safeBaseH / 2) >> 1) << 1);
    const quarterW = Math.max(2, (Math.round(safeBaseW / 4) >> 1) << 1);
    const quarterH = Math.max(2, (Math.round(safeBaseH / 4) >> 1) << 1);
    return [
        {
            rid: "f",
            width: safeBaseW,
            height: safeBaseH,
            maxFramerate: Math.max(1, baseFps),
            maxBitrate: Math.max(100_000, baseBitrate),
        },
        {
            rid: "h",
            width: halfW,
            height: halfH,
            maxFramerate: Math.min(30, Math.max(1, baseFps)),
            maxBitrate: Math.round(baseBitrate * 0.35),
        },
        {
            rid: "q",
            width: quarterW,
            height: quarterH,
            maxFramerate: 15,
            maxBitrate: Math.round(baseBitrate * 0.12),
        },
    ];
}
exports.DEFAULT_USER_NOTIFICATION_SETTINGS = {
    enabled: true,
    directMessages: true,
    mentions: true,
    calls: true,
    p2pTransfers: true,
    soundEnabled: true,
};
// ==========================================
// 11. 阶段五：混合分级安全加密体系协议与核心算法 (Phase 5 Contracts & Crypto)
// ==========================================
// 11.0 跨平台基础编解码与密钥转换工具
function bytesToBase64(bytes) {
    const g = globalThis;
    if (typeof g.Buffer !== "undefined") {
        return g.Buffer.from(bytes).toString("base64");
    }
    let binary = "";
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}
function base64ToBytes(base64) {
    const g = globalThis;
    if (typeof g.Buffer !== "undefined") {
        return new Uint8Array(g.Buffer.from(base64, "base64"));
    }
    try {
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
        }
        return bytes;
    }
    catch {
        return new TextEncoder().encode(base64);
    }
}
function bytesToHex(bytes) {
    const g = globalThis;
    if (typeof g.Buffer !== "undefined") {
        return g.Buffer.from(bytes).toString("hex");
    }
    return Array.from(bytes)
        .map((b) => b.toString(16).padStart(2, "0"))
        .join("");
}
function hexToBytes(hex) {
    const clean = hex.startsWith("0x") ? hex.slice(2) : hex;
    const bytes = new Uint8Array(clean.length / 2);
    for (let i = 0; i < clean.length; i += 2) {
        bytes[i / 2] = parseInt(clean.substring(i, i + 2), 16);
    }
    return bytes;
}
function buildSecurityHeaders(custom) {
    return {
        "Strict-Transport-Security": custom?.strictTransportSecurity ||
            "max-age=31536000; includeSubDomains; preload",
        "Content-Security-Policy": custom?.contentSecurityPolicy ||
            "default-src 'self'; script-src 'self' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src 'self' blob: mediastream:; connect-src 'self' ws: wss: http: https:; frame-src https://www.youtube-nocookie.com https://player.bilibili.com;",
        "X-Content-Type-Options": custom?.xContentTypeOptions || "nosniff",
        "X-Frame-Options": custom?.xFrameOptions || "DENY",
        "Referrer-Policy": custom?.referrerPolicy || "strict-origin-when-cross-origin",
        "Permissions-Policy": custom?.permissionsPolicy ||
            "camera=(), microphone=(self), display-capture=(self)",
    };
}
function validateDtlsSrtpParameters(config) {
    const reasons = [];
    if (!config.requireDtlsSrtp) {
        reasons.push("WebRTC 媒体链路必须强制开启 requireDtlsSrtp");
    }
    const supportedCiphers = [
        "SRTP_AES128_CM_HMAC_SHA1_80",
        "SRTP_AEAD_AES_128_GCM",
        "SRTP_AEAD_AES_256_GCM",
    ];
    const hasValidCipher = config.cipherSuites?.some((c) => supportedCiphers.includes(c));
    if (!hasValidCipher) {
        reasons.push("cipherSuites 未包含标准 SRTP 加密套件 (如 SRTP_AEAD_AES_128_GCM / SRTP_AEAD_AES_256_GCM)");
    }
    return {
        valid: reasons.length === 0,
        reasons,
    };
}
/** RFC 9605 section 4.3 compact, unsigned, big-endian header. */
function encodeSFrameHeader(kid, counter) {
    if (!Number.isSafeInteger(kid) || kid < 0)
        throw new Error("MEDIA_KEY_INVALID");
    const ctr = BigInt(counter);
    if (ctr < 0n || ctr > 0xffffffffffffffffn)
        throw new Error("MEDIA_KEY_INVALID");
    const encode = (value) => {
        if (value <= 7n)
            return [];
        const bytes = [];
        do {
            bytes.unshift(Number(value & 255n));
            value >>= 8n;
        } while (value);
        return bytes;
    };
    const k = encode(BigInt(kid)), c = encode(ctr);
    const config = (k.length ? 0x80 | ((k.length - 1) << 4) : kid << 4) |
        (c.length ? 0x08 | (c.length - 1) : Number(ctr));
    return Uint8Array.from([config, ...k, ...c]);
}
function decodeSFrameHeader(buffer) {
    if (!buffer.length)
        throw new Error("MEDIA_KEY_INVALID");
    const config = buffer[0];
    let offset = 1;
    const read = (length) => {
        if (offset + length > buffer.length)
            throw new Error("MEDIA_KEY_INVALID");
        let value = 0n;
        for (let i = 0; i < length; i++)
            value = (value << 8n) | BigInt(buffer[offset++]);
        if (value <= 7n || (length > 1 && buffer[offset - length] === 0))
            throw new Error("MEDIA_KEY_INVALID");
        return value;
    };
    const kidBig = config & 0x80 ? read(((config >> 4) & 7) + 1) : BigInt((config >> 4) & 7);
    const counter = config & 8 ? read((config & 7) + 1) : BigInt(config & 7);
    if (kidBig > BigInt(Number.MAX_SAFE_INTEGER))
        throw new Error("MEDIA_KEY_INVALID");
    return { kid: Number(kidBig), counter, headerLength: offset };
}
const sframeDerivedKeys = new WeakMap();
/** AES_256_GCM_SHA512_128 (0x0005), RFC 9605 section 4.4.2. */
function deriveSFrameKey(keyBuffer, kid) {
    if (keyBuffer.length !== 16 && keyBuffer.length !== 32)
        return Promise.reject(new Error("MEDIA_KEY_INVALID"));
    let keys = sframeDerivedKeys.get(keyBuffer);
    if (!keys) {
        keys = new Map();
        sframeDerivedKeys.set(keyBuffer, keys);
    }
    const existing = keys.get(kid);
    if (existing)
        return existing;
    const promise = (async () => {
        const material = await globalThis.crypto.subtle.importKey("raw", keyBuffer, "HKDF", false, ["deriveBits"]);
        const suffix = new Uint8Array(10);
        const view = new DataView(suffix.buffer);
        view.setBigUint64(0, BigInt(kid));
        view.setUint16(8, 5);
        const derive = async (label, size) => {
            const prefix = new TextEncoder().encode(label);
            const info = new Uint8Array(prefix.length + suffix.length);
            info.set(prefix);
            info.set(suffix, prefix.length);
            return globalThis.crypto.subtle.deriveBits({ name: "HKDF", hash: "SHA-512", salt: new Uint8Array(0), info }, material, size * 8);
        };
        const [rawKey, rawSalt] = await Promise.all([
            derive("SFrame 1.0 Secret key ", 32),
            derive("SFrame 1.0 Secret salt ", 12),
        ]);
        const key = await globalThis.crypto.subtle.importKey("raw", rawKey, "AES-GCM", false, ["encrypt", "decrypt"]);
        return { key, salt: new Uint8Array(rawSalt) };
    })();
    keys.set(kid, promise);
    return promise;
}
function sframeNonce(salt, counter) {
    const nonce = salt.slice();
    for (let i = 0; i < 8; i++)
        nonce[11 - i] ^= Number((counter >> BigInt(i * 8)) & 255n);
    return nonce;
}
async function encryptSFramePacket(rawPcmOrOpus, keyBuffer, kid, counter, metadata = new Uint8Array(0)) {
    const header = encodeSFrameHeader(kid, counter);
    const derived = await deriveSFrameKey(keyBuffer, kid);
    const aad = new Uint8Array(header.length + metadata.length);
    aad.set(header);
    aad.set(metadata, header.length);
    const ciphertext = new Uint8Array(await globalThis.crypto.subtle.encrypt({
        name: "AES-GCM",
        iv: sframeNonce(derived.salt, BigInt(counter)),
        additionalData: aad,
        tagLength: 128,
    }, derived.key, rawPcmOrOpus));
    const result = new Uint8Array(header.length + ciphertext.length);
    result.set(header);
    result.set(ciphertext, header.length);
    return result;
}
async function decryptSFramePacket(sframePacket, keyBuffer, metadata = new Uint8Array(0)) {
    const header = decodeSFrameHeader(sframePacket);
    if (sframePacket.length < header.headerLength + 16)
        throw new Error("MEDIA_KEY_INVALID");
    const derived = await deriveSFrameKey(keyBuffer, header.kid);
    const aad = new Uint8Array(header.headerLength + metadata.length);
    aad.set(sframePacket.slice(0, header.headerLength));
    aad.set(metadata, header.headerLength);
    const decrypted = await globalThis.crypto.subtle.decrypt({
        name: "AES-GCM",
        iv: sframeNonce(derived.salt, header.counter),
        additionalData: aad,
        tagLength: 128,
    }, derived.key, sframePacket.slice(header.headerLength));
    return { decryptedPayload: new Uint8Array(decrypted), header };
}
class SFrameReplayFilter {
    windowSize;
    maxCounter = -1n;
    windowBitmask = 0n;
    constructor(windowSize = 64) {
        this.windowSize = BigInt(windowSize);
    }
    checkAndAdd(counter) {
        const ctr = BigInt(counter);
        if (this.maxCounter < 0n) {
            this.maxCounter = ctr;
            this.windowBitmask = 1n;
            return true;
        }
        if (ctr > this.maxCounter) {
            const diff = ctr - this.maxCounter;
            if (diff >= this.windowSize) {
                this.windowBitmask = 1n;
            }
            else {
                this.windowBitmask = (this.windowBitmask << diff) | 1n;
            }
            this.maxCounter = ctr;
            return true;
        }
        const diff = this.maxCounter - ctr;
        if (diff >= this.windowSize) {
            return false;
        }
        const mask = 1n << diff;
        if ((this.windowBitmask & mask) !== 0n) {
            return false;
        }
        this.windowBitmask |= mask;
        return true;
    }
}
exports.SFrameReplayFilter = SFrameReplayFilter;
async function generateDhKeyPair() {
    const cryptoObj = globalThis.crypto;
    if (!cryptoObj?.subtle)
        throw new Error("缺少 Web Crypto API");
    return await cryptoObj.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits", "deriveKey"]);
}
async function exportDhPublicKey(key) {
    const cryptoObj = globalThis.crypto;
    const raw = await cryptoObj.subtle.exportKey("raw", key);
    return bytesToBase64(new Uint8Array(raw));
}
async function importDhPublicKey(base64) {
    const cryptoObj = globalThis.crypto;
    return await cryptoObj.subtle.importKey("raw", base64ToBytes(base64), { name: "ECDH", namedCurve: "P-256" }, true, []);
}
async function computeDhSecret(privateKey, publicKey) {
    const cryptoObj = globalThis.crypto;
    const bits = await cryptoObj.subtle.deriveBits({ name: "ECDH", public: publicKey }, privateKey, 256);
    return new Uint8Array(bits);
}
async function kdfRootKey(rootKey, dhSecret) {
    const cryptoObj = globalThis.crypto;
    const enc = new TextEncoder();
    const hkdfKey = await cryptoObj.subtle.importKey("raw", dhSecret, { name: "HKDF" }, false, ["deriveBits"]);
    const derived = await cryptoObj.subtle.deriveBits({
        name: "HKDF",
        hash: "SHA-256",
        salt: rootKey,
        info: enc.encode("TescordDoubleRatchetRootKDF"),
    }, hkdfKey, 512);
    const buf = new Uint8Array(derived);
    return {
        nextRootKey: buf.slice(0, 32),
        chainKey: buf.slice(32, 64),
    };
}
async function kdfChainKey(chainKey) {
    const cryptoObj = globalThis.crypto;
    const enc = new TextEncoder();
    const hkdfKey = await cryptoObj.subtle.importKey("raw", chainKey, { name: "HKDF" }, false, ["deriveBits"]);
    const derived = await cryptoObj.subtle.deriveBits({
        name: "HKDF",
        hash: "SHA-256",
        salt: new Uint8Array(32),
        info: enc.encode("TescordDoubleRatchetChainKDF"),
    }, hkdfKey, 512);
    const buf = new Uint8Array(derived);
    return {
        nextChainKey: buf.slice(0, 32),
        messageKey: buf.slice(32, 64),
    };
}
async function computeFingerprint(pubBase64) {
    const cryptoObj = globalThis.crypto;
    const digest = await cryptoObj.subtle.digest("SHA-256", base64ToBytes(pubBase64));
    return bytesToHex(new Uint8Array(digest)).slice(0, 16).toUpperCase();
}
async function computeSafetyNumber(pubKeyA, pubKeyB) {
    const cryptoObj = globalThis.crypto;
    const [p1, p2] = [pubKeyA, pubKeyB].sort();
    const enc = new TextEncoder();
    const data = enc.encode(`TescordSafetyNumber:${p1}:${p2}`);
    const hashBuf = await cryptoObj.subtle.digest("SHA-256", data);
    const bytes = new Uint8Array(hashBuf);
    const chunks = [];
    for (let i = 0; i < 12; i++) {
        const offset = i * 2;
        const val = ((bytes[offset] << 8) | bytes[offset + 1]) % 100000;
        chunks.push(val.toString().padStart(5, "0"));
    }
    const safetyNumber = chunks.join("");
    const formattedSafetyNumber = chunks.join(" ");
    const [fingerprintA, fingerprintB] = await Promise.all([
        computeFingerprint(pubKeyA),
        computeFingerprint(pubKeyB),
    ]);
    return {
        safetyNumber,
        formattedSafetyNumber,
        fingerprintA,
        fingerprintB,
    };
}
async function encryptMessageWithKey(plaintext, messageKey, associatedData) {
    const cryptoObj = globalThis.crypto;
    const key = await cryptoObj.subtle.importKey("raw", messageKey, { name: "AES-GCM" }, false, ["encrypt"]);
    const iv = cryptoObj.getRandomValues(new Uint8Array(12));
    const enc = new TextEncoder();
    const ctBuf = await cryptoObj.subtle.encrypt({ name: "AES-GCM", iv, additionalData: associatedData }, key, enc.encode(plaintext));
    const rawCt = new Uint8Array(ctBuf);
    const tag = rawCt.slice(rawCt.length - 16);
    const ciphertext = rawCt.slice(0, rawCt.length - 16);
    return {
        ciphertext: bytesToBase64(ciphertext),
        iv: bytesToBase64(iv),
        tag: bytesToBase64(tag),
    };
}
async function decryptMessageWithKey(ciphertextBase64, ivBase64, tagBase64, messageKey, associatedData) {
    const cryptoObj = globalThis.crypto;
    const key = await cryptoObj.subtle.importKey("raw", messageKey, { name: "AES-GCM" }, false, ["decrypt"]);
    const ct = base64ToBytes(ciphertextBase64);
    const tag = base64ToBytes(tagBase64);
    const full = new Uint8Array(ct.length + tag.length);
    full.set(ct, 0);
    full.set(tag, ct.length);
    const iv = base64ToBytes(ivBase64);
    const dec = new TextDecoder();
    const ptBuf = await cryptoObj.subtle.decrypt({ name: "AES-GCM", iv, additionalData: associatedData }, key, full);
    return dec.decode(ptBuf);
}
class DoubleRatchetSession {
    localUserId;
    peerUserId;
    rootKey;
    sendingChainKey = null;
    receivingChainKey = null;
    localDhKeyPair = null;
    localDhPublicKeyB64 = null;
    remoteDhPublicKey = null;
    remoteDhPublicKeyB64 = null;
    sendingSeq = 0;
    receivingSeq = 0;
    previousChainLength = 0;
    skippedMessageKeys = new Map();
    // 频道群组模式支持 (Channel / Group Sender-Key Ratchet Mode)
    isChannelMode = false;
    channelId = null;
    channelReceivingChains = new Map();
    cachedFingerprint = null;
    constructor(localUserId, peerUserId, rootKey) {
        this.localUserId = localUserId;
        this.peerUserId = peerUserId;
        this.rootKey = new Uint8Array(rootKey);
    }
    async initAsAlice(peerDhPublicKey) {
        this.isChannelMode = false;
        if (typeof peerDhPublicKey === "string") {
            this.remoteDhPublicKey = await importDhPublicKey(peerDhPublicKey);
            this.remoteDhPublicKeyB64 = peerDhPublicKey;
        }
        else {
            this.remoteDhPublicKey = peerDhPublicKey;
            this.remoteDhPublicKeyB64 = await exportDhPublicKey(peerDhPublicKey);
        }
        this.localDhKeyPair = await generateDhKeyPair();
        this.localDhPublicKeyB64 = await exportDhPublicKey(this.localDhKeyPair.publicKey);
        this.cachedFingerprint = await computeFingerprint(this.localDhPublicKeyB64);
        const dhSecret = await computeDhSecret(this.localDhKeyPair.privateKey, this.remoteDhPublicKey);
        const { nextRootKey, chainKey } = await kdfRootKey(this.rootKey, dhSecret);
        this.rootKey = nextRootKey;
        this.sendingChainKey = chainKey;
        this.sendingSeq = 0;
    }
    async initAsBob(bobDhKeyPair) {
        this.isChannelMode = false;
        this.localDhKeyPair = bobDhKeyPair;
        this.localDhPublicKeyB64 = await exportDhPublicKey(this.localDhKeyPair.publicKey);
        this.cachedFingerprint = await computeFingerprint(this.localDhPublicKeyB64);
        this.sendingChainKey = null;
        this.receivingChainKey = null;
        this.sendingSeq = 0;
        this.receivingSeq = 0;
    }
    // 绝密频道模式：基于频道根密钥派生发送者棘轮链
    async initAsChannel(channelId, currentUserId) {
        this.isChannelMode = true;
        this.channelId = channelId;
        this.localUserId = currentUserId;
        this.localDhKeyPair = await generateDhKeyPair();
        this.localDhPublicKeyB64 = await exportDhPublicKey(this.localDhKeyPair.publicKey);
        this.cachedFingerprint = await computeFingerprint(this.localDhPublicKeyB64);
        const enc = new TextEncoder();
        const senderSeed = enc.encode(`TescordChannelSenderChain:${channelId}:${currentUserId}:${this.localDhPublicKeyB64}`);
        const { chainKey } = await kdfRootKey(this.rootKey, senderSeed);
        this.sendingChainKey = chainKey;
        this.sendingSeq = 0;
    }
    async ratchetEncrypt(plaintext, channelId = "e2ee-channel") {
        if (!this.localDhKeyPair) {
            this.localDhKeyPair = await generateDhKeyPair();
            this.localDhPublicKeyB64 = await exportDhPublicKey(this.localDhKeyPair.publicKey);
            this.cachedFingerprint = await computeFingerprint(this.localDhPublicKeyB64);
        }
        if (!this.sendingChainKey) {
            if (this.isChannelMode) {
                const localPub = this.localDhPublicKeyB64 ||
                    (await exportDhPublicKey(this.localDhKeyPair.publicKey));
                const enc = new TextEncoder();
                const senderSeed = enc.encode(`TescordChannelSenderChain:${channelId}:${this.localUserId}:${localPub}`);
                const { chainKey } = await kdfRootKey(this.rootKey, senderSeed);
                this.sendingChainKey = chainKey;
                this.sendingSeq = 0;
            }
            else {
                if (!this.remoteDhPublicKey) {
                    throw new Error("缺少远端 DH 公钥，无法建立发送链");
                }
                const dhSecret = await computeDhSecret(this.localDhKeyPair.privateKey, this.remoteDhPublicKey);
                const { nextRootKey, chainKey } = await kdfRootKey(this.rootKey, dhSecret);
                this.rootKey = nextRootKey;
                this.sendingChainKey = chainKey;
                this.sendingSeq = 0;
            }
        }
        const { nextChainKey, messageKey } = await kdfChainKey(this.sendingChainKey);
        this.sendingChainKey = nextChainKey;
        const currentSeq = this.sendingSeq;
        this.sendingSeq += 1;
        const localPubB64 = this.localDhPublicKeyB64 ||
            (await exportDhPublicKey(this.localDhKeyPair.publicKey));
        const enc = new TextEncoder();
        const associatedData = enc.encode(`${channelId}:${localPubB64}:${currentSeq}`);
        const { ciphertext, iv, tag } = await encryptMessageWithKey(plaintext, messageKey, associatedData);
        const fingerprint = this.cachedFingerprint || (await computeFingerprint(localPubB64));
        return {
            version: 1,
            senderId: this.localUserId,
            channelId,
            ephemeralPublicKey: localPubB64,
            sequenceNumber: currentSeq,
            previousChainLength: this.previousChainLength,
            ciphertext,
            iv,
            tag,
            fingerprint,
        };
    }
    async ratchetDecrypt(envelope) {
        const peerPubB64 = envelope.ephemeralPublicKey;
        const enc = new TextEncoder();
        const associatedData = enc.encode(`${envelope.channelId}:${peerPubB64}:${envelope.sequenceNumber}`);
        if (this.isChannelMode) {
            // 频道模式：按 [senderId + ephemeralPublicKey] 隔离接收链并执行前向棘轮
            const cacheKey = `${envelope.senderId}:${peerPubB64}:${envelope.sequenceNumber}`;
            if (this.skippedMessageKeys.has(cacheKey)) {
                const messageKey = this.skippedMessageKeys.get(cacheKey);
                this.skippedMessageKeys.delete(cacheKey);
                return await decryptMessageWithKey(envelope.ciphertext, envelope.iv, envelope.tag, messageKey, associatedData);
            }
            const chainId = `${envelope.senderId}:${peerPubB64}`;
            if (!this.channelReceivingChains.has(chainId)) {
                const senderSeed = enc.encode(`TescordChannelSenderChain:${envelope.channelId}:${envelope.senderId}:${peerPubB64}`);
                const { chainKey } = await kdfRootKey(this.rootKey, senderSeed);
                this.channelReceivingChains.set(chainId, { chainKey, seq: 0 });
            }
            const chainState = this.channelReceivingChains.get(chainId);
            if (envelope.sequenceNumber < chainState.seq) {
                throw new Error(`消息 sequenceNumber (${envelope.sequenceNumber}) 已落后于当前接收链游标 (${chainState.seq})，该消息已解密过或已被单向棘轮消费`);
            }
            const MAX_SKIP = 2000;
            if (chainState.seq + MAX_SKIP < envelope.sequenceNumber) {
                throw new Error("跳过的消息数量过多，疑似拒绝服务攻击 (DoS)");
            }
            // 处理乱序消息：将中途跳过的消息密钥暂存
            while (chainState.seq < envelope.sequenceNumber) {
                const { nextChainKey, messageKey } = await kdfChainKey(chainState.chainKey);
                chainState.chainKey = nextChainKey;
                this.saveSkippedMessageKey(`${envelope.senderId}:${peerPubB64}:${chainState.seq}`, messageKey);
                chainState.seq += 1;
            }
            const { nextChainKey, messageKey } = await kdfChainKey(chainState.chainKey);
            chainState.chainKey = nextChainKey;
            chainState.seq += 1;
            return await decryptMessageWithKey(envelope.ciphertext, envelope.iv, envelope.tag, messageKey, associatedData);
        }
        // 1-to-1 点对点双棘轮模式
        const cacheKey = `${peerPubB64}:${envelope.sequenceNumber}`;
        if (this.skippedMessageKeys.has(cacheKey)) {
            const messageKey = this.skippedMessageKeys.get(cacheKey);
            this.skippedMessageKeys.delete(cacheKey);
            return await decryptMessageWithKey(envelope.ciphertext, envelope.iv, envelope.tag, messageKey, associatedData);
        }
        if (peerPubB64 !== this.remoteDhPublicKeyB64) {
            if (this.receivingChainKey && this.remoteDhPublicKeyB64) {
                await this.skipMessageKeys(this.remoteDhPublicKeyB64, envelope.previousChainLength);
            }
            this.remoteDhPublicKeyB64 = peerPubB64;
            this.remoteDhPublicKey = await importDhPublicKey(peerPubB64);
            if (!this.localDhKeyPair) {
                throw new Error("本地 DH 密钥对尚未初始化");
            }
            const dhSecretRecv = await computeDhSecret(this.localDhKeyPair.privateKey, this.remoteDhPublicKey);
            const { nextRootKey: rk1, chainKey: recvChainKey } = await kdfRootKey(this.rootKey, dhSecretRecv);
            this.rootKey = rk1;
            this.receivingChainKey = recvChainKey;
            this.previousChainLength = this.sendingSeq;
            this.receivingSeq = 0;
            this.localDhKeyPair = await generateDhKeyPair();
            this.localDhPublicKeyB64 = await exportDhPublicKey(this.localDhKeyPair.publicKey);
            this.cachedFingerprint = await computeFingerprint(this.localDhPublicKeyB64);
            const dhSecretSend = await computeDhSecret(this.localDhKeyPair.privateKey, this.remoteDhPublicKey);
            const { nextRootKey: rk2, chainKey: sendChainKey } = await kdfRootKey(this.rootKey, dhSecretSend);
            this.rootKey = rk2;
            this.sendingChainKey = sendChainKey;
            this.sendingSeq = 0;
        }
        if (this.remoteDhPublicKeyB64) {
            await this.skipMessageKeys(this.remoteDhPublicKeyB64, envelope.sequenceNumber);
        }
        if (!this.receivingChainKey) {
            throw new Error("接收链尚未就绪");
        }
        const { nextChainKey, messageKey } = await kdfChainKey(this.receivingChainKey);
        this.receivingChainKey = nextChainKey;
        this.receivingSeq += 1;
        return await decryptMessageWithKey(envelope.ciphertext, envelope.iv, envelope.tag, messageKey, associatedData);
    }
    saveSkippedMessageKey(keyId, messageKey) {
        const MAX_KEYS = 2000;
        if (this.skippedMessageKeys.size >= MAX_KEYS) {
            const oldestKey = this.skippedMessageKeys.keys().next().value;
            if (oldestKey)
                this.skippedMessageKeys.delete(oldestKey);
        }
        this.skippedMessageKeys.set(keyId, messageKey);
    }
    async skipMessageKeys(pubB64, untilSeq) {
        if (!this.receivingChainKey)
            return;
        const MAX_SKIP = 2000;
        if (this.receivingSeq + MAX_SKIP < untilSeq) {
            throw new Error("跳过的消息数量过多，疑似拒绝服务攻击 (DoS)");
        }
        while (this.receivingSeq < untilSeq) {
            const { nextChainKey, messageKey } = await kdfChainKey(this.receivingChainKey);
            this.receivingChainKey = nextChainKey;
            const keyId = `${pubB64}:${this.receivingSeq}`;
            this.saveSkippedMessageKey(keyId, messageKey);
            this.receivingSeq += 1;
        }
    }
    getFingerprint() {
        if (this.cachedFingerprint)
            return this.cachedFingerprint;
        if (this.remoteDhPublicKeyB64) {
            return this.remoteDhPublicKeyB64.slice(0, 16).toUpperCase();
        }
        return "UNVERIFIED";
    }
    async getSafetyNumber() {
        if (this.cachedFingerprint)
            return this.cachedFingerprint;
        const key = this.localDhPublicKeyB64 ||
            (this.localDhKeyPair
                ? await exportDhPublicKey(this.localDhKeyPair.publicKey)
                : null);
        if (!key)
            return "UNVERIFIED";
        this.cachedFingerprint = await computeFingerprint(key);
        return this.cachedFingerprint;
    }
}
exports.DoubleRatchetSession = DoubleRatchetSession;
function tokenizeText(text) {
    if (!text)
        return [];
    const lower = text.toLowerCase();
    const tokens = [];
    // 匹配英文字词与数字
    const words = lower.match(/[a-z0-9_]+/g) || [];
    tokens.push(...words);
    // 匹配中日韩字符 (CJK Unigrams - 滤除常见单字虚词停用词)
    const cjkChars = lower.match(/[\u4e00-\u9fa5]/g) || [];
    const CJK_STOP_WORDS = new Set([
        "的",
        "了",
        "和",
        "是",
        "就",
        "都",
        "而",
        "及",
        "与",
        "着",
        "在",
        "之",
    ]);
    for (const ch of cjkChars) {
        if (!CJK_STOP_WORDS.has(ch)) {
            tokens.push(ch);
        }
    }
    // 提取 CJK 二元分词 (Bigrams) 用于快速子词精确匹配
    for (let i = 0; i < cjkChars.length - 1; i++) {
        tokens.push(cjkChars[i] + cjkChars[i + 1]);
    }
    return Array.from(new Set(tokens.filter((t) => t.length > 0)));
}
class ClientSideFtsEngine {
    static MAX_DOCUMENTS = 10000;
    documents = new Map();
    docSignatures = new Map();
    invertedIndex = new Map();
    computeSignature(doc) {
        const content = doc.content;
        let hash = 2166136261;
        for (let i = 0; i < content.length; i++) {
            hash ^= content.charCodeAt(i);
            hash = Math.imul(hash, 16777619);
        }
        return `${doc.channelId}\0${content.length}\0${hash >>> 0}`;
    }
    addDocument(doc) {
        const sig = this.computeSignature(doc);
        if (this.docSignatures.get(doc.id) === sig) {
            const existing = this.documents.get(doc.id);
            if (existing) {
                if (existing.content === doc.content && existing.channelId === doc.channelId) {
                    this.documents.delete(doc.id);
                    this.documents.set(doc.id, doc);
                    return;
                }
            }
        }
        this.removeDocument(doc.id);
        if (this.documents.size >= ClientSideFtsEngine.MAX_DOCUMENTS) {
            const oldestId = this.documents.keys().next().value;
            if (oldestId !== undefined) {
                this.removeDocument(oldestId);
            }
        }
        this.documents.set(doc.id, doc);
        this.docSignatures.set(doc.id, sig);
        const tokens = tokenizeText(doc.content);
        for (const token of tokens) {
            let set = this.invertedIndex.get(token);
            if (!set) {
                set = new Set();
                this.invertedIndex.set(token, set);
            }
            set.add(doc.id);
        }
    }
    removeDocument(id) {
        const oldDoc = this.documents.get(id);
        if (!oldDoc)
            return;
        const tokens = tokenizeText(oldDoc.content);
        for (const token of tokens) {
            const set = this.invertedIndex.get(token);
            if (set) {
                set.delete(id);
                if (set.size === 0) {
                    this.invertedIndex.delete(token);
                }
            }
        }
        this.documents.delete(id);
        this.docSignatures.delete(id);
    }
    search(query, filterChannelId) {
        const queryTokens = tokenizeText(query);
        if (queryTokens.length === 0)
            return [];
        const scores = new Map();
        for (const token of queryTokens) {
            const docIds = this.invertedIndex.get(token);
            if (docIds) {
                for (const id of docIds) {
                    scores.set(id, (scores.get(id) || 0) + 1);
                }
            }
        }
        const results = [];
        for (const [id, score] of scores.entries()) {
            const doc = this.documents.get(id);
            if (!doc)
                continue;
            if (filterChannelId && doc.channelId !== filterChannelId)
                continue;
            results.push({ ...doc, score });
        }
        results.sort((a, b) => b.score - a.score);
        return results;
    }
    clear() {
        this.documents.clear();
        this.docSignatures.clear();
        this.invertedIndex.clear();
    }
    get size() {
        return this.documents.size;
    }
}
exports.ClientSideFtsEngine = ClientSideFtsEngine;
exports.SUPPORTED_LOCALES = [
    {
        code: "zh-CN",
        label: "简体中文",
        englishName: "Simplified Chinese",
        nativeName: "简体中文",
    },
    {
        code: "zh-TW",
        label: "繁體中文（台灣）",
        englishName: "Traditional Chinese (Taiwan)",
        nativeName: "繁體中文（台灣）",
    },
    {
        code: "zh-HK",
        label: "繁體中文（香港）",
        englishName: "Traditional Chinese (Hong Kong)",
        nativeName: "繁體中文（香港）",
    },
    {
        code: "en-US",
        label: "English (US)",
        englishName: "English (US)",
        nativeName: "English (US)",
    },
    {
        code: "ja-JP",
        label: "日本語",
        englishName: "Japanese",
        nativeName: "日本語",
    },
];
var ErrorCode;
(function (ErrorCode) {
    // 通用错误
    ErrorCode["INTERNAL_ERROR"] = "INTERNAL_ERROR";
    ErrorCode["AUDIO_INPUT_SWITCH_FAILED"] = "AUDIO_INPUT_SWITCH_FAILED";
    ErrorCode["AUDIO_DEVICE_SWITCH_FAILED"] = "AUDIO_DEVICE_SWITCH_FAILED";
    ErrorCode["AUDIO_DEVICE_UNSUPPORTED"] = "AUDIO_DEVICE_UNSUPPORTED";
    ErrorCode["AUDIO_PROCESSING_UNSUPPORTED"] = "AUDIO_PROCESSING_UNSUPPORTED";
    ErrorCode["INVALID_PARAMS"] = "INVALID_PARAMS";
    ErrorCode["NOT_FOUND"] = "NOT_FOUND";
    ErrorCode["HISTORY_RECOVERY_INVALID"] = "HISTORY_RECOVERY_INVALID";
    ErrorCode["HISTORY_RECOVERY_EXPIRED"] = "HISTORY_RECOVERY_EXPIRED";
    ErrorCode["HISTORY_RECOVERY_CONFLICT"] = "HISTORY_RECOVERY_CONFLICT";
    ErrorCode["HISTORY_RECOVERY_UNAVAILABLE"] = "HISTORY_RECOVERY_UNAVAILABLE";
    ErrorCode["UNAUTHORIZED"] = "UNAUTHORIZED";
    ErrorCode["FORBIDDEN"] = "FORBIDDEN";
    ErrorCode["RATE_LIMITED"] = "RATE_LIMITED";
    ErrorCode["BOT_REVOKED"] = "BOT_REVOKED";
    ErrorCode["BOT_DEVICE_CONFLICT"] = "BOT_DEVICE_CONFLICT";
    ErrorCode["BOT_DEVICE_REVOKED"] = "BOT_DEVICE_REVOKED";
    ErrorCode["INTERACTION_EXPIRED"] = "INTERACTION_EXPIRED";
    ErrorCode["INTERACTION_ALREADY_ACKNOWLEDGED"] = "INTERACTION_ALREADY_ACKNOWLEDGED";
    ErrorCode["MESSAGE_EDIT_CONFLICT"] = "MESSAGE_EDIT_CONFLICT";
    // 认证与用户
    ErrorCode["AUTH_INVALID_CREDENTIALS"] = "AUTH_INVALID_CREDENTIALS";
    ErrorCode["AUTH_TOKEN_EXPIRED"] = "AUTH_TOKEN_EXPIRED";
    ErrorCode["AUTH_USER_NOT_FOUND"] = "AUTH_USER_NOT_FOUND";
    ErrorCode["AUTH_USER_EXISTS"] = "AUTH_USER_EXISTS";
    ErrorCode["AUTH_USERNAME_TAKEN"] = "AUTH_USERNAME_TAKEN";
    ErrorCode["AUTH_EMAIL_TAKEN"] = "AUTH_EMAIL_TAKEN";
    ErrorCode["AUTH_PASSWORD_TOO_WEAK"] = "AUTH_PASSWORD_TOO_WEAK";
    ErrorCode["AUTH_ACCOUNT_DISABLED"] = "AUTH_ACCOUNT_DISABLED";
    ErrorCode["AUTH_ACCOUNT_DELETION_PENDING"] = "AUTH_ACCOUNT_DELETION_PENDING";
    ErrorCode["AUTH_REAUTH_REQUIRED"] = "AUTH_REAUTH_REQUIRED";
    // WebAuthn / 通行密钥 (Passkey)
    ErrorCode["WEBAUTHN_NOT_SUPPORTED"] = "WEBAUTHN_NOT_SUPPORTED";
    ErrorCode["WEBAUTHN_CHALLENGE_EXPIRED"] = "WEBAUTHN_CHALLENGE_EXPIRED";
    ErrorCode["WEBAUTHN_VERIFICATION_FAILED"] = "WEBAUTHN_VERIFICATION_FAILED";
    ErrorCode["WEBAUTHN_CREDENTIAL_EXISTS"] = "WEBAUTHN_CREDENTIAL_EXISTS";
    ErrorCode["WEBAUTHN_CREDENTIAL_NOT_FOUND"] = "WEBAUTHN_CREDENTIAL_NOT_FOUND";
    // 服务器 (Guild)
    ErrorCode["GUILD_NOT_FOUND"] = "GUILD_NOT_FOUND";
    ErrorCode["GUILD_NAME_REQUIRED"] = "GUILD_NAME_REQUIRED";
    ErrorCode["GUILD_PERMISSION_DENIED"] = "GUILD_PERMISSION_DENIED";
    ErrorCode["GUILD_CREATION_RESTRICTED"] = "GUILD_CREATION_RESTRICTED";
    ErrorCode["GUILD_INVITE_INVALID"] = "GUILD_INVITE_INVALID";
    ErrorCode["GUILD_INVITE_EXPIRED"] = "GUILD_INVITE_EXPIRED";
    ErrorCode["GUILD_ALREADY_MEMBER"] = "GUILD_ALREADY_MEMBER";
    ErrorCode["GUILD_CANNOT_LEAVE_OWNER"] = "GUILD_CANNOT_LEAVE_OWNER";
    ErrorCode["GUILD_ROLE_NOT_FOUND"] = "GUILD_ROLE_NOT_FOUND";
    ErrorCode["GUILD_ROLE_CANNOT_DELETE_DEFAULT"] = "GUILD_ROLE_CANNOT_DELETE_DEFAULT";
    ErrorCode["GUILD_ROLE_HIERARCHY_TOO_LOW"] = "GUILD_ROLE_HIERARCHY_TOO_LOW";
    // 频道与分类
    ErrorCode["CHANNEL_NOT_FOUND"] = "CHANNEL_NOT_FOUND";
    ErrorCode["CHANNEL_NAME_REQUIRED"] = "CHANNEL_NAME_REQUIRED";
    ErrorCode["CHANNEL_PERMISSION_DENIED"] = "CHANNEL_PERMISSION_DENIED";
    ErrorCode["CHANNEL_OVERWRITE_NOT_FOUND"] = "CHANNEL_OVERWRITE_NOT_FOUND";
    ErrorCode["CHANNEL_HIERARCHY_VIOLATION"] = "CHANNEL_HIERARCHY_VIOLATION";
    ErrorCode["CATEGORY_NOT_FOUND"] = "CATEGORY_NOT_FOUND";
    ErrorCode["CATEGORY_NAME_REQUIRED"] = "CATEGORY_NAME_REQUIRED";
    // 消息与文件
    ErrorCode["MESSAGE_NOT_FOUND"] = "MESSAGE_NOT_FOUND";
    ErrorCode["MESSAGE_EMPTY"] = "MESSAGE_EMPTY";
    ErrorCode["MESSAGE_TOO_LARGE"] = "MESSAGE_TOO_LARGE";
    ErrorCode["FILE_TOO_LARGE"] = "FILE_TOO_LARGE";
    ErrorCode["FILE_TYPE_UNSUPPORTED"] = "FILE_TYPE_UNSUPPORTED";
    ErrorCode["ICON_PROCESS_TIMEOUT"] = "ICON_PROCESS_TIMEOUT";
    ErrorCode["UPLOAD_FAILED"] = "UPLOAD_FAILED";
    // 自定义表情 (Emoji)
    ErrorCode["EMOJI_NOT_FOUND"] = "EMOJI_NOT_FOUND";
    ErrorCode["EMOJI_LIMIT_REACHED"] = "EMOJI_LIMIT_REACHED";
    ErrorCode["EMOJI_NAME_INVALID"] = "EMOJI_NAME_INVALID";
    ErrorCode["EMOJI_FILE_TOO_LARGE"] = "EMOJI_FILE_TOO_LARGE";
    // 贴纸 (Stickers)
    ErrorCode["STICKER_PACK_NOT_FOUND"] = "STICKER_PACK_NOT_FOUND";
    ErrorCode["STICKER_NOT_FOUND"] = "STICKER_NOT_FOUND";
    ErrorCode["STICKER_PARSE_FAILED"] = "STICKER_PARSE_FAILED";
    ErrorCode["STICKER_URL_INVALID"] = "STICKER_URL_INVALID";
    ErrorCode["STICKER_ALREADY_INSTALLED"] = "STICKER_ALREADY_INSTALLED";
    ErrorCode["STICKER_LIMIT_REACHED"] = "STICKER_LIMIT_REACHED";
    ErrorCode["STICKER_UPSTREAM_UNAVAILABLE"] = "STICKER_UPSTREAM_UNAVAILABLE";
    ErrorCode["TELEGRAM_BOT_TOKEN_REQUIRED"] = "TELEGRAM_BOT_TOKEN_REQUIRED";
    // 语音与媒体
    ErrorCode["MEDIA_E2EE_UNSUPPORTED"] = "MEDIA_E2EE_UNSUPPORTED";
    ErrorCode["MEDIA_KEY_UNAVAILABLE"] = "MEDIA_KEY_UNAVAILABLE";
    ErrorCode["MEDIA_CONTEXT_STALE"] = "MEDIA_CONTEXT_STALE";
    ErrorCode["MEDIA_SESSION_UNAVAILABLE"] = "MEDIA_SESSION_UNAVAILABLE";
    ErrorCode["MEDIA_KEY_INVALID"] = "MEDIA_KEY_INVALID";
    ErrorCode["MEDIA_NEGOTIATION_TIMEOUT"] = "MEDIA_NEGOTIATION_TIMEOUT";
    ErrorCode["VOICE_ROOM_FULL"] = "VOICE_ROOM_FULL";
    ErrorCode["VOICE_JOIN_FAILED"] = "VOICE_JOIN_FAILED";
    ErrorCode["VOICE_PERMISSION_DENIED"] = "VOICE_PERMISSION_DENIED";
    ErrorCode["VOICE_USER_NOT_CONNECTED"] = "VOICE_USER_NOT_CONNECTED";
    ErrorCode["CANNOT_MANAGE_MEMBER"] = "CANNOT_MANAGE_MEMBER";
    // 管理后台
    ErrorCode["ADMIN_REQUIRED"] = "ADMIN_REQUIRED";
    ErrorCode["ADMIN_CANNOT_BAN_SELF"] = "ADMIN_CANNOT_BAN_SELF";
    ErrorCode["ADMIN_CANNOT_DELETE_SELF"] = "ADMIN_CANNOT_DELETE_SELF";
    ErrorCode["ADMIN_PASSWORD_INVALID"] = "ADMIN_PASSWORD_INVALID";
    ErrorCode["DATABASE_BACKUP_FAILED"] = "DATABASE_BACKUP_FAILED";
    ErrorCode["DATABASE_OPTIMIZE_FAILED"] = "DATABASE_OPTIMIZE_FAILED";
    ErrorCode["STORAGE_GC_FAILED"] = "STORAGE_GC_FAILED";
    ErrorCode["OPERATION_CANCELLED"] = "OPERATION_CANCELLED";
})(ErrorCode || (exports.ErrorCode = ErrorCode = {}));
// 消息容量限制契约
exports.MAX_MESSAGE_CONTENT_LENGTH = 4000;
exports.MAX_ENCRYPTED_ENVELOPE_LENGTH = 256 * 1024; // 256KB
function isAdminUpdateUserDTO(value) {
    if (!value || typeof value !== "object" || Array.isArray(value))
        return false;
    const dto = value;
    return ((dto.role === undefined ||
        dto.role === "USER" ||
        dto.role === "ADMIN" ||
        dto.role === "SUPER_ADMIN") &&
        (dto.isBanned === undefined || typeof dto.isBanned === "boolean") &&
        (dto.resetPassword === undefined || typeof dto.resetPassword === "boolean"));
}
function parseTrustedDomains(value) {
    if (!Array.isArray(value) || value.length > 100)
        return null;
    const domains = [];
    for (const domain of value) {
        if (typeof domain !== "string")
            return null;
        const normalized = domain.trim().toLowerCase();
        if (normalized.length > 253 ||
            !normalized
                .split(".")
                .every((label) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label)))
            return null;
        domains.push(normalized);
    }
    return [...new Set(domains)];
}
function isAdminEditUserProfileDTO(value) {
    if (!(0, interactions_js_1.isRecord)(value))
        return false;
    return (Object.keys(value).every((key) => ["email", "username", "displayName", "clearAvatar"].includes(key)) &&
        (value.username === undefined ||
            (typeof value.username === "string" &&
                value.username.trim().length >= 1 &&
                value.username.trim().length <= 80)) &&
        (value.email === undefined ||
            (typeof value.email === "string" &&
                value.email.length <= 254 &&
                /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(value.email.trim()))) &&
        (value.displayName === undefined ||
            value.displayName === null ||
            (typeof value.displayName === "string" &&
                value.displayName.trim().length <= 80)) &&
        (value.clearAvatar === undefined || typeof value.clearAvatar === "boolean"));
}
function isAdminSoftDeleteUserDTO(value) {
    return ((0, interactions_js_1.isRecord)(value) &&
        typeof value.adminPassword === "string" &&
        value.adminPassword.length > 0 &&
        value.adminPassword.length <= 1024 &&
        (value.deleteCreatedBots === undefined ||
            value.deleteCreatedBots === true) &&
        (value.dissolveOwnedGuilds === undefined ||
            value.dissolveOwnedGuilds === true));
}
function isAdminDataPruneDTO(value) {
    return ((0, interactions_js_1.isRecord)(value) &&
        Object.keys(value).every((key) => ["retentionDays", "pruneOrphanDrafts", "pruneRevokedInvites"].includes(key)) &&
        (value.retentionDays === undefined ||
            (typeof value.retentionDays === "number" &&
                Number.isSafeInteger(value.retentionDays) &&
                value.retentionDays >= 1 &&
                value.retentionDays <= 365)) &&
        (value.pruneOrphanDrafts === undefined ||
            typeof value.pruneOrphanDrafts === "boolean") &&
        (value.pruneRevokedInvites === undefined ||
            typeof value.pruneRevokedInvites === "boolean"));
}
function isStorageClearOptions(value) {
    const keys = new Set([
        "clearChromiumCache",
        "clearOfflineMessages",
        "clearAiModels",
        "clearUpdatePackages",
        "vacuumDatabase",
    ]);
    return ((0, interactions_js_1.isRecord)(value) &&
        Object.entries(value).every(([key, flag]) => keys.has(key) && typeof flag === "boolean"));
}
exports.STORAGE_IPC_CHANNELS = {
    PREF_GET: "storage:pref-get",
    PREF_SET: "storage:pref-set",
    PREF_REMOVE: "storage:pref-remove",
    ACCOUNTS_GET: "storage:accounts-get",
    ACCOUNTS_SAVE: "storage:accounts-save",
    TOKENS_GET: "storage:tokens-get",
    TOKENS_SET: "storage:tokens-set",
    TOKENS_CLEAR: "storage:tokens-clear",
    USER_SWITCH: "storage:user-switch",
    MESSAGES_SAVE_BATCH: "storage:messages-save-batch",
    MESSAGES_RECONCILE: "storage:messages-reconcile",
    MESSAGE_SAVE_SINGLE: "storage:message-save-single",
    MESSAGES_GET_LATEST: "storage:messages-get-latest",
    CHANNEL_SNAPSHOT_GET: "storage:channel-snapshot-get",
    MESSAGE_DELETE: "storage:message-delete",
    CHANNEL_META_SAVE: "storage:channel-meta-save",
    CHANNEL_META_GET: "storage:channel-meta-get",
    CHANNEL_CLEAR: "storage:channel-clear",
    MESSAGES_CLEAR_ALL: "storage:messages-clear-all",
    MESSAGES_SEARCH_FTS: "storage:messages-search-fts",
    STATS_GET: "storage:stats-get",
    STATS_DETAILED_GET: "storage:stats-detailed-get",
    CACHE_BATCH_CLEAR: "storage:cache-batch-clear",
    DATABASE_VACUUM: "storage:database-vacuum",
};
__exportStar(require("./communication.js"), exports);
__exportStar(require("./desktop-capture.js"), exports);
__exportStar(require("./media-encryption.js"), exports);
__exportStar(require("./media-frame.js"), exports);
__exportStar(require("./proxy.js"), exports);
__exportStar(require("./voice-routing.js"), exports);
__exportStar(require("./sticker.js"), exports);
//# sourceMappingURL=index.js.map