import { type MessageDeviceIdentity, type SecureMessageEnvelope } from "./message-encryption.js";
export type HistoryRecoveryScope = {
    kind: "all";
} | {
    kind: "channel";
    channelId: string;
};
export type HistoryRecoveryStatus = "pending" | "transferring" | "ready" | "completed" | "cancelled" | "expired";
export interface HistoryRecoveryRequest {
    id: string;
    userId: string;
    target: MessageDeviceIdentity;
    source: MessageDeviceIdentity | null;
    scope: HistoryRecoveryScope;
    codeHash: string;
    nonce: string;
    snapshotAt: string;
    expiresAt: string;
    status: HistoryRecoveryStatus;
    cursor: string | null;
    total: number;
    uploaded: number;
    restored: number;
    skipped: number;
}
export interface HistoryRecoveryMessage {
    id: string;
    channelId: string;
    content: string;
    revision: number;
}
export interface HistoryRecoveryGrant {
    version: 1;
    requestId: string;
    userId: string;
    sourceDeviceId: string;
    sourceFingerprint: string;
    targetDeviceId: string;
    targetFingerprint: string;
    messageId: string;
    channelId: string;
    revision: number;
    envelopeMessageId: string;
    envelopeHash: string;
    sender: MessageDeviceIdentity;
    ephemeralPublicKey: string;
    iv: string;
    ciphertext: string;
    signature: string;
}
export type HistoryRecoveryCommand = {
    op: "create";
    id: string;
    codeHash: string;
    nonce: string;
    scope: HistoryRecoveryScope;
} | {
    op: "list";
} | {
    op: "resolve";
    codeHash: string;
} | {
    op: "approve";
    requestId: string;
    codeHash: string;
} | {
    op: "status" | "cancel" | "history" | "download" | "finish";
    requestId: string;
} | {
    op: "upload";
    requestId: string;
    grants: HistoryRecoveryGrant[];
    cursor: string;
    skipped: number;
} | {
    op: "ack";
    requestId: string;
    results: Array<{
        id: string;
        restored: boolean;
    }>;
} | {
    op: "delete";
    requestIds: string[];
};
export interface HistoryRecoveryUpdatedEvent {
    requestId?: string;
    requestIds?: string[];
    status?: HistoryRecoveryStatus | "deleted";
}
export interface HistoryRecoveryCall {
    userId: string;
    deviceId: string;
    fingerprint: string;
    timestamp: number;
    nonce: string;
    command: HistoryRecoveryCommand;
    signature: string;
}
export interface HistoryRecoveryResponse {
    requests?: HistoryRecoveryRequest[];
    request?: HistoryRecoveryRequest;
    messages?: HistoryRecoveryMessage[];
    cursor?: string | null;
    done?: boolean;
    grants?: Array<{
        id: string;
        grant: HistoryRecoveryGrant;
        message: HistoryRecoveryMessage;
    }>;
    deletedIds?: string[];
}
export declare function validateRecoveryResponse(value: unknown): asserts value is HistoryRecoveryResponse;
export declare const recoveryBytes: (value: string, length?: number) => Uint8Array;
export declare const recoveryBase64: (value: Uint8Array) => string;
export declare function recoveryHash(value: string): Promise<string>;
export declare function recoveryCodeBytes(code: string): Uint8Array;
export declare function createRecoveryCode(): string;
export declare function recoveryCodeHash(code: string): Promise<string>;
export declare function recoveryCallBytes(call: Omit<HistoryRecoveryCall, "signature">): Uint8Array;
export declare function signRecoveryCall(call: Omit<HistoryRecoveryCall, "signature">, key: CryptoKey): Promise<HistoryRecoveryCall>;
export declare function verifyRecoveryCall(call: HistoryRecoveryCall, device: MessageDeviceIdentity): Promise<void>;
export declare function validateRecoveryScope(value: unknown): asserts value is HistoryRecoveryScope;
export declare function validateRecoveryCommand(value: unknown): asserts value is HistoryRecoveryCommand;
export declare function validateRecoveryGrant(value: unknown): asserts value is HistoryRecoveryGrant;
export declare function createRecoveryGrant(request: HistoryRecoveryRequest, message: HistoryRecoveryMessage, envelope: SecureMessageEnvelope, sender: MessageDeviceIdentity, messageKey: Uint8Array, code: string, signingKey: CryptoKey): Promise<HistoryRecoveryGrant>;
export declare function verifyRecoveryGrant(grant: HistoryRecoveryGrant, request: HistoryRecoveryRequest): Promise<void>;
export declare function openRecoveryGrant(grant: HistoryRecoveryGrant, request: HistoryRecoveryRequest, message: HistoryRecoveryMessage, code: string, privateKey: CryptoKey): Promise<Uint8Array>;
//# sourceMappingURL=history-recovery.d.ts.map