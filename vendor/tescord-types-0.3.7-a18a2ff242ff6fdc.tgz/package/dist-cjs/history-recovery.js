"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recoveryBase64 = exports.recoveryBytes = void 0;
exports.validateRecoveryResponse = validateRecoveryResponse;
exports.recoveryHash = recoveryHash;
exports.recoveryCodeBytes = recoveryCodeBytes;
exports.createRecoveryCode = createRecoveryCode;
exports.recoveryCodeHash = recoveryCodeHash;
exports.recoveryCallBytes = recoveryCallBytes;
exports.signRecoveryCall = signRecoveryCall;
exports.verifyRecoveryCall = verifyRecoveryCall;
exports.validateRecoveryScope = validateRecoveryScope;
exports.validateRecoveryCommand = validateRecoveryCommand;
exports.validateRecoveryGrant = validateRecoveryGrant;
exports.createRecoveryGrant = createRecoveryGrant;
exports.verifyRecoveryGrant = verifyRecoveryGrant;
exports.openRecoveryGrant = openRecoveryGrant;
const message_encryption_js_1 = require("./message-encryption.js");
function validateRecoveryResponse(value) {
    if (!record(value))
        return fail();
    const request = (r) => {
        if (!record(r) ||
            !validId(r.id) ||
            !validId(r.userId) ||
            !validId(r.nonce) ||
            !record(r.target) ||
            !(r.source === null || record(r.source)) ||
            ![
                "pending",
                "transferring",
                "ready",
                "completed",
                "cancelled",
                "expired",
            ].includes(String(r.status)) ||
            typeof r.snapshotAt !== "string" ||
            !Number.isFinite(Date.parse(r.snapshotAt)) ||
            typeof r.expiresAt !== "string" ||
            !Number.isFinite(Date.parse(r.expiresAt)) ||
            !(r.cursor === null || typeof r.cursor === "string") ||
            [r.total, r.uploaded, r.restored, r.skipped].some((n) => !Number.isSafeInteger(n) || Number(n) < 0))
            return fail();
        validateRecoveryScope(r.scope);
        (0, exports.recoveryBytes)(r.codeHash, 32);
    };
    const message = (m) => {
        if (!record(m) ||
            !validId(m.id) ||
            !validId(m.channelId) ||
            typeof m.content !== "string" ||
            m.content.length > 256 * 1024 ||
            !Number.isSafeInteger(m.revision) ||
            Number(m.revision) < 0)
            return fail();
    };
    if (value.request !== undefined)
        request(value.request);
    if (value.requests !== undefined) {
        if (!Array.isArray(value.requests) || value.requests.length > 20)
            return fail();
        value.requests.forEach(request);
    }
    if (value.messages !== undefined) {
        if (!Array.isArray(value.messages) || value.messages.length > 100)
            return fail();
        value.messages.forEach(message);
    }
    if (value.grants !== undefined) {
        if (!Array.isArray(value.grants) || value.grants.length > 100)
            return fail();
        value.grants.forEach((g) => {
            if (!record(g) || !validId(g.id))
                return fail();
            validateRecoveryGrant(g.grant);
            message(g.message);
        });
    }
    if (value.deletedIds !== undefined) {
        if (!Array.isArray(value.deletedIds) ||
            value.deletedIds.length > 50 ||
            value.deletedIds.some((id) => !validId(id)))
            return fail();
    }
    if ((value.cursor !== undefined &&
        value.cursor !== null &&
        typeof value.cursor !== "string") ||
        (value.done !== undefined && typeof value.done !== "boolean"))
        return fail();
}
const encoder = new TextEncoder();
const fail = () => {
    throw new Error("HISTORY_RECOVERY_INVALID");
};
const recoveryBytes = (value, length) => {
    if (typeof value !== "string" ||
        value.length > 16384 ||
        !/^[A-Za-z0-9+/]*={0,2}$/.test(value))
        return fail();
    const result = Uint8Array.from(atob(value), (c) => c.charCodeAt(0));
    if (length !== undefined && result.length !== length)
        return fail();
    return result;
};
exports.recoveryBytes = recoveryBytes;
const recoveryBase64 = (value) => btoa(Array.from(value, (b) => String.fromCharCode(b)).join(""));
exports.recoveryBase64 = recoveryBase64;
async function recoveryHash(value) {
    return (0, exports.recoveryBase64)(new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(value))));
}
function recoveryCodeBytes(code) {
    const normalized = code.replace(/[\s-]/g, "").toUpperCase();
    if (!/^[0-9A-F]{32}$/.test(normalized))
        return fail();
    return Uint8Array.from(normalized.match(/../g), (pair) => parseInt(pair, 16));
}
function createRecoveryCode() {
    return Array.from(crypto.getRandomValues(new Uint8Array(16)), (b) => b.toString(16).padStart(2, "0"))
        .join("")
        .toUpperCase()
        .match(/.{8}/g)
        .join("-");
}
const MAX_RECOVERY_CODE_HASH_CACHE = 32;
const recoveryCodeHashCache = new Map();
async function recoveryCodeHash(code) {
    const rawBytes = recoveryCodeBytes(code);
    const normalized = (0, exports.recoveryBase64)(rawBytes);
    const cached = recoveryCodeHashCache.get(normalized);
    if (cached) {
        recoveryCodeHashCache.delete(normalized);
        recoveryCodeHashCache.set(normalized, cached);
        return cached;
    }
    const hashed = await recoveryHash(`tescord-history-code-v1:${normalized}`);
    if (recoveryCodeHashCache.size >= MAX_RECOVERY_CODE_HASH_CACHE) {
        const oldest = recoveryCodeHashCache.keys().next().value;
        if (oldest !== undefined)
            recoveryCodeHashCache.delete(oldest);
    }
    recoveryCodeHashCache.set(normalized, hashed);
    return hashed;
}
function recoveryCallBytes(call) {
    return encoder.encode(JSON.stringify([
        "tescord-history-call-v1",
        call.userId,
        call.deviceId,
        call.fingerprint,
        call.timestamp,
        call.nonce,
        call.command,
    ]));
}
async function signRecoveryCall(call, key) {
    return {
        ...call,
        signature: (0, exports.recoveryBase64)(new Uint8Array(await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, key, recoveryCallBytes(call)))),
    };
}
async function verifyRecoveryCall(call, device) {
    const { verifyKey: key } = await (0, message_encryption_js_1.getValidatedDeviceKeys)(device);
    if (call.userId !== device.userId ||
        call.deviceId !== device.deviceId ||
        call.fingerprint !== device.fingerprint ||
        !Number.isSafeInteger(call.timestamp) ||
        Math.abs(Date.now() - call.timestamp) > 120000 ||
        !validId(call.nonce))
        return fail();
    if (!(await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, key, (0, exports.recoveryBytes)(call.signature, 64), recoveryCallBytes(call))))
        return fail();
}
const validId = (value) => typeof value === "string" && /^[A-Za-z0-9_-]{1,160}$/.test(value);
const record = (value) => !!value && typeof value === "object" && !Array.isArray(value);
function validateRecoveryScope(value) {
    if (!record(value) ||
        !(value.kind === "all" ||
            (value.kind === "channel" && validId(value.channelId))))
        return fail();
}
function validateRecoveryCommand(value) {
    if (!record(value))
        return fail();
    if (value.op === "create") {
        if (!validId(value.id) || !validId(value.nonce))
            return fail();
        (0, exports.recoveryBytes)(value.codeHash, 32);
        validateRecoveryScope(value.scope);
    }
    else if (value.op === "resolve")
        (0, exports.recoveryBytes)(value.codeHash, 32);
    else if (value.op === "delete") {
        if (!Array.isArray(value.requestIds) ||
            value.requestIds.length === 0 ||
            value.requestIds.length > 50 ||
            value.requestIds.some((id) => !validId(id)) ||
            new Set(value.requestIds).size !== value.requestIds.length)
            return fail();
    }
    else if (value.op !== "list") {
        if (!validId(value.requestId))
            return fail();
        if (value.op === "approve")
            (0, exports.recoveryBytes)(value.codeHash, 32);
        else if (value.op === "upload") {
            if (!Array.isArray(value.grants) ||
                value.grants.length > 100 ||
                typeof value.cursor !== "string" ||
                value.cursor.length > 1024 ||
                !Number.isSafeInteger(value.skipped) ||
                Number(value.skipped) < 0)
                return fail();
            value.grants.forEach(validateRecoveryGrant);
        }
        else if (value.op === "ack") {
            if (!Array.isArray(value.results) ||
                value.results.length > 100 ||
                value.results.some((v) => !record(v) || !validId(v.id) || typeof v.restored !== "boolean"))
                return fail();
        }
        else if (![
            "status",
            "approve",
            "cancel",
            "history",
            "download",
            "finish",
        ].includes(String(value.op)))
            return fail();
    }
}
function validateRecoveryGrant(value) {
    if (!record(value) ||
        value.version !== 1 ||
        [
            value.requestId,
            value.userId,
            value.sourceDeviceId,
            value.targetDeviceId,
            value.messageId,
            value.channelId,
            value.envelopeMessageId,
        ].some((id) => !validId(id)) ||
        !Number.isSafeInteger(value.revision) ||
        Number(value.revision) < 0 ||
        !record(value.sender))
        return fail();
    for (const field of ["sourceFingerprint", "targetFingerprint"])
        if (typeof value[field] !== "string" ||
            value[field].length > 128)
            return fail();
    (0, exports.recoveryBytes)(value.envelopeHash, 32);
    (0, exports.recoveryBytes)(value.ephemeralPublicKey, 65);
    (0, exports.recoveryBytes)(value.iv, 12);
    (0, exports.recoveryBytes)(value.ciphertext, 48);
    (0, exports.recoveryBytes)(value.signature, 64);
}
function grantContext(grant, request) {
    return encoder.encode(JSON.stringify([
        "tescord-history-grant-v1",
        request.id,
        request.userId,
        request.codeHash,
        request.nonce,
        request.scope,
        request.snapshotAt,
        request.expiresAt,
        grant.sourceDeviceId,
        grant.sourceFingerprint,
        grant.targetDeviceId,
        grant.targetFingerprint,
        grant.messageId,
        grant.channelId,
        grant.revision,
        grant.envelopeMessageId,
        grant.envelopeHash,
        grant.sender,
    ]));
}
function grantSigningBytes(grant, request) {
    return encoder.encode(JSON.stringify([
        (0, exports.recoveryBase64)(grantContext(grant, request)),
        grant.ephemeralPublicKey,
        grant.iv,
        grant.ciphertext,
    ]));
}
async function grantKey(privateKey, publicKey, code, context) {
    const secret = new Uint8Array(await crypto.subtle.deriveBits({ name: "ECDH", public: publicKey }, privateKey, 256));
    const material = new Uint8Array(48);
    material.set(secret);
    material.set(recoveryCodeBytes(code), 32);
    const input = await crypto.subtle.importKey("raw", material, "HKDF", false, [
        "deriveKey",
    ]);
    material.fill(0);
    secret.fill(0);
    return crypto.subtle.deriveKey({
        name: "HKDF",
        hash: "SHA-256",
        salt: encoder.encode("TescordHistoryRecoveryV1"),
        info: await crypto.subtle.digest("SHA-256", context),
    }, input, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
}
async function createRecoveryGrant(request, message, envelope, sender, messageKey, code, signingKey) {
    if (!request.source ||
        messageKey.length !== 32 ||
        (await recoveryCodeHash(code)) !== request.codeHash)
        return fail();
    const ephemeral = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
    const grant = {
        version: 1,
        requestId: request.id,
        userId: request.userId,
        sourceDeviceId: request.source.deviceId,
        sourceFingerprint: request.source.fingerprint,
        targetDeviceId: request.target.deviceId,
        targetFingerprint: request.target.fingerprint,
        messageId: message.id,
        channelId: message.channelId,
        revision: message.revision,
        envelopeMessageId: envelope.messageId,
        envelopeHash: await recoveryHash(message.content),
        sender,
        ephemeralPublicKey: (0, exports.recoveryBase64)(new Uint8Array(await crypto.subtle.exportKey("raw", ephemeral.publicKey))),
        iv: (0, exports.recoveryBase64)(crypto.getRandomValues(new Uint8Array(12))),
        ciphertext: "",
        signature: "",
    };
    const { agreementPublicKey: target } = await (0, message_encryption_js_1.getValidatedDeviceKeys)(request.target);
    const context = grantContext(grant, request);
    const key = await grantKey(ephemeral.privateKey, target, code, context);
    grant.ciphertext = (0, exports.recoveryBase64)(new Uint8Array(await crypto.subtle.encrypt({
        name: "AES-GCM",
        iv: (0, exports.recoveryBytes)(grant.iv),
        additionalData: context,
    }, key, messageKey)));
    grant.signature = (0, exports.recoveryBase64)(new Uint8Array(await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, signingKey, grantSigningBytes(grant, request))));
    return grant;
}
async function verifyRecoveryGrant(grant, request) {
    validateRecoveryGrant(grant);
    const source = request.source;
    if (!source ||
        grant.requestId !== request.id ||
        grant.userId !== request.userId ||
        source.userId !== request.userId ||
        request.target.userId !== request.userId ||
        grant.sourceDeviceId !== source.deviceId ||
        grant.sourceFingerprint !== source.fingerprint ||
        grant.targetDeviceId !== request.target.deviceId ||
        grant.targetFingerprint !== request.target.fingerprint ||
        (request.scope.kind === "channel" &&
            grant.channelId !== request.scope.channelId))
        return fail();
    const [{ verifyKey: key }] = await Promise.all([
        (0, message_encryption_js_1.getValidatedDeviceKeys)(source),
        (0, message_encryption_js_1.validateMessageDevice)(grant.sender),
    ]);
    if (!(await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, key, (0, exports.recoveryBytes)(grant.signature, 64), grantSigningBytes(grant, request))))
        return fail();
}
async function openRecoveryGrant(grant, request, message, code, privateKey) {
    await verifyRecoveryGrant(grant, request);
    if (grant.messageId !== message.id ||
        grant.channelId !== message.channelId ||
        grant.revision !== message.revision ||
        grant.envelopeHash !== (await recoveryHash(message.content)) ||
        (await recoveryCodeHash(code)) !== request.codeHash)
        return fail();
    const ephemeral = await crypto.subtle.importKey("raw", (0, exports.recoveryBytes)(grant.ephemeralPublicKey, 65), { name: "ECDH", namedCurve: "P-256" }, false, []);
    const context = grantContext(grant, request);
    const key = await grantKey(privateKey, ephemeral, code, context);
    return new Uint8Array(await crypto.subtle.decrypt({ name: "AES-GCM", iv: (0, exports.recoveryBytes)(grant.iv), additionalData: context }, key, (0, exports.recoveryBytes)(grant.ciphertext, 48)));
}
//# sourceMappingURL=history-recovery.js.map