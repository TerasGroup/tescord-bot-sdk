"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TextInputStyle = exports.ButtonStyle = exports.ComponentType = exports.MessageFlags = exports.InteractionResponseType = exports.InteractionType = void 0;
exports.isRecord = isRecord;
exports.validateMessageComponents = validateMessageComponents;
exports.validateInteractionModalData = validateInteractionModalData;
exports.validateBotCommandDefinition = validateBotCommandDefinition;
exports.validateInteractionOptions = validateInteractionOptions;
var InteractionType;
(function (InteractionType) {
    InteractionType[InteractionType["APPLICATION_COMMAND"] = 2] = "APPLICATION_COMMAND";
    InteractionType[InteractionType["MESSAGE_COMPONENT"] = 3] = "MESSAGE_COMPONENT";
    InteractionType[InteractionType["MODAL_SUBMIT"] = 5] = "MODAL_SUBMIT";
})(InteractionType || (exports.InteractionType = InteractionType = {}));
var InteractionResponseType;
(function (InteractionResponseType) {
    InteractionResponseType[InteractionResponseType["CHANNEL_MESSAGE_WITH_SOURCE"] = 4] = "CHANNEL_MESSAGE_WITH_SOURCE";
    InteractionResponseType[InteractionResponseType["DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE"] = 5] = "DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE";
    InteractionResponseType[InteractionResponseType["DEFERRED_UPDATE_MESSAGE"] = 6] = "DEFERRED_UPDATE_MESSAGE";
    InteractionResponseType[InteractionResponseType["UPDATE_MESSAGE"] = 7] = "UPDATE_MESSAGE";
    InteractionResponseType[InteractionResponseType["MODAL"] = 9] = "MODAL";
})(InteractionResponseType || (exports.InteractionResponseType = InteractionResponseType = {}));
exports.MessageFlags = {
    EPHEMERAL: 1 << 6,
    LOADING: 1 << 7,
};
var ComponentType;
(function (ComponentType) {
    ComponentType[ComponentType["ACTION_ROW"] = 1] = "ACTION_ROW";
    ComponentType[ComponentType["BUTTON"] = 2] = "BUTTON";
    ComponentType[ComponentType["STRING_SELECT"] = 3] = "STRING_SELECT";
    ComponentType[ComponentType["TEXT_INPUT"] = 4] = "TEXT_INPUT";
})(ComponentType || (exports.ComponentType = ComponentType = {}));
var ButtonStyle;
(function (ButtonStyle) {
    ButtonStyle[ButtonStyle["PRIMARY"] = 1] = "PRIMARY";
    ButtonStyle[ButtonStyle["SECONDARY"] = 2] = "SECONDARY";
    ButtonStyle[ButtonStyle["SUCCESS"] = 3] = "SUCCESS";
    ButtonStyle[ButtonStyle["DANGER"] = 4] = "DANGER";
    ButtonStyle[ButtonStyle["LINK"] = 5] = "LINK";
})(ButtonStyle || (exports.ButtonStyle = ButtonStyle = {}));
var TextInputStyle;
(function (TextInputStyle) {
    TextInputStyle[TextInputStyle["SHORT"] = 1] = "SHORT";
    TextInputStyle[TextInputStyle["PARAGRAPH"] = 2] = "PARAGRAPH";
})(TextInputStyle || (exports.TextInputStyle = TextInputStyle = {}));
const locales = ["zh-CN", "zh-TW", "zh-HK", "en-US", "ja-JP"];
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isValidComponentEmoji(value) {
    if (!isRecord(value))
        return false;
    const keys = Object.keys(value);
    if (keys.some((k) => k !== "name" && k !== "id"))
        return false;
    if (typeof value.name !== "string" || value.name.length < 1 || value.name.length > 64) {
        return false;
    }
    if (value.id !== undefined && (typeof value.id !== "string" || value.id.length > 64)) {
        return false;
    }
    return true;
}
function validateMessageComponents(value) {
    if (!Array.isArray(value) || value.length > 5) {
        throw new Error("INVALID_PARAMS");
    }
    const customIds = new Set();
    for (const row of value) {
        if (!isRecord(row) ||
            row.type !== ComponentType.ACTION_ROW ||
            !Array.isArray(row.components) ||
            row.components.length < 1 ||
            row.components.length > 5 ||
            Object.keys(row).some((k) => k !== "type" && k !== "components")) {
            throw new Error("INVALID_PARAMS");
        }
        const firstType = isRecord(row.components[0]) ? row.components[0].type : undefined;
        if (firstType === ComponentType.STRING_SELECT &&
            row.components.length !== 1) {
            throw new Error("INVALID_PARAMS");
        }
        for (const comp of row.components) {
            if (!isRecord(comp))
                throw new Error("INVALID_PARAMS");
            if (comp.type === ComponentType.BUTTON) {
                if (firstType !== ComponentType.BUTTON)
                    throw new Error("INVALID_PARAMS");
                if (Object.keys(comp).some((k) => ![
                    "type",
                    "style",
                    "label",
                    "emoji",
                    "customId",
                    "url",
                    "disabled",
                ].includes(k))) {
                    throw new Error("INVALID_PARAMS");
                }
                if (![
                    ButtonStyle.PRIMARY,
                    ButtonStyle.SECONDARY,
                    ButtonStyle.SUCCESS,
                    ButtonStyle.DANGER,
                    ButtonStyle.LINK,
                ].includes(comp.style)) {
                    throw new Error("INVALID_PARAMS");
                }
                const hasLabel = typeof comp.label === "string" &&
                    comp.label.trim().length >= 1 &&
                    comp.label.length <= 80;
                if (comp.label !== undefined && !hasLabel) {
                    throw new Error("INVALID_PARAMS");
                }
                const hasEmoji = comp.emoji !== undefined && isValidComponentEmoji(comp.emoji);
                if (comp.emoji !== undefined && !hasEmoji) {
                    throw new Error("INVALID_PARAMS");
                }
                if (!hasLabel && !hasEmoji) {
                    throw new Error("INVALID_PARAMS");
                }
                if (comp.disabled !== undefined && typeof comp.disabled !== "boolean") {
                    throw new Error("INVALID_PARAMS");
                }
                if (comp.style === ButtonStyle.LINK) {
                    if (comp.customId !== undefined || typeof comp.url !== "string" || comp.url.length > 512) {
                        throw new Error("INVALID_PARAMS");
                    }
                    try {
                        const parsed = new URL(comp.url);
                        if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
                            throw new Error("INVALID_PARAMS");
                        }
                    }
                    catch {
                        throw new Error("INVALID_PARAMS");
                    }
                }
                else {
                    if (comp.url !== undefined ||
                        typeof comp.customId !== "string" ||
                        comp.customId.length < 1 ||
                        comp.customId.length > 100 ||
                        customIds.has(comp.customId)) {
                        throw new Error("INVALID_PARAMS");
                    }
                    customIds.add(comp.customId);
                }
            }
            else if (comp.type === ComponentType.STRING_SELECT) {
                if (Object.keys(comp).some((k) => ![
                    "type",
                    "customId",
                    "options",
                    "placeholder",
                    "minValues",
                    "maxValues",
                    "disabled",
                ].includes(k))) {
                    throw new Error("INVALID_PARAMS");
                }
                if (typeof comp.customId !== "string" ||
                    comp.customId.length < 1 ||
                    comp.customId.length > 100 ||
                    customIds.has(comp.customId)) {
                    throw new Error("INVALID_PARAMS");
                }
                customIds.add(comp.customId);
                if (comp.placeholder !== undefined &&
                    (typeof comp.placeholder !== "string" || comp.placeholder.length > 150)) {
                    throw new Error("INVALID_PARAMS");
                }
                if (comp.disabled !== undefined && typeof comp.disabled !== "boolean") {
                    throw new Error("INVALID_PARAMS");
                }
                if (!Array.isArray(comp.options) ||
                    comp.options.length < 1 ||
                    comp.options.length > 25) {
                    throw new Error("INVALID_PARAMS");
                }
                const minValues = comp.minValues ?? 1;
                const maxValues = comp.maxValues ?? 1;
                if (typeof minValues !== "number" ||
                    typeof maxValues !== "number" ||
                    !Number.isSafeInteger(minValues) ||
                    !Number.isSafeInteger(maxValues) ||
                    minValues < 0 ||
                    minValues > 25 ||
                    maxValues < 1 ||
                    maxValues > 25 ||
                    minValues > maxValues ||
                    maxValues > comp.options.length) {
                    throw new Error("INVALID_PARAMS");
                }
                const optionValues = new Set();
                for (const opt of comp.options) {
                    if (!isRecord(opt) ||
                        Object.keys(opt).some((k) => !["label", "value", "description", "emoji", "default"].includes(k)) ||
                        typeof opt.label !== "string" ||
                        opt.label.trim().length < 1 ||
                        opt.label.length > 100 ||
                        typeof opt.value !== "string" ||
                        opt.value.length < 1 ||
                        opt.value.length > 100 ||
                        optionValues.has(opt.value)) {
                        throw new Error("INVALID_PARAMS");
                    }
                    optionValues.add(opt.value);
                    if (opt.description !== undefined &&
                        (typeof opt.description !== "string" || opt.description.length > 100)) {
                        throw new Error("INVALID_PARAMS");
                    }
                    if (opt.emoji !== undefined && !isValidComponentEmoji(opt.emoji)) {
                        throw new Error("INVALID_PARAMS");
                    }
                    if (opt.default !== undefined && typeof opt.default !== "boolean") {
                        throw new Error("INVALID_PARAMS");
                    }
                }
            }
            else {
                throw new Error("INVALID_PARAMS");
            }
        }
    }
}
function validateInteractionModalData(value) {
    if (!isRecord(value) ||
        Object.keys(value).some((k) => !["customId", "title", "components"].includes(k)) ||
        typeof value.customId !== "string" ||
        value.customId.length < 1 ||
        value.customId.length > 100 ||
        typeof value.title !== "string" ||
        value.title.trim().length < 1 ||
        value.title.length > 45 ||
        !Array.isArray(value.components) ||
        value.components.length < 1 ||
        value.components.length > 5) {
        throw new Error("INVALID_PARAMS");
    }
    const fieldIds = new Set();
    for (const row of value.components) {
        if (!isRecord(row) ||
            row.type !== ComponentType.ACTION_ROW ||
            !Array.isArray(row.components) ||
            row.components.length !== 1 ||
            Object.keys(row).some((k) => k !== "type" && k !== "components")) {
            throw new Error("INVALID_PARAMS");
        }
        const field = row.components[0];
        if (!isRecord(field) ||
            field.type !== ComponentType.TEXT_INPUT ||
            Object.keys(field).some((k) => ![
                "type",
                "customId",
                "style",
                "label",
                "minLength",
                "maxLength",
                "required",
                "value",
                "placeholder",
            ].includes(k)) ||
            typeof field.customId !== "string" ||
            field.customId.length < 1 ||
            field.customId.length > 100 ||
            fieldIds.has(field.customId) ||
            ![TextInputStyle.SHORT, TextInputStyle.PARAGRAPH].includes(field.style) ||
            typeof field.label !== "string" ||
            field.label.trim().length < 1 ||
            field.label.length > 45) {
            throw new Error("INVALID_PARAMS");
        }
        fieldIds.add(field.customId);
        const minLen = field.minLength ?? 0;
        const maxLen = field.maxLength ?? 4000;
        if (typeof minLen !== "number" ||
            typeof maxLen !== "number" ||
            !Number.isSafeInteger(minLen) ||
            !Number.isSafeInteger(maxLen) ||
            minLen < 0 ||
            minLen > 4000 ||
            maxLen < 1 ||
            maxLen > 4000 ||
            minLen > maxLen) {
            throw new Error("INVALID_PARAMS");
        }
        if (field.required !== undefined && typeof field.required !== "boolean") {
            throw new Error("INVALID_PARAMS");
        }
        if (field.value !== undefined &&
            (typeof field.value !== "string" || field.value.length > maxLen)) {
            throw new Error("INVALID_PARAMS");
        }
        if (field.placeholder !== undefined &&
            (typeof field.placeholder !== "string" || field.placeholder.length > 100)) {
            throw new Error("INVALID_PARAMS");
        }
    }
}
function validateBotCommandDefinition(value) {
    if (!isRecord(value))
        throw new Error("INVALID_PARAMS");
    const name = (v) => typeof v === "string" && /^[\p{L}\p{N}_-]{1,32}$/u.test(v);
    const description = (v) => typeof v === "string" && v.length >= 1 && v.length <= 100;
    const choiceLabel = (v) => typeof v === "string" && v.trim().length >= 1 && v.length <= 100;
    const localized = (v, valid) => isRecord(v) &&
        Object.keys(v).length === locales.length &&
        locales.every((locale) => valid(v[locale]));
    const base = (v) => name(v.name) &&
        description(v.description) &&
        localized(v.nameLocalizations, name) &&
        localized(v.descriptionLocalizations, description);
    if (!base(value) ||
        typeof value.ephemeral !== "boolean" ||
        !Array.isArray(value.options) ||
        value.options.length > 25)
        throw new Error("INVALID_PARAMS");
    const names = new Set();
    for (const option of value.options) {
        if (!isRecord(option) ||
            !base(option) ||
            typeof option.required !== "boolean" ||
            ![
                "string",
                "integer",
                "number",
                "boolean",
                "user",
                "channel",
                "attachment",
            ].includes(String(option.type)) ||
            names.has(String(option.name)))
            throw new Error("INVALID_PARAMS");
        if (option.choices !== undefined) {
            if (!["string", "integer", "number"].includes(String(option.type)) ||
                !Array.isArray(option.choices) ||
                option.choices.length < 1 ||
                option.choices.length > 25) {
                throw new Error("INVALID_PARAMS");
            }
            const choiceValues = new Set();
            for (const choice of option.choices) {
                if (!isRecord(choice) ||
                    !choiceLabel(choice.name) ||
                    (choice.nameLocalizations !== undefined &&
                        !localized(choice.nameLocalizations, choiceLabel))) {
                    throw new Error("INVALID_PARAMS");
                }
                if (option.type === "string") {
                    if (typeof choice.value !== "string" ||
                        choice.value.length < 1 ||
                        choice.value.length > 100) {
                        throw new Error("INVALID_PARAMS");
                    }
                }
                else if (option.type === "integer") {
                    if (!Number.isSafeInteger(choice.value)) {
                        throw new Error("INVALID_PARAMS");
                    }
                }
                else if (option.type === "number") {
                    if (typeof choice.value !== "number" || !Number.isFinite(choice.value)) {
                        throw new Error("INVALID_PARAMS");
                    }
                }
                if (choiceValues.has(choice.value)) {
                    throw new Error("INVALID_PARAMS");
                }
                choiceValues.add(choice.value);
            }
        }
        names.add(String(option.name));
    }
}
function validateInteractionOptions(command, value) {
    if (!isRecord(value) ||
        Object.keys(value).some((key) => !command.options.some((option) => option.name === key)))
        throw new Error("INVALID_PARAMS");
    for (const option of command.options) {
        const item = value[option.name];
        if (item === undefined && !option.required)
            continue;
        if (option.type === "boolean"
            ? typeof item !== "boolean"
            : option.type === "integer"
                ? !Number.isSafeInteger(item)
                : option.type === "number"
                    ? typeof item !== "number" || !Number.isFinite(item)
                    : typeof item !== "string" || !item.length || item.length > 4000)
            throw new Error("INVALID_PARAMS");
        if (option.choices &&
            option.choices.length > 0 &&
            !option.choices.some((choice) => choice.value === item)) {
            throw new Error("INVALID_PARAMS");
        }
    }
}
//# sourceMappingURL=interactions.js.map