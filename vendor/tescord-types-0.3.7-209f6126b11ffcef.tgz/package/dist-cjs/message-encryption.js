"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.messageDeviceFingerprint = messageDeviceFingerprint;
exports.validateMessageDevice = validateMessageDevice;
exports.validateSecureMessageEnvelope = validateSecureMessageEnvelope;
exports.encryptSecureMessage = encryptSecureMessage;
exports.verifySecureMessageSignature = verifySecureMessageSignature;
exports.decryptSecureMessage = decryptSecureMessage;
const enc = new TextEncoder();
const b64 = (bytes) => {
    let binary = "";
    for (const byte of bytes)
        binary += String.fromCharCode(byte);
    return btoa(binary);
};
const bytes = (value, maximum) => {
    if (typeof value !== "string" ||
        value.length > Math.ceil(maximum / 3) * 4 ||
        !/^[A-Za-z0-9+/]*={0,2}$/.test(value))
        throw new Error("MESSAGE_ENVELOPE_INVALID");
    const result = Uint8Array.from(atob(value), (char) => char.charCodeAt(0));
    if (result.byteLength > maximum)
        throw new Error("MESSAGE_ENVELOPE_TOO_LARGE");
    return result;
};
const publicJwk = (value) => {
    if (typeof value !== "string" || value.length > 2048)
        throw new Error("DEVICE_KEY_INVALID");
    const jwk = JSON.parse(value);
    if (jwk.kty !== "EC" ||
        jwk.crv !== "P-256" ||
        typeof jwk.x !== "string" ||
        typeof jwk.y !== "string" ||
        jwk.d !== undefined)
        throw new Error("DEVICE_KEY_INVALID");
    return jwk;
};
async function messageDeviceFingerprint(signingPublicKey, agreementPublicKey) {
    const digest = await crypto.subtle.digest("SHA-256", enc.encode(JSON.stringify({
        signingPublicJwk: publicJwk(signingPublicKey),
        agreementPublicJwk: publicJwk(agreementPublicKey),
    })));
    return b64(new Uint8Array(digest))
        .replace(/\+/g, "-")
        .replace(/\//g, "_")
        .replace(/=+$/g, "");
}
async function validateMessageDevice(device) {
    if (!device.userId ||
        !device.deviceId ||
        device.userId.length > 160 ||
        device.deviceId.length > 160 ||
        (await messageDeviceFingerprint(device.signingPublicKey, device.agreementPublicKey)) !== device.fingerprint)
        throw new Error("DEVICE_FINGERPRINT_INVALID");
    await Promise.all([
        crypto.subtle.importKey("jwk", publicJwk(device.signingPublicKey), { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]),
        crypto.subtle.importKey("jwk", publicJwk(device.agreementPublicKey), { name: "ECDH", namedCurve: "P-256" }, false, []),
    ]);
}
const header = (envelope) => [
    "tescord-message-v2",
    envelope.channelId,
    envelope.senderId,
    envelope.senderDeviceId,
    envelope.messageId,
    ...(envelope.context ? [envelope.context] : []),
];
const signed = (envelope) => enc.encode(JSON.stringify([
    header(envelope),
    envelope.senderSigningPublicKey,
    envelope.senderAgreementPublicKey,
    envelope.fingerprint,
    envelope.iv,
    envelope.ciphertext,
    envelope.recipients,
]));
const recipientContext = (envelope, recipient) => enc.encode(JSON.stringify([
    ...header(envelope),
    recipient.userId,
    recipient.deviceId,
    recipient.fingerprint,
]));
async function wrappingKey(privateKey, publicKey, context, usages) {
    const secret = await crypto.subtle.deriveBits({ name: "ECDH", public: publicKey }, privateKey, 256);
    const material = await crypto.subtle.importKey("raw", secret, "HKDF", false, [
        "deriveKey",
    ]);
    return crypto.subtle.deriveKey({
        name: "HKDF",
        hash: "SHA-256",
        salt: enc.encode("TescordMessageEnvelopeV2"),
        info: context,
    }, material, { name: "AES-GCM", length: 256 }, false, usages);
}
function validateSecureMessageEnvelope(value) {
    const envelope = value;
    if (envelope?.context !== undefined) {
        const context = envelope.context;
        if (!context ||
            !Number.isSafeInteger(context.revision) ||
            context.revision < 0 ||
            (context.purpose === "edit"
                ? typeof context.messageId !== "string" ||
                    !context.messageId ||
                    context.messageId.length > 160
                : !["interaction", "ephemeral"].includes(context.purpose) ||
                    [
                        context.interactionId,
                        context.commandId,
                        context.botId,
                        context.callerId,
                    ].some((id) => typeof id !== "string" || !id || id.length > 160) ||
                    typeof context.ephemeral !== "boolean"))
            throw new Error("MESSAGE_ENVELOPE_INVALID");
    }
    if (!envelope ||
        envelope.version !== 2 ||
        JSON.stringify(envelope).length > 256 * 1024 ||
        !Array.isArray(envelope.recipients) ||
        envelope.recipients.length < 1 ||
        envelope.recipients.length > 100)
        throw new Error("MESSAGE_ENVELOPE_INVALID");
    for (const field of [
        envelope.channelId,
        envelope.senderId,
        envelope.senderDeviceId,
        envelope.messageId,
    ])
        if (typeof field !== "string" || !field || field.length > 160)
            throw new Error("MESSAGE_ENVELOPE_INVALID");
    publicJwk(envelope.senderSigningPublicKey);
    publicJwk(envelope.senderAgreementPublicKey);
    if (bytes(envelope.iv, 12).length !== 12 ||
        bytes(envelope.signature, 64).length !== 64 ||
        bytes(envelope.ciphertext, 32 * 1024).length < 16)
        throw new Error("MESSAGE_ENVELOPE_INVALID");
    const targets = new Set();
    for (const recipient of envelope.recipients) {
        if (!recipient ||
            typeof recipient.userId !== "string" ||
            !recipient.userId ||
            recipient.userId.length > 160 ||
            typeof recipient.deviceId !== "string" ||
            !recipient.deviceId ||
            recipient.deviceId.length > 160 ||
            typeof recipient.fingerprint !== "string" ||
            recipient.fingerprint.length > 128)
            throw new Error("MESSAGE_ENVELOPE_INVALID");
        const target = JSON.stringify([recipient.userId, recipient.deviceId]);
        if (targets.has(target))
            throw new Error("MESSAGE_ENVELOPE_DUPLICATE_RECIPIENT");
        targets.add(target);
        if (bytes(recipient.ephemeralPublicKey, 65).length !== 65 ||
            bytes(recipient.iv, 12).length !== 12 ||
            bytes(recipient.ciphertext, 48).length !== 48)
            throw new Error("MESSAGE_ENVELOPE_INVALID");
    }
}
async function encryptSecureMessage(channelId, plaintext, sender, signingPrivateKey, recipients, context) {
    if (typeof plaintext !== "string" ||
        plaintext.length > 4000 ||
        enc.encode(plaintext).length > 16000 ||
        recipients.length < 1 ||
        recipients.length > 100)
        throw new Error("MESSAGE_TOO_LARGE_OR_RECIPIENTS_UNAVAILABLE");
    await validateMessageDevice(sender);
    if (!recipients.some((device) => device.userId === sender.userId && device.deviceId === sender.deviceId))
        throw new Error("MESSAGE_SELF_DEVICE_MISSING");
    const keyBytes = crypto.getRandomValues(new Uint8Array(32));
    const messageKey = await crypto.subtle.importKey("raw", keyBytes, "AES-GCM", false, ["encrypt"]);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const envelope = {
        ...(context ? { context } : {}),
        version: 2,
        channelId,
        senderId: sender.userId,
        senderDeviceId: sender.deviceId,
        messageId: crypto.randomUUID(),
        senderSigningPublicKey: sender.signingPublicKey,
        senderAgreementPublicKey: sender.agreementPublicKey,
        fingerprint: sender.fingerprint,
        iv: b64(iv),
        ciphertext: "",
        recipients: [],
        signature: "",
    };
    envelope.ciphertext = b64(new Uint8Array(await crypto.subtle.encrypt({
        name: "AES-GCM",
        iv,
        additionalData: enc.encode(JSON.stringify(header(envelope))),
    }, messageKey, enc.encode(plaintext))));
    for (const recipient of recipients) {
        await validateMessageDevice(recipient);
        const ephemeral = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
        const remote = await crypto.subtle.importKey("jwk", publicJwk(recipient.agreementPublicKey), { name: "ECDH", namedCurve: "P-256" }, false, []);
        const context = recipientContext(envelope, recipient);
        const wrap = await wrappingKey(ephemeral.privateKey, remote, context, [
            "encrypt",
        ]);
        const recipientIv = crypto.getRandomValues(new Uint8Array(12));
        envelope.recipients.push({
            userId: recipient.userId,
            deviceId: recipient.deviceId,
            fingerprint: recipient.fingerprint,
            ephemeralPublicKey: b64(new Uint8Array(await crypto.subtle.exportKey("raw", ephemeral.publicKey))),
            iv: b64(recipientIv),
            ciphertext: b64(new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: recipientIv, additionalData: context }, wrap, keyBytes))),
        });
    }
    envelope.signature = b64(new Uint8Array(await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, signingPrivateKey, signed(envelope))));
    validateSecureMessageEnvelope(envelope);
    return envelope;
}
async function verifySecureMessageSignature(envelope, expectedSender) {
    validateSecureMessageEnvelope(envelope);
    await validateMessageDevice(expectedSender);
    if (envelope.senderId !== expectedSender.userId ||
        envelope.senderDeviceId !== expectedSender.deviceId ||
        envelope.senderSigningPublicKey !== expectedSender.signingPublicKey ||
        envelope.senderAgreementPublicKey !== expectedSender.agreementPublicKey ||
        envelope.fingerprint !== expectedSender.fingerprint)
        throw new Error("MESSAGE_SENDER_IDENTITY_CHANGED");
    const signing = await crypto.subtle.importKey("jwk", publicJwk(expectedSender.signingPublicKey), { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
    if (!(await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, signing, bytes(envelope.signature, 64), signed(envelope))))
        throw new Error("MESSAGE_SIGNATURE_INVALID");
}
async function decryptSecureMessage(envelope, channelId, local, agreementPrivateKey, expectedSender) {
    await verifySecureMessageSignature(envelope, expectedSender);
    await validateMessageDevice(local);
    if (envelope.channelId !== channelId)
        throw new Error("MESSAGE_SENDER_IDENTITY_CHANGED");
    const recipient = envelope.recipients.find((item) => item.userId === local.userId &&
        item.deviceId === local.deviceId &&
        item.fingerprint === local.fingerprint);
    if (!recipient)
        throw new Error("MESSAGE_NOT_FOR_THIS_DEVICE");
    const ephemeral = await crypto.subtle.importKey("raw", bytes(recipient.ephemeralPublicKey, 65), { name: "ECDH", namedCurve: "P-256" }, false, []);
    const context = recipientContext(envelope, recipient);
    const wrap = await wrappingKey(agreementPrivateKey, ephemeral, context, [
        "decrypt",
    ]);
    const keyBytes = await crypto.subtle.decrypt({ name: "AES-GCM", iv: bytes(recipient.iv, 12), additionalData: context }, wrap, bytes(recipient.ciphertext, 48));
    const key = await crypto.subtle.importKey("raw", keyBytes, "AES-GCM", false, [
        "decrypt",
    ]);
    const plaintext = await crypto.subtle.decrypt({
        name: "AES-GCM",
        iv: bytes(envelope.iv, 12),
        additionalData: enc.encode(JSON.stringify(header(envelope))),
    }, key, bytes(envelope.ciphertext, 32 * 1024));
    return new TextDecoder().decode(plaintext);
}
//# sourceMappingURL=message-encryption.js.map