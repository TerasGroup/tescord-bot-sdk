import type { BotLocalizations } from "./bot.js";
export declare enum InteractionType {
    APPLICATION_COMMAND = 2,
    MESSAGE_COMPONENT = 3,
    MODAL_SUBMIT = 5
}
export declare enum InteractionResponseType {
    CHANNEL_MESSAGE_WITH_SOURCE = 4,
    DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE = 5,
    DEFERRED_UPDATE_MESSAGE = 6,
    UPDATE_MESSAGE = 7,
    MODAL = 9
}
export declare const MessageFlags: {
    readonly EPHEMERAL: number;
    readonly LOADING: number;
};
export declare enum ComponentType {
    ACTION_ROW = 1,
    BUTTON = 2,
    STRING_SELECT = 3,
    TEXT_INPUT = 4
}
export declare enum ButtonStyle {
    PRIMARY = 1,
    SECONDARY = 2,
    SUCCESS = 3,
    DANGER = 4,
    LINK = 5
}
export declare enum TextInputStyle {
    SHORT = 1,
    PARAGRAPH = 2
}
export interface ComponentEmoji {
    name: string;
    id?: string;
}
export interface ButtonComponent {
    type: ComponentType.BUTTON;
    style: ButtonStyle;
    label?: string;
    emoji?: ComponentEmoji;
    customId?: string;
    url?: string;
    disabled?: boolean;
}
export interface StringSelectOption {
    label: string;
    value: string;
    description?: string;
    emoji?: ComponentEmoji;
    default?: boolean;
}
export interface StringSelectComponent {
    type: ComponentType.STRING_SELECT;
    customId: string;
    options: StringSelectOption[];
    placeholder?: string;
    minValues?: number;
    maxValues?: number;
    disabled?: boolean;
}
export type MessageItemComponent = ButtonComponent | StringSelectComponent;
export interface MessageActionRow {
    type: ComponentType.ACTION_ROW;
    components: MessageItemComponent[];
}
export interface TextInputComponent {
    type: ComponentType.TEXT_INPUT;
    customId: string;
    style: TextInputStyle;
    label: string;
    minLength?: number;
    maxLength?: number;
    required?: boolean;
    value?: string;
    placeholder?: string;
}
export interface ModalActionRow {
    type: ComponentType.ACTION_ROW;
    components: [TextInputComponent];
}
export interface InteractionModalData {
    customId: string;
    title: string;
    components: ModalActionRow[];
}
export type BotCommandOptionType = "string" | "integer" | "number" | "boolean" | "user" | "channel" | "attachment";
export interface BotCommandOptionChoice {
    name: string;
    nameLocalizations?: BotLocalizations;
    value: string | number;
}
export interface BotCommandOption {
    name: string;
    description: string;
    nameLocalizations: BotLocalizations;
    descriptionLocalizations: BotLocalizations;
    type: BotCommandOptionType;
    required: boolean;
    choices?: BotCommandOptionChoice[];
}
export interface BotCommandDefinition {
    name: string;
    description: string;
    nameLocalizations: BotLocalizations;
    descriptionLocalizations: BotLocalizations;
    options: BotCommandOption[];
    ephemeral: boolean;
}
export interface BotCommand extends BotCommandDefinition {
    id: string;
    applicationId: string;
    botUserId: string;
    botName: string;
}
export interface MessageInteractionMetadata {
    id: string;
    type: InteractionType;
    commandId?: string;
    commandName?: string;
    userId: string;
    username: string;
    displayName?: string | null;
    avatarUrl?: string | null;
    botId: string;
    botName: string;
}
export type InteractionOptions = Record<string, string | number | boolean>;
export type InteractionInput = {
    isEncrypted: false;
    options: InteractionOptions;
} | {
    isEncrypted: true;
    content: string;
};
export type CreateCommandInteractionDTO = InteractionInput & {
    id: string;
    type?: InteractionType.APPLICATION_COMMAND;
    commandId: string;
};
export type CreateComponentInteractionDTO = {
    id: string;
    type: InteractionType.MESSAGE_COMPONENT;
    messageId: string;
    ephemeralMessage?: boolean;
    componentType: ComponentType.BUTTON | ComponentType.STRING_SELECT;
    customId: string;
    values?: string[];
    isEncrypted: boolean;
    content?: string;
};
export type CreateModalSubmitInteractionDTO = {
    id: string;
    type: InteractionType.MODAL_SUBMIT;
    modalInteractionId: string;
    customId: string;
    fields?: Record<string, string>;
    isEncrypted: boolean;
    content?: string;
};
export type CreateInteractionDTO = CreateCommandInteractionDTO | CreateComponentInteractionDTO | CreateModalSubmitInteractionDTO;
export interface InteractionCallerInfo {
    id: string;
    username: string;
    displayName?: string | null;
    avatarUrl?: string | null;
}
export type InteractionCreatePayload = {
    id: string;
    type?: InteractionType;
    command: BotCommand;
    channelId: string;
    callerId: string;
    caller?: InteractionCallerInfo;
    applicationId: string;
    ephemeral: boolean;
    expiresAt: string;
    sequence: number;
    isEncrypted: boolean;
    options?: InteractionOptions;
    content?: string;
    messageId?: string;
    ephemeralMessage?: boolean;
    componentType?: ComponentType.BUTTON | ComponentType.STRING_SELECT;
    customId?: string;
    values?: string[];
    modalInteractionId?: string;
    fields?: Record<string, string>;
};
export type InteractionResponseDTO = {
    type: "defer" | InteractionResponseType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE;
    flags?: number;
    ephemeral?: boolean;
} | {
    type: "defer_update" | InteractionResponseType.DEFERRED_UPDATE_MESSAGE;
} | {
    type: "message" | InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE;
    content: string;
    isEncrypted: boolean;
    components?: MessageActionRow[];
    flags?: number;
    ephemeral?: boolean;
} | {
    type: "update_message" | InteractionResponseType.UPDATE_MESSAGE;
    content: string;
    isEncrypted: boolean;
    components?: MessageActionRow[];
} | {
    type: "modal" | InteractionResponseType.MODAL;
    modal: InteractionModalData;
};
export interface EphemeralMessage {
    id: string;
    interactionId: string;
    channelId: string;
    authorId: string;
    authorName: string;
    authorAvatarUrl?: string | null;
    content: string;
    isEncrypted: boolean;
    components?: MessageActionRow[];
    interaction?: MessageInteractionMetadata;
    revision: number;
    createdAt: string;
}
export interface InteractionThinkingPayload {
    id: string;
    channelId: string;
    ephemeral: boolean;
    interaction: MessageInteractionMetadata;
    createdAt: string;
}
export interface InteractionModalPayload {
    interactionId: string;
    channelId: string;
    applicationId: string;
    botId: string;
    botName: string;
    commandId: string;
    isEncrypted: boolean;
    modal: InteractionModalData;
}
export interface EphemeralDeletePayload {
    id: string;
    interactionId: string;
    channelId: string;
}
export declare function isRecord(value: unknown): value is Record<string, unknown>;
export declare function validateMessageComponents(value: unknown): asserts value is MessageActionRow[];
export declare function validateInteractionModalData(value: unknown): asserts value is InteractionModalData;
export declare function validateBotCommandDefinition(value: unknown): asserts value is BotCommandDefinition;
export declare function validateInteractionOptions(command: BotCommandDefinition, value: unknown): asserts value is InteractionOptions;
//# sourceMappingURL=interactions.d.ts.map