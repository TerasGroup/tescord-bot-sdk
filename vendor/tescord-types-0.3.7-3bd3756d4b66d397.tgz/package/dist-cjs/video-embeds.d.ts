export type VideoEmbedDescriptor = {
    provider: "youtube";
    videoId: string;
    startSeconds?: number;
} | {
    provider: "bilibili";
    videoId: string;
    startSeconds?: number;
    page?: number;
};
export declare function isVideoEmbedDescriptor(value: unknown): value is VideoEmbedDescriptor;
export declare function parseVideoUrl(input: string): VideoEmbedDescriptor | null;
export declare function getCanonicalVideoUrl(video: VideoEmbedDescriptor): string;
export declare function getVideoEmbedUrl(video: VideoEmbedDescriptor): string;
export declare function isVideoThumbnailUrl(input: unknown, provider: VideoEmbedDescriptor["provider"]): input is string;
//# sourceMappingURL=video-embeds.d.ts.map