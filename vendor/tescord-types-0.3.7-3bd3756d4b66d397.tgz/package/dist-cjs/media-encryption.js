"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MEDIA_SESSION_RECOVERY_MS = exports.MEDIA_ENCRYPTION_VERSION = void 0;
exports.resolveMediaEncryptionPolicy = resolveMediaEncryptionPolicy;
exports.isMediaEncryptionSyncRequest = isMediaEncryptionSyncRequest;
exports.isMediaEncryptionSyncResult = isMediaEncryptionSyncResult;
exports.mediaStreamEnvelopeSigningBytes = mediaStreamEnvelopeSigningBytes;
const index_js_1 = require("./index.js");
exports.MEDIA_ENCRYPTION_VERSION = 3;
exports.MEDIA_SESSION_RECOVERY_MS = 30_000;
function resolveMediaEncryptionPolicy(channel) {
    if (channel.type === "DM" || channel.type === "GROUP_DM")
        return "e2ee";
    if (channel.type === "VOICE" && typeof channel.isE2EE === "boolean")
        return channel.isE2EE ? "e2ee" : "transport";
    throw new Error("MEDIA_CONTEXT_STALE");
}
function isMediaEncryptionSyncRequest(value) {
    if (!value || typeof value !== "object")
        return false;
    const data = value;
    return (data.version === exports.MEDIA_ENCRYPTION_VERSION &&
        [
            "requestId",
            "channelId",
            "deviceId",
            "gatewaySessionId",
            "registrationId",
        ].every((key) => typeof data[key] === "string" &&
            data[key].length > 0 &&
            data[key].length <= 160) &&
        (data.callId === undefined ||
            (typeof data.callId === "string" &&
                data.callId.length > 0 &&
                data.callId.length <= 160)));
}
/** Validate transport shape before any snapshot reaches the crypto state machine. */
function isMediaEncryptionSyncResult(value) {
    if (!value || typeof value !== "object")
        return false;
    const data = value;
    if (!["requestId", "channelId", "registrationId"].every((key) => typeof data[key] === "string" &&
        data[key].length > 0 &&
        data[key].length <= 160))
        return false;
    if (data.success === false)
        return Object.values(index_js_1.ErrorCode).includes(data.code);
    if (data.success !== true ||
        !data.snapshot ||
        typeof data.snapshot !== "object")
        return false;
    const snapshot = data.snapshot;
    if (!snapshot.context || typeof snapshot.context !== "object")
        return false;
    const context = snapshot.context;
    const strings = (entry, fields) => Boolean(entry &&
        typeof entry === "object" &&
        fields.every((key) => typeof entry[key] === "string" &&
            entry[key].length > 0));
    const integer = (entry) => typeof entry === "number" && Number.isSafeInteger(entry) && entry > 0;
    return (context.version === exports.MEDIA_ENCRYPTION_VERSION &&
        strings(context, [
            "contextId",
            "channelId",
            "membershipVersion",
            "expiresAt",
        ]) &&
        (context.callId === undefined || typeof context.callId === "string") &&
        integer(context.contextRevision) &&
        typeof context.complete === "boolean" &&
        Array.isArray(context.devices) &&
        context.devices.every((device) => strings(device, [
            "userId",
            "deviceId",
            "gatewaySessionId",
            "registrationId",
            "signingPublicKey",
            "agreementPublicKey",
            "fingerprint",
        ])) &&
        Array.isArray(snapshot.acknowledgedKeyIds) &&
        snapshot.acknowledgedKeyIds.every(integer) &&
        (snapshot.acknowledgedRecipients === undefined ||
            (Array.isArray(snapshot.acknowledgedRecipients) &&
                snapshot.acknowledgedRecipients.every((entry) => Boolean(entry && typeof entry === "object") &&
                    integer(entry.keyId) &&
                    Array.isArray(entry.recipients) &&
                    entry.recipients.every((recipient) => strings(recipient, ["userId", "deviceId"]))))) &&
        Array.isArray(snapshot.envelopes) &&
        snapshot.envelopes.every((entry) => {
            if (!entry || typeof entry !== "object")
                return false;
            const envelope = entry;
            return (envelope.version === exports.MEDIA_ENCRYPTION_VERSION &&
                integer(envelope.contextRevision) &&
                integer(envelope.keyId) &&
                strings(envelope, [
                    "contextId",
                    "membershipVersion",
                    "streamId",
                    "senderId",
                    "senderDeviceId",
                    "recipientId",
                    "recipientDeviceId",
                    "ephemeralPublicKey",
                    "iv",
                    "ciphertext",
                    "signature",
                    "createdAt",
                ]));
        }));
}
/** Canonical signed bytes: no delimiter ambiguity or implementation-local ordering. */
function mediaStreamEnvelopeSigningBytes(envelope) {
    return new TextEncoder().encode(JSON.stringify([
        envelope.version,
        envelope.contextId,
        envelope.membershipVersion,
        envelope.contextRevision,
        envelope.streamId,
        envelope.keyId,
        envelope.senderId,
        envelope.senderDeviceId,
        envelope.recipientId,
        envelope.recipientDeviceId,
        envelope.ephemeralPublicKey,
        envelope.iv,
        envelope.ciphertext,
        envelope.createdAt,
    ]));
}
//# sourceMappingURL=media-encryption.js.map