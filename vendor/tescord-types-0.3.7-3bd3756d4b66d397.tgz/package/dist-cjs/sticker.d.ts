export type StickerFormat = "webp" | "tgs" | "webm";
export declare const STICKER_NAME_PATTERN = "[a-zA-Z0-9_]{2,64}";
export declare const STICKER_ID_PATTERN = "[a-zA-Z0-9_-]{1,128}";
export declare const STICKER_TOKEN_REGEX_SOURCE = "<s:([a-zA-Z0-9_]{2,64}):([a-zA-Z0-9_-]{1,128})>";
export declare const STICKER_PACK_URL_REGEX_SOURCE = "(?:https?:\\/\\/(?:t\\.me|telegram\\.me)\\/addstickers\\/[a-zA-Z0-9_]{2,64}|https?:\\/\\/(?:www\\.)?sigstick\\.com\\/pack\\/[a-zA-Z0-9_-]{10,64})(?![a-zA-Z0-9_-])";
export declare function normalizeStickerName(raw: string, fallback?: string): string;
export type StickerItemsBatchResponse = StickerItem[];
export interface StickerItem {
    id: string;
    packId: string;
    name: string;
    emojis: string[];
    format: StickerFormat;
    mediaUrl: string;
    thumbnailUrl?: string;
    width: number;
    height: number;
    sortOrder: number;
}
export interface StickerPack {
    id: string;
    name: string;
    title: string;
    thumbnailUrl: string;
    format: StickerFormat;
    stickersCount: number;
    sourceType: "telegram" | "sigstick" | "custom";
    sourceUrl?: string;
    stickers?: StickerItem[];
    createdAt: string;
}
export interface UserStickerPackMeta {
    packId: string;
    installedAt: string;
    sortOrder: number;
    pack: StickerPack;
}
export interface StickerPreviewItem {
    id: string;
    name: string;
    emojis: string[];
    format: StickerFormat;
    previewUrl: string;
}
export interface StickerPreviewResponse {
    name: string;
    title: string;
    format: StickerFormat;
    thumbnailUrl: string;
    stickersCount: number;
    stickers: StickerPreviewItem[];
}
export interface ImportStickerPackDTO {
    url: string;
}
export interface ReorderStickerPacksDTO {
    packIds: string[];
}
export type StickerAutoplayMode = "always" | "hover" | "off";
//# sourceMappingURL=sticker.d.ts.map