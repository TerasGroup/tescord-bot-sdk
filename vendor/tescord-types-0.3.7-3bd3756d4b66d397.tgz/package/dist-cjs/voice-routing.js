"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VOICE_ROUTING_EVENTS = exports.VALID_SUPPORTED_CHANNEL_VOICE_MODES = void 0;
exports.isChannelVoiceMode = isChannelVoiceMode;
exports.voicePathScore = voicePathScore;
exports.VALID_SUPPORTED_CHANNEL_VOICE_MODES = [
    "sfu",
    "p2p_mesh",
    "p2p_relay",
    "hybrid",
];
exports.VOICE_ROUTING_EVENTS = {
    QUALITY_REPORT: "VOICE_QUALITY_REPORT",
    QUALITY_UPDATE: "VOICE_QUALITY_UPDATE",
    ROUTES_UPDATE: "VOICE_ROUTES_UPDATE",
    MODE_CHANGED: "VOICE_MODE_CHANGED",
};
function isChannelVoiceMode(value) {
    return exports.VALID_SUPPORTED_CHANNEL_VOICE_MODES.some((mode) => mode === value);
}
function voicePathScore(quality) {
    if (!quality.ready ||
        quality.latencyMs === undefined ||
        quality.packetLossPercent === undefined ||
        quality.jitterMs === undefined)
        return null;
    const values = [
        quality.latencyMs,
        quality.packetLossPercent,
        quality.jitterMs,
        quality.concealmentPercent ?? 0,
        quality.processingMs ?? 0,
    ];
    if (values.some((value) => !Number.isFinite(value) || value < 0))
        return null;
    return (quality.latencyMs +
        (quality.processingMs ?? 0) +
        40 * quality.packetLossPercent +
        2 * quality.jitterMs +
        20 * (quality.concealmentPercent ?? 0));
}
//# sourceMappingURL=voice-routing.js.map