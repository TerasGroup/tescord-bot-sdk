export type ProxyMode = "system" | "direct" | "custom";
export type ProxyProtocol = "http" | "https" | "socks5";
export interface ProxyConfig {
    mode: ProxyMode;
    protocol: ProxyProtocol;
    host: string;
    port: number;
    authEnabled?: boolean;
    username?: string;
    password?: string;
    bypassRules?: string;
}
export interface ProxyTestResult {
    success: boolean;
    latencyMs?: number;
    error?: string;
}
export declare const PROXY_IPC_CHANNELS: {
    readonly GET_SETTINGS: "proxy:get-settings";
    readonly SET_SETTINGS: "proxy:set-settings";
    readonly TEST_CONNECTION: "proxy:test-connection";
};
export type ProxyIpcChannel = (typeof PROXY_IPC_CHANNELS)[keyof typeof PROXY_IPC_CHANNELS];
export declare const DEFAULT_PROXY_BYPASS_RULES = "<local>,127.0.0.1,localhost";
export declare const DEFAULT_PROXY_CONFIG: ProxyConfig;
//# sourceMappingURL=proxy.d.ts.map