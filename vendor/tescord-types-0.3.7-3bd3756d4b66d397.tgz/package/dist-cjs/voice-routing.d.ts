export declare const VALID_SUPPORTED_CHANNEL_VOICE_MODES: readonly ["sfu", "p2p_mesh", "p2p_relay", "hybrid"];
export type ChannelVoiceMode = (typeof VALID_SUPPORTED_CHANNEL_VOICE_MODES)[number];
export declare const VOICE_ROUTING_EVENTS: {
    readonly QUALITY_REPORT: "VOICE_QUALITY_REPORT";
    readonly QUALITY_UPDATE: "VOICE_QUALITY_UPDATE";
    readonly ROUTES_UPDATE: "VOICE_ROUTES_UPDATE";
    readonly MODE_CHANGED: "VOICE_MODE_CHANGED";
};
export interface VoiceRoutingCapabilities {
    version: 1;
    supportedModes: ChannelVoiceMode[];
}
export interface VoicePathQuality {
    latencyMs?: number;
    packetLossPercent?: number;
    jitterMs?: number;
    concealmentPercent?: number;
    processingMs?: number;
    bitrate?: number;
    ready: boolean;
}
export interface VoiceLinkQualitySample extends VoicePathQuality {
    sourceId: string;
    path: "p2p" | "sfu";
}
export interface VoiceQualityReportPayload {
    channelId: string;
    samples: VoiceLinkQualitySample[];
    uplink?: VoicePathQuality;
    availableOutgoingBitrate?: number;
}
export interface VoiceQualityUpdatePayload extends VoiceQualityReportPayload {
    reporterId: string;
    observedAt: number;
}
export interface VoiceRelayRoute {
    routeId: string;
    revision: number;
    channelId: string;
    sourceId: string;
    relayId: string;
    targetId: string;
    sourceSessionId: string;
    relaySessionId: string;
    targetSessionId: string;
}
export interface VoiceRoutesUpdatePayload {
    channelId: string;
    revision: number;
    routes: VoiceRelayRoute[];
}
export interface VoiceModeChangedPayload {
    channelId: string;
    voiceMode: ChannelVoiceMode;
    isE2EE: boolean;
}
export declare function isChannelVoiceMode(value: unknown): value is ChannelVoiceMode;
export declare function voicePathScore(quality: VoicePathQuality): number | null;
//# sourceMappingURL=voice-routing.d.ts.map