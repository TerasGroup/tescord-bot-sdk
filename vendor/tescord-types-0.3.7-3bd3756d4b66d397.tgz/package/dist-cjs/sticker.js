"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.STICKER_PACK_URL_REGEX_SOURCE = exports.STICKER_TOKEN_REGEX_SOURCE = exports.STICKER_ID_PATTERN = exports.STICKER_NAME_PATTERN = void 0;
exports.normalizeStickerName = normalizeStickerName;
exports.STICKER_NAME_PATTERN = "[a-zA-Z0-9_]{2,64}";
exports.STICKER_ID_PATTERN = "[a-zA-Z0-9_-]{1,128}";
exports.STICKER_TOKEN_REGEX_SOURCE = `<s:(${exports.STICKER_NAME_PATTERN}):(${exports.STICKER_ID_PATTERN})>`;
exports.STICKER_PACK_URL_REGEX_SOURCE = "(?:https?:\\/\\/(?:t\\.me|telegram\\.me)\\/addstickers\\/[a-zA-Z0-9_]{2,64}|https?:\\/\\/(?:www\\.)?sigstick\\.com\\/pack\\/[a-zA-Z0-9_-]{10,64})(?![a-zA-Z0-9_-])";
function normalizeStickerName(raw, fallback = "sticker") {
    const cleaned = raw.replace(/[^a-zA-Z0-9_]+/g, "_").replace(/^_+|_+$/g, "");
    const base = cleaned.length >= 2 ? cleaned : `${fallback}_${cleaned || "1"}`;
    return base.slice(0, 64);
}
//# sourceMappingURL=sticker.js.map