/** Codec routing headers remain visible and are authenticated as SFrame metadata.
 * The encrypted payload is an RFC 9605 packet; H26x ciphertext uses RBSP escaping
 * so the WebRTC packetizer cannot mistake random ciphertext for NAL boundaries. */
export interface EncodedFrameLayout {
    header: Uint8Array;
    payload: Uint8Array;
    rbsp: boolean;
    wrapper?: boolean;
}
export type MediaTransformControl = {
    type: "sender-key";
    keyId: number;
    key: Uint8Array;
    generation: number;
} | {
    type: "receiver-key";
    keyId: number;
    key: Uint8Array;
    requestId?: number;
} | {
    type: "expire-key";
    keyId: number;
} | {
    type: "pause" | "resume" | "clear-keys";
} | {
    type: "codecs";
    codecs: {
        payloadType: number;
        mimeType: string;
    }[];
};
export type MediaTransformEvent = {
    type: "key-missing";
    keyId: number;
} | {
    type: "key-installed";
    requestId: number;
} | {
    type: "stats";
    encrypted: number;
    decrypted: number;
    replay: number;
} | {
    type: "fatal";
    error: string;
} | {
    type: "codecs-needed";
};
export declare function encodedFrameLayout(data: Uint8Array, kind: "audio" | "video", codec?: string, frameType?: string, decoding?: boolean): EncodedFrameLayout;
export declare function escapeMediaRbsp(data: Uint8Array): Uint8Array;
export declare function unescapeMediaRbsp(data: Uint8Array): Uint8Array;
export declare function joinMediaFrame(header: Uint8Array, payload: Uint8Array): Uint8Array;
//# sourceMappingURL=media-frame.d.ts.map