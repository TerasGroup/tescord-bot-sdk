"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_PROXY_CONFIG = exports.DEFAULT_PROXY_BYPASS_RULES = exports.PROXY_IPC_CHANNELS = void 0;
exports.PROXY_IPC_CHANNELS = {
    GET_SETTINGS: "proxy:get-settings",
    SET_SETTINGS: "proxy:set-settings",
    TEST_CONNECTION: "proxy:test-connection",
};
exports.DEFAULT_PROXY_BYPASS_RULES = "<local>,127.0.0.1,localhost";
exports.DEFAULT_PROXY_CONFIG = {
    mode: "system",
    protocol: "http",
    host: "127.0.0.1",
    port: 7890,
    authEnabled: false,
    username: "",
    password: "",
    bypassRules: exports.DEFAULT_PROXY_BYPASS_RULES,
};
//# sourceMappingURL=proxy.js.map