import { ErrorCode } from "./index.js";
export declare const MEDIA_ENCRYPTION_VERSION: 3;
export declare const MEDIA_SESSION_RECOVERY_MS = 30000;
export type MediaEncryptionPolicy = "e2ee" | "transport";
export interface MediaPolicyResponse {
    channelId: string;
    policy: MediaEncryptionPolicy;
}
export declare function resolveMediaEncryptionPolicy(channel: {
    type: string;
    isE2EE?: boolean | null;
}): MediaEncryptionPolicy;
export interface MediaRecoveryDiagnostic {
    channelId: string;
    peerId: string;
    trackId?: string;
    generation: number;
    stage: "playback" | "track" | "ice" | "rebuild" | "exhausted";
}
export type MediaEncryptionPhase = "negotiating" | "ready" | "active" | "failed";
export interface MediaEncryptionDevice {
    userId: string;
    deviceId: string;
    gatewaySessionId: string;
    registrationId: string;
    signingPublicKey: string;
    agreementPublicKey: string;
    fingerprint: string;
}
export interface MediaEncryptionJoinRequest {
    version: typeof MEDIA_ENCRYPTION_VERSION;
    deviceId: string;
    gatewaySessionId: string;
    registrationId: string;
    callId?: string;
}
export interface MediaEncryptionContext {
    version: typeof MEDIA_ENCRYPTION_VERSION;
    contextId: string;
    channelId: string;
    callId?: string;
    membershipVersion: string;
    contextRevision: number;
    devices: MediaEncryptionDevice[];
    expiresAt: string;
    complete: boolean;
}
export interface MediaStreamKeyEnvelope {
    version: typeof MEDIA_ENCRYPTION_VERSION;
    contextId: string;
    membershipVersion: string;
    contextRevision: number;
    streamId: string;
    keyId: number;
    senderId: string;
    senderDeviceId: string;
    recipientId: string;
    recipientDeviceId: string;
    ephemeralPublicKey: string;
    iv: string;
    ciphertext: string;
    signature: string;
    createdAt: string;
}
export interface MediaStreamKeyPublishRequest {
    contextId: string;
    membershipVersion: string;
    contextRevision: number;
    streamId: string;
    keyId: number;
    envelopes: MediaStreamKeyEnvelope[];
}
export interface MediaStreamKeyAcknowledgeRequest {
    contextId: string;
    membershipVersion: string;
    contextRevision: number;
    keyId: number;
}
export interface MediaKeyRecipient {
    userId: string;
    deviceId: string;
}
export interface MediaSenderRecipient {
    userId: string;
    deviceId?: string;
}
export interface MediaStreamKeyPublishResult {
    acknowledged: boolean;
    acknowledgedRecipients?: MediaKeyRecipient[];
}
export interface MediaKeyRecipientAcknowledgement {
    keyId: number;
    recipients: MediaKeyRecipient[];
}
export interface MediaEncryptionSnapshot {
    context: MediaEncryptionContext;
    envelopes: MediaStreamKeyEnvelope[];
    acknowledgedKeyIds: number[];
    acknowledgedRecipients?: MediaKeyRecipientAcknowledgement[];
}
/** Only the identified connection's own login and Gateway session may sync. */
export interface MediaEncryptionSyncRequest extends MediaEncryptionJoinRequest {
    requestId: string;
    channelId: string;
}
export type MediaEncryptionSyncResult = {
    requestId: string;
    channelId: string;
    registrationId: string;
} & ({
    success: true;
    snapshot: MediaEncryptionSnapshot;
} | {
    success: false;
    code: ErrorCode;
});
export declare function isMediaEncryptionSyncRequest(value: unknown): value is MediaEncryptionSyncRequest;
/** Validate transport shape before any snapshot reaches the crypto state machine. */
export declare function isMediaEncryptionSyncResult(value: unknown): value is MediaEncryptionSyncResult;
/** Canonical signed bytes: no delimiter ambiguity or implementation-local ordering. */
export declare function mediaStreamEnvelopeSigningBytes(envelope: Omit<MediaStreamKeyEnvelope, "signature">): Uint8Array;
export interface MediaEncryptionState {
    phase: MediaEncryptionPhase;
    contextId: string | null;
    membershipVersion: string | null;
    errorCode?: string;
    framesEncrypted: number;
    framesDecrypted: number;
}
/** Percentages use 0..100 across P2P/SFU and all presentation layers. */
export interface AudioReceiveQuality {
    trackId: string;
    timestamp: number;
    intervalMs: number;
    packetsReceived: number;
    packetsLost: number;
    packetLossPercent?: number;
    jitterMs?: number;
    jitterBufferDelayMs?: number;
    concealedSamples: number;
    concealmentPercent?: number;
    bytesReceived: number;
    receiverBufferTargetMs?: number;
}
export interface MediaKeyEnvelopePushPayload {
    channelId: string;
    callId?: string;
    contextId: string;
    membershipVersion: string;
    contextRevision: number;
    envelope: MediaStreamKeyEnvelope;
}
export interface MediaKeyAckPushPayload {
    channelId: string;
    callId?: string;
    contextId: string;
    membershipVersion: string;
    contextRevision: number;
    keyId: number;
    acknowledged: boolean;
    recipient?: MediaKeyRecipient;
}
export interface MediaEpochUpdatePushPayload {
    channelId: string;
    callId?: string;
    context: MediaEncryptionContext;
}
export interface MediaMemberLeftPushPayload {
    channelId: string;
    callId?: string;
    userId: string;
    deviceId: string;
    contextId?: string;
    contextRevision?: number;
}
export interface MediaKeyResyncRequestPayload {
    channelId: string;
    callId?: string;
    targetSenderId: string;
    targetSenderDeviceId?: string;
    contextId?: string;
    contextRevision?: number;
    keyId?: number;
    streamId?: string;
}
export type MediaJoinStage = "joinStarted" | "deviceRegistered" | "contextReady" | "keyPublished" | "keyAcknowledged" | "senderKeyReady" | "iceReady" | "published" | "subscribed" | "connected" | "firstPlayableAudio";
/** Durations from startedAt, in milliseconds; never interpreted as media latency. */
export interface MediaJoinTimingTrace {
    channelId: string;
    operationEpoch: number;
    startedAt: number;
    stages: Partial<Record<MediaJoinStage, number>>;
}
//# sourceMappingURL=media-encryption.d.ts.map