"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isVideoEmbedDescriptor = isVideoEmbedDescriptor;
exports.parseVideoUrl = parseVideoUrl;
exports.getCanonicalVideoUrl = getCanonicalVideoUrl;
exports.getVideoEmbedUrl = getVideoEmbedUrl;
exports.isVideoThumbnailUrl = isVideoThumbnailUrl;
const YOUTUBE_ID = /^[A-Za-z0-9_-]{11}$/;
const BILIBILI_ID = /^(?:BV[A-Za-z0-9]{10}|av[1-9][0-9]{0,19})$/;
function positiveInteger(value, minimum = 0) {
    return (typeof value === "number" && Number.isSafeInteger(value) && value >= minimum);
}
function isVideoEmbedDescriptor(value) {
    if (!value || typeof value !== "object")
        return false;
    const video = value;
    if (video.startSeconds !== undefined && !positiveInteger(video.startSeconds))
        return false;
    if (typeof video.videoId !== "string")
        return false;
    if (video.provider === "youtube")
        return YOUTUBE_ID.test(video.videoId) && video.page === undefined;
    return (video.provider === "bilibili" &&
        BILIBILI_ID.test(video.videoId) &&
        (video.page === undefined || positiveInteger(video.page, 1)));
}
function parseTime(value) {
    if (!value)
        return undefined;
    if (/^\d+$/.test(value)) {
        const seconds = Number(value);
        return positiveInteger(seconds) ? seconds : undefined;
    }
    const match = /^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?$/.exec(value);
    if (!match || !match.slice(1).some(Boolean))
        return undefined;
    const seconds = Number(match[1] || 0) * 3600 +
        Number(match[2] || 0) * 60 +
        Number(match[3] || 0);
    return positiveInteger(seconds) ? seconds : undefined;
}
function parseVideoUrl(input) {
    try {
        const url = new URL(input);
        if (!["http:", "https:"].includes(url.protocol) ||
            url.username ||
            url.password ||
            url.port)
            return null;
        const host = url.hostname;
        const startSeconds = parseTime(url.searchParams.get("t")) ??
            parseTime(url.searchParams.get("start")) ??
            parseTime(new URLSearchParams(url.hash.slice(1)).get("t"));
        const time = startSeconds === undefined ? {} : { startSeconds };
        if ([
            "youtube.com",
            "www.youtube.com",
            "m.youtube.com",
            "www.youtube-nocookie.com",
        ].includes(host) ||
            host === "youtu.be") {
            const videoId = host === "youtu.be"
                ? /^\/([A-Za-z0-9_-]{11})\/?$/.exec(url.pathname)?.[1]
                : url.pathname === "/watch"
                    ? url.searchParams.get("v")
                    : /^\/(?:shorts|embed)\/([A-Za-z0-9_-]{11})\/?$/.exec(url.pathname)?.[1];
            return videoId && YOUTUBE_ID.test(videoId)
                ? { provider: "youtube", videoId, ...time }
                : null;
        }
        if (["bilibili.com", "www.bilibili.com", "m.bilibili.com"].includes(host)) {
            const videoId = /^\/video\/((?:BV[A-Za-z0-9]{10}|av[1-9][0-9]{0,19}))\/?$/.exec(url.pathname)?.[1];
            if (!videoId)
                return null;
            const page = Number(url.searchParams.get("p"));
            return {
                provider: "bilibili",
                videoId,
                ...time,
                ...(positiveInteger(page, 1) ? { page } : {}),
            };
        }
    }
    catch { }
    return null;
}
function getCanonicalVideoUrl(video) {
    const url = new URL(video.provider === "youtube"
        ? `https://www.youtube.com/watch?v=${video.videoId}`
        : `https://www.bilibili.com/video/${video.videoId}`);
    if (video.startSeconds)
        url.searchParams.set("t", String(video.startSeconds));
    if (video.provider === "bilibili" && video.page)
        url.searchParams.set("p", String(video.page));
    return url.toString();
}
function getVideoEmbedUrl(video) {
    if (!isVideoEmbedDescriptor(video))
        throw new TypeError("Invalid video descriptor");
    const url = new URL(video.provider === "youtube"
        ? `https://www.youtube-nocookie.com/embed/${video.videoId}`
        : "https://player.bilibili.com/player.html");
    url.searchParams.set("autoplay", "1");
    if (video.provider === "youtube") {
        url.searchParams.set("playsinline", "1");
        if (video.startSeconds)
            url.searchParams.set("start", String(video.startSeconds));
    }
    else {
        url.searchParams.set(video.videoId.startsWith("BV") ? "bvid" : "aid", video.videoId.replace(/^av/, ""));
        if (video.startSeconds)
            url.searchParams.set("t", String(video.startSeconds));
        if (video.page)
            url.searchParams.set("p", String(video.page));
    }
    return url.toString();
}
function isVideoThumbnailUrl(input, provider) {
    if (typeof input !== "string" || input.length > 2048)
        return false;
    try {
        const url = new URL(input);
        return (url.protocol === "https:" &&
            !url.username &&
            !url.password &&
            !url.port &&
            (provider === "youtube"
                ? url.hostname === "i.ytimg.com"
                : /^i[0-2]\.hdslb\.com$/.test(url.hostname)));
    }
    catch {
        return false;
    }
}
//# sourceMappingURL=video-embeds.js.map