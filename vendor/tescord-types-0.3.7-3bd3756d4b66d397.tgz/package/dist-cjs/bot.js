"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BOT_MAX_CONTEXT_LIMIT = exports.CHANNEL_MENTION_TOKEN_REGEX_SOURCE = exports.USER_MENTION_TOKEN_REGEX_SOURCE = exports.TYPING_TIMEOUT_MS = exports.BOT_TYPING_INTERVAL_MS = exports.BOT_DEFAULT_CONTEXT_LIMIT = void 0;
exports.formatChannelMention = formatChannelMention;
exports.extractChannelMentionIds = extractChannelMentionIds;
exports.resolveGuildChannelMention = resolveGuildChannelMention;
exports.formatChannelMentionsForReader = formatChannelMentionsForReader;
exports.replaceChannelNamesWithTokens = replaceChannelNamesWithTokens;
exports.isUpdateIntegrationSettingsDTO = isUpdateIntegrationSettingsDTO;
exports.applyMessageUpdate = applyMessageUpdate;
exports.isContextLimit = isContextLimit;
exports.effectiveContextLimit = effectiveContextLimit;
exports.BOT_DEFAULT_CONTEXT_LIMIT = 5;
exports.BOT_TYPING_INTERVAL_MS = 3000;
exports.TYPING_TIMEOUT_MS = 7000;
exports.USER_MENTION_TOKEN_REGEX_SOURCE = "<@!?([A-Za-z0-9_-]{1,160})>";
exports.CHANNEL_MENTION_TOKEN_REGEX_SOURCE = "<#([A-Za-z0-9_-]{1,160})>";
exports.BOT_MAX_CONTEXT_LIMIT = 100;
function formatChannelMention(channelId) {
    return `<#${channelId}>`;
}
function extractChannelMentionIds(text) {
    const ids = [];
    const regex = new RegExp(exports.CHANNEL_MENTION_TOKEN_REGEX_SOURCE, "g");
    for (const match of text.matchAll(regex)) {
        if (match[1])
            ids.push(match[1]);
    }
    return ids;
}
function isGuildMentionableChannel(channel) {
    return channel.type === "TEXT" || channel.type === "VOICE";
}
function disambiguateChannelMatches(matches) {
    if (matches.length === 1)
        return matches[0];
    if (matches.length > 1) {
        const textChannels = matches.filter((item) => item.type === "TEXT");
        if (textChannels.length === 1)
            return textChannels[0];
    }
    return undefined;
}
function resolveGuildChannelMention(channels, query) {
    const trimmed = query.trim();
    if (!trimmed)
        return undefined;
    const tokenMatch = new RegExp(`^${exports.CHANNEL_MENTION_TOKEN_REGEX_SOURCE}$`).exec(trimmed);
    if (tokenMatch?.[1]) {
        return channels.find((item) => item.id === tokenMatch[1]);
    }
    const normalizedQuery = trimmed.startsWith("#") ? trimmed.slice(1) : trimmed;
    if (!normalizedQuery)
        return undefined;
    const mentionable = channels.filter(isGuildMentionableChannel);
    const exactCase = disambiguateChannelMatches(mentionable.filter((item) => item.name === normalizedQuery));
    if (exactCase)
        return exactCase;
    const lower = normalizedQuery.toLowerCase();
    const ignoreCase = disambiguateChannelMatches(mentionable.filter((item) => item.name.toLowerCase() === lower));
    if (ignoreCase)
        return ignoreCase;
    if (!trimmed.startsWith("#")) {
        return channels.find((item) => item.id === trimmed);
    }
    return undefined;
}
function formatChannelMentionsForReader(text, channels) {
    if (!text || !text.includes("<#") || !channels.length)
        return text;
    const byId = new Map(channels.map((item) => [item.id, item]));
    const regex = new RegExp(exports.CHANNEL_MENTION_TOKEN_REGEX_SOURCE, "g");
    return text.replace(regex, (token, id, offset) => {
        const channel = byId.get(id);
        if (!channel?.name)
            return token;
        const expectedPrefix = `#${channel.name} (`;
        if (offset >= expectedPrefix.length &&
            text.slice(offset - expectedPrefix.length, offset) === expectedPrefix &&
            text[offset + token.length] === ")") {
            return token;
        }
        return `#${channel.name} (${token})`;
    });
}
function escapeRegExp(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function buildUnambiguousChannelNameMap(channels) {
    const mentionable = channels.filter((item) => isGuildMentionableChannel(item) && item.name.trim().length > 0);
    const byLower = new Map();
    const byExact = new Map();
    for (const ch of mentionable) {
        const lower = ch.name.toLowerCase();
        const listLower = byLower.get(lower);
        if (listLower)
            listLower.push(ch);
        else
            byLower.set(lower, [ch]);
        const listExact = byExact.get(ch.name);
        if (listExact)
            listExact.push(ch);
        else
            byExact.set(ch.name, [ch]);
    }
    const result = new Map();
    for (const [lower, items] of byLower) {
        const resolved = disambiguateChannelMatches(items);
        if (resolved) {
            result.set(lower, resolved);
        }
        else {
            for (const item of items) {
                const exactItems = byExact.get(item.name) ?? [];
                const exactResolved = disambiguateChannelMatches(exactItems);
                if (exactResolved && exactItems.length !== items.length) {
                    result.set(`exact:${item.name}`, exactResolved);
                }
            }
        }
    }
    return result;
}
const OUTBOUND_PROTECTED_SEGMENT_REGEX = /```[\s\S]*?(?:```|$)|~~~[\s\S]*?(?:~~~|$)|`[^`\n]+`|<#[A-Za-z0-9_-]{1,160}>|<@!?[A-Za-z0-9_-]{1,160}>|<a?:[a-zA-Z0-9_]{2,32}:[a-zA-Z0-9_-]+>|<s:[^>\s]+:[^>\s]+>|https?:\/\/[^\s<>\])"']+|\[[^\]\n]+\]\([^)\n]+\)/g;
const CHANNEL_PRE_BOUNDARY_FORBIDDEN = /[A-Za-z0-9_#&/:]/;
const CHANNEL_POST_BOUNDARY_ALLOWED = /^(?:$|[\s,.;:!?()[\]{}<>"'，。；：！？（）【】《》“”‘’、])/;
function replaceChannelNamesWithTokens(text, channels) {
    if (!text || !text.includes("#") || !channels.length)
        return text;
    const resolvedMap = buildUnambiguousChannelNameMap(channels);
    if (resolvedMap.size === 0)
        return text;
    const uniqueNames = [
        ...new Set(channels
            .filter((item) => isGuildMentionableChannel(item) && item.name.length > 0)
            .filter((item) => resolvedMap.has(item.name.toLowerCase()) ||
            resolvedMap.has(`exact:${item.name}`))
            .map((item) => item.name)),
    ].sort((a, b) => b.length - a.length);
    if (uniqueNames.length === 0)
        return text;
    const namePattern = uniqueNames.map(escapeRegExp).join("|");
    const candidateRegex = new RegExp(`#(${namePattern})`, "gi");
    const transformPlain = (segment) => {
        if (!segment.includes("#"))
            return segment;
        let out = "";
        let last = 0;
        candidateRegex.lastIndex = 0;
        for (const match of segment.matchAll(candidateRegex)) {
            const idx = match.index ?? 0;
            const matchedName = match[1];
            if (!matchedName)
                continue;
            if (idx > 0 && CHANNEL_PRE_BOUNDARY_FORBIDDEN.test(segment[idx - 1])) {
                continue;
            }
            const end = idx + match[0].length;
            if (!CHANNEL_POST_BOUNDARY_ALLOWED.test(segment.slice(end))) {
                continue;
            }
            const target = resolvedMap.get(`exact:${matchedName}`) ??
                resolvedMap.get(matchedName.toLowerCase());
            if (!target)
                continue;
            if (idx < last)
                continue;
            out += segment.slice(last, idx) + `<#${target.id}>`;
            last = end;
        }
        return out + segment.slice(last);
    };
    let result = "";
    let offset = 0;
    for (const match of text.matchAll(OUTBOUND_PROTECTED_SEGMENT_REGEX)) {
        const idx = match.index ?? 0;
        result += transformPlain(text.slice(offset, idx));
        result += match[0];
        offset = idx + match[0].length;
    }
    result += transformPlain(text.slice(offset));
    return result;
}
function isUpdateIntegrationSettingsDTO(value) {
    if (!value || typeof value !== "object" || Array.isArray(value))
        return false;
    const dto = value;
    return (Object.keys(dto).length > 0 &&
        Object.keys(dto).every((key) => ["botsEnabled", "maxBotsPerGuild", "webhooksEnabled"].includes(key)) &&
        (dto.botsEnabled === undefined || typeof dto.botsEnabled === "boolean") &&
        (dto.webhooksEnabled === undefined ||
            typeof dto.webhooksEnabled === "boolean") &&
        (dto.maxBotsPerGuild === undefined ||
            (typeof dto.maxBotsPerGuild === "number" &&
                Number.isSafeInteger(dto.maxBotsPerGuild) &&
                dto.maxBotsPerGuild >= 1 &&
                dto.maxBotsPerGuild <= 100)));
}
function applyMessageUpdate(message, update) {
    if ((update.revision ?? message.revision ?? 0) < (message.revision ?? 0))
        return message;
    return {
        ...message,
        ...update,
        ...(update.content !== undefined && update.content !== message.content
            ? { rawContent: undefined }
            : {}),
    };
}
function isContextLimit(value) {
    return (Number.isSafeInteger(value) &&
        Number(value) >= 0 &&
        Number(value) <= exports.BOT_MAX_CONTEXT_LIMIT);
}
function effectiveContextLimit(application, channelId) {
    return (application.channelSettings.find((setting) => setting.channelId === channelId)?.contextLimit ?? application.defaultContextLimit);
}
//# sourceMappingURL=bot.js.map