"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=desktop-capture.js.map