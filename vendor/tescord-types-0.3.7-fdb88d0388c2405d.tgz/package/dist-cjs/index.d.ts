export * from "./message-encryption.js";
export * from "./bot.js";
import type { BotMember } from "./bot.js";
export * from "./interactions.js";
export type UserStatus = "ONLINE" | "IDLE" | "DND" | "OFFLINE" | "INVISIBLE";
export type SystemRole = "USER" | "ADMIN" | "SUPER_ADMIN";
export type ActivityType = "PLAYING" | "STREAMING" | "LISTENING" | "WATCHING" | "CUSTOM";
export interface Activity {
    name: string;
    type: ActivityType;
    details?: string;
    state?: string;
    applicationId?: string;
    timestamps?: {
        start?: number;
        end?: number;
    };
    assets?: {
        largeImage?: string;
        largeText?: string;
        smallImage?: string;
        smallText?: string;
    };
}
export type VagueTimeUnit = "just_now" | "minute" | "hour" | "day" | "month" | "year";
export interface VagueTime {
    unit: VagueTimeUnit;
    value?: number;
}
export declare function calcVagueTime(date: Date | string | number | null | undefined, nowMs?: number): VagueTime | undefined;
export interface User {
    id: string;
    username: string;
    displayName?: string | null;
    discriminator?: string;
    email: string;
    avatarUrl?: string | null;
    status: UserStatus;
    customStatus?: string | null;
    bio?: string | null;
    bannerUrl?: string | null;
    bannerColor?: string | null;
    themeColor?: string | null;
    showActivity?: boolean;
    activities?: Activity[];
    role?: SystemRole;
    isBanned?: boolean;
    isBot?: boolean;
    mustChangePassword?: boolean;
    scheduledDeletionAt?: string | null;
    createdAt: string;
    updatedAt?: string;
    lastSeenAt?: string | null;
}
export interface AuthTokens {
    accessToken: string;
    refreshToken: string;
    user: User;
    expiresIn: number;
}
export type AuthFailureCode = "AUTH_INVALID_CREDENTIALS" | "AUTH_REFRESH_INVALID" | "AUTH_REFRESH_EXPIRED" | "AUTH_ACCOUNT_BANNED" | "AUTH_ACCOUNT_DELETION_PENDING" | "AUTH_SESSION_REVOKED";
export interface AuthErrorResponse {
    error: string;
    code: AuthFailureCode | "AUTH_SERVICE_UNAVAILABLE";
    scheduledDeletionAt?: string;
}
export interface RevokeSessionDTO {
    refreshToken: string;
}
export interface AuthResponse {
    user: User;
    token: string;
    accessToken: string;
    refreshToken: string;
}
export interface CheckEmailDTO {
    email: string;
}
export interface CheckEmailResponse {
    exists: boolean;
}
export interface RegisterDTO {
    username?: string;
    nickname?: string;
    email: string;
    password: string;
    inviteCode?: string;
}
export interface LoginDTO {
    emailOrUsername: string;
    password: string;
    rememberMe?: boolean;
}
export interface SelfDeleteAccountDTO {
    password: string;
}
export interface CancelDeletionDTO {
    emailOrUsername: string;
    password: string;
}
export declare function isSelfDeleteAccountDTO(value: unknown): value is SelfDeleteAccountDTO;
export declare function isCancelDeletionDTO(value: unknown): value is CancelDeletionDTO;
export interface SavedAccount {
    id: string;
    email: string;
    username: string;
    displayName?: string | null;
    discriminator?: string;
    avatarUrl?: string | null;
    lastActiveAt: number;
    rememberPassword?: boolean;
    refreshToken?: string;
}
export interface RefreshTokenDTO {
    refreshToken: string;
}
export interface PasskeyInfo {
    id: string;
    name: string;
    createdAt: string;
    lastUsedAt: string | null;
    aaguid?: string | null;
    transports?: string[] | null;
}
export interface WebAuthnRegisterOptionsResponse {
    options: any;
    challengeId: string;
}
export interface WebAuthnVerifyRegisterDTO {
    challengeId: string;
    response: any;
    name?: string;
}
export interface WebAuthnLoginOptionsResponse {
    options: any;
    challengeId: string;
}
export interface WebAuthnVerifyLoginDTO {
    challengeId: string;
    response: any;
}
export interface UpdatePasskeyDTO {
    name: string;
}
export interface DeletePasskeyDTO {
    password?: string;
}
export interface DesktopPasskeyAuthPayload {
    action: "login" | "register";
    apiBase: string;
    emailOrUsername?: string;
    deviceName?: string;
    token?: string;
}
export interface DesktopPasskeyAuthResult {
    success: boolean;
    tokens?: AuthTokens;
    error?: string;
    code?: ErrorCode;
}
export interface UpdateProfileDTO {
    username?: string;
    displayName?: string | null;
    avatarUrl?: string | null;
    customStatus?: string | null;
    bio?: string | null;
    status?: UserStatus;
    bannerUrl?: string | null;
    bannerColor?: string | null;
    themeColor?: string | null;
    showActivity?: boolean;
}
export type RelationshipType = "FRIEND" | "PENDING_INCOMING" | "PENDING_OUTGOING" | "BLOCKED";
export interface Relationship {
    id: string;
    userId: string;
    targetUserId: string;
    type: RelationshipType;
    createdAt: string;
    updatedAt: string;
    targetUser?: User;
}
export interface SendFriendRequestDTO {
    identifier?: string;
    targetUserId?: string;
}
export interface BlockUserDTO {
    targetUserId: string;
}
export declare enum PermissionFlags {
    CREATE_INVITE = 1,// 0x00000001
    KICK_MEMBERS = 2,// 0x00000002
    BAN_MEMBERS = 4,// 0x00000004
    ADMINISTRATOR = 8,// 0x00000008 (拥有全部权限)
    MANAGE_CHANNELS = 16,// 0x00000010
    MANAGE_GUILD = 32,// 0x00000020
    ADD_REACTIONS = 64,// 0x00000040
    VIEW_AUDIT_LOG = 128,// 0x00000080
    VIEW_CHANNEL = 1024,// 0x00000400
    SEND_MESSAGES = 2048,// 0x00000800
    MANAGE_MESSAGES = 8192,// 0x00002000
    ATTACH_FILES = 32768,// 0x00008000
    READ_MESSAGE_HISTORY = 65536,// 0x00010000
    CONNECT = 1048576,// 0x00100000
    SPEAK = 2097152,// 0x00200000
    MUTE_MEMBERS = 4194304,// 0x00400000
    DEAFEN_MEMBERS = 8388608,// 0x00800000
    MOVE_MEMBERS = 16777216,// 0x01000000
    STREAM = 33554432,// 0x02000000
    MANAGE_ROLES = 67108864,// 0x04000000
    CHANGE_NICKNAME = 134217728,// 0x08000000
    MANAGE_NICKNAMES = 268435456
}
export interface PermissionDefinition {
    flag: PermissionFlags;
    name: string;
    description: string;
    category: "GENERAL" | "MEMBERSHIP" | "TEXT" | "VOICE" | "ADVANCED";
}
export declare const ALL_PERMISSIONS: PermissionDefinition[];
export interface Role {
    id: string;
    guildId: string;
    name: string;
    color?: string | null;
    hoist: boolean;
    position: number;
    permissions: number;
    isDefault?: boolean;
    createdAt: string;
}
export declare function hasPermission(userPermissions: number, flag: PermissionFlags): boolean;
export declare function computePermissions(roles: Role[]): number;
export declare function parseRoleIds(raw: any): string[];
export type OverwriteTargetType = "ROLE" | "MEMBER";
export interface PermissionOverwrite {
    id: string;
    guildId: string;
    channelId?: string | null;
    categoryId?: string | null;
    targetType: OverwriteTargetType;
    targetId: string;
    allow: number;
    deny: number;
    createdAt?: string;
    updatedAt?: string;
}
export interface SetPermissionOverwriteDTO {
    targetType: OverwriteTargetType;
    allow: number;
    deny: number;
}
export declare const CHANNEL_TEXT_PERMISSIONS: PermissionFlags[];
export declare const CHANNEL_VOICE_PERMISSIONS: PermissionFlags[];
export declare const CHANNEL_CATEGORY_PERMISSIONS: PermissionFlags[];
export interface ComputePermissionsContext {
    userId: string;
    isOwner?: boolean;
    isSuperAdmin?: boolean;
    userRoleIds: string[];
    guildRoles: Role[];
    channelOverwrites?: PermissionOverwrite[];
    categoryOverwrites?: PermissionOverwrite[];
}
export declare function computeEffectivePermissions(context: ComputePermissionsContext): number;
export type ChannelType = "TEXT" | "VOICE" | "DM" | "GROUP_DM";
export interface ChannelCategory {
    id: string;
    guildId: string;
    name: string;
    position: number;
    overwrites?: PermissionOverwrite[];
    createdAt: string;
    updatedAt: string;
}
export interface Channel {
    id: string;
    guildId?: string | null;
    name: string;
    type: ChannelType;
    topic?: string | null;
    parentId?: string | null;
    position: number;
    isE2EE?: boolean;
    bitrate?: number;
    voiceMode?: import("./voice-routing.js").ChannelVoiceMode;
    streamMode?: StreamTransmissionMode;
    recipients?: User[];
    lastMessage?: Message;
    unreadCount?: number;
    lastReadSequence?: number;
    overwrites?: PermissionOverwrite[];
    createdAt: string;
}
export interface ChannelUnreadInfo {
    channelId: string;
    guildId?: string | null;
    hasUnread: boolean;
    unreadCount: number;
    mentionCount: number;
    lastReadSequence: number;
}
export type ChannelUnreadMap = Record<string, ChannelUnreadInfo>;
export interface ChannelReadState {
    id: string;
    userId: string;
    channelId: string;
    guildId?: string | null;
    lastReadSequence: number;
    lastReadAt: string;
}
export interface MarkChannelReadDTO {
    sequence?: number;
    lastReadSequence?: number;
}
export interface MarkGuildReadDTO {
    guildId: string;
}
export interface MarkChannelReadResponse {
    success: boolean;
    channelId: string;
    lastReadSequence: number;
    guildId?: string | null;
    unreadCount?: number;
}
export interface MarkGuildReadResponse {
    success: boolean;
    guildId: string;
    updatedChannels: {
        channelId: string;
        lastReadSequence: number;
    }[];
}
export interface GuildMember {
    userId: string;
    guildId: string;
    nickname?: string | null;
    roleIds: string[];
    roles?: Role[];
    joinedAt: string;
    user?: User;
}
export interface GuildMemberAddPayload {
    guildId: string;
    member: GuildMember;
}
export interface GuildMemberRemovePayload {
    guildId: string;
    userId: string;
}
export interface GuildMemberUpdatePayload {
    guildId: string;
    member: GuildMember;
}
export interface Guild {
    id: string;
    name: string;
    iconUrl?: string | null;
    description?: string | null;
    isPublic?: boolean;
    ownerId: string;
    channels: Channel[];
    categories?: ChannelCategory[];
    members: GuildMember[];
    botMembers?: BotMember[];
    roles?: Role[];
    createdAt: string;
    updatedAt?: string;
}
export interface PublicGuild {
    id: string;
    name: string;
    iconUrl?: string | null;
    description?: string | null;
    ownerId: string;
    memberCount: number;
    isJoined?: boolean;
    createdAt: string;
}
export interface Invite {
    code: string;
    guildId: string;
    inviterId: string;
    inviter?: User;
    maxUses?: number;
    uses: number;
    expiresAt?: string | null;
    createdAt: string;
}
export interface ActiveGuildInviteResponse {
    invite: Invite | null;
}
export interface GuildBan {
    id: string;
    guildId: string;
    userId: string;
    user?: User;
    reason?: string | null;
    createdAt: string;
}
export interface BanMemberDTO {
    reason?: string;
}
export declare enum AuditLogAction {
    GUILD_UPDATE = "GUILD_UPDATE",
    ROLE_CREATE = "ROLE_CREATE",
    ROLE_UPDATE = "ROLE_UPDATE",
    ROLE_DELETE = "ROLE_DELETE",
    MEMBER_KICK = "MEMBER_KICK",
    MEMBER_BAN_ADD = "MEMBER_BAN_ADD",
    MEMBER_BAN_REMOVE = "MEMBER_BAN_REMOVE",
    MEMBER_ROLE_UPDATE = "MEMBER_ROLE_UPDATE",
    INVITE_CREATE = "INVITE_CREATE",
    INVITE_DELETE = "INVITE_DELETE",
    CHANNEL_CREATE = "CHANNEL_CREATE",
    CHANNEL_UPDATE = "CHANNEL_UPDATE",
    CHANNEL_DELETE = "CHANNEL_DELETE"
}
export interface AuditLogEntry {
    id: string;
    guildId: string;
    userId: string;
    user?: User;
    action: AuditLogAction | string;
    targetId?: string | null;
    targetName?: string | null;
    changesJson?: string | null;
    changes?: Record<string, {
        old?: any;
        new?: any;
    }>;
    reason?: string | null;
    createdAt: string;
}
export interface CreateGuildDTO {
    name: string;
    iconUrl?: string | null;
    description?: string | null;
}
export interface UpdateGuildDTO {
    name?: string;
    iconUrl?: string | null;
    description?: string | null;
}
export interface TransferOwnershipDTO {
    newOwnerId: string;
}
export interface CreateRoleDTO {
    name: string;
    color?: string | null;
    hoist?: boolean;
    permissions?: number;
}
export interface UpdateRoleDTO {
    name?: string;
    color?: string | null;
    hoist?: boolean;
    position?: number;
    permissions?: number;
}
export interface UpdateRolePositionsDTO {
    roles: Array<{
        id: string;
        position: number;
    }>;
}
export interface UpdateMemberRolesDTO {
    roleIds: string[];
    nickname?: string | null;
}
export interface CreateChannelDTO {
    name: string;
    type?: ChannelType;
    topic?: string | null;
    parentId?: string | null;
    position?: number;
    isE2EE?: boolean;
    bitrate?: number;
    voiceMode?: import("./voice-routing.js").ChannelVoiceMode;
    streamMode?: StreamTransmissionMode;
    isPrivate?: boolean;
    allowedRoleIds?: string[];
    allowedUserIds?: string[];
}
export interface UpdateChannelDTO {
    name?: string;
    topic?: string | null;
    parentId?: string | null;
    position?: number;
    isE2EE?: boolean;
    bitrate?: number;
    voiceMode?: import("./voice-routing.js").ChannelVoiceMode;
    streamMode?: StreamTransmissionMode;
}
export interface CreateCategoryDTO {
    name: string;
    position?: number;
}
export interface UpdateCategoryDTO {
    name?: string;
    position?: number;
}
export interface ReorderCategoriesDTO {
    categories: {
        id: string;
        position: number;
    }[];
}
export interface ReorderChannelsDTO {
    channels: {
        id: string;
        position: number;
        parentId?: string | null;
    }[];
}
export interface CreateInviteDTO {
    maxAge?: number;
    maxUses?: number;
    expiresInHours?: number;
    isTemporary?: boolean;
    forceNew?: boolean;
}
export interface InvitePreviewDTO {
    code: string;
    guild: {
        id: string;
        name: string;
        iconUrl?: string | null;
        description?: string | null;
        createdAt?: string;
        approximateMemberCount?: number;
        approximatePresenceCount?: number;
    };
    inviter?: {
        id: string;
        username: string;
        displayName?: string | null;
        avatarUrl?: string | null;
    } | null;
    channel?: {
        id: string;
        name: string;
    } | null;
    expiresAt?: string | null;
    isTemporary?: boolean;
    approximateMemberCount?: number;
    approximatePresenceCount?: number;
    isMember?: boolean;
}
export interface JoinInviteDTO {
    code: string;
}
export type AttachmentVariant = "original" | "preview";
export interface Attachment {
    id: string;
    url: string;
    previewUrl?: string;
    downloadUrl?: string;
    expiresAt?: number;
    fileName: string;
    fileSize: number;
    mimeType: string;
    width?: number;
    height?: number;
    localPreviewUrl?: string;
    uploadProgress?: number;
}
export interface DesktopServerConfig {
    serverUrl: string;
    gatewayUrl: string;
    livekitUrl: string;
    voiceEngine: "livekit" | "cloudflare_realtime";
    webUrl?: string;
}
export interface FileUrlAccess {
    fileUrl: string;
    url: string;
    previewUrl?: string;
    downloadUrl?: string;
    expiresAt: number;
}
export interface AttachmentAccessRequest {
    attachmentIds?: string[];
    fileUrls?: string[];
}
export interface AttachmentAccessResponse {
    attachments: Array<Pick<Attachment, "id" | "url" | "previewUrl" | "downloadUrl" | "expiresAt">>;
    fileUrls?: FileUrlAccess[];
}
export interface MessageReaction {
    emoji: string;
    count: number;
    userIds: string[];
    me?: boolean;
}
import { type VideoEmbedDescriptor } from "./video-embeds.js";
export * from "./video-embeds.js";
export interface MessageEmbed {
    url: string;
    originalUrl: string;
    title?: string;
    description?: string;
    siteName?: string;
    themeColor?: string;
    video?: VideoEmbedDescriptor;
    thumbnailUrl?: string;
}
export declare function isMessageEmbed(value: unknown): value is MessageEmbed;
export interface UrlPreviewQueryDTO {
    urls: string[];
}
export interface UrlPreviewQueryResponse {
    embeds: MessageEmbed[];
}
export type MessageAuthorType = "user" | "bot";
export interface Message {
    id: string;
    channelId: string;
    authorId: string;
    authorType?: MessageAuthorType;
    author: {
        id: string;
        isBot?: boolean;
        username: string;
        displayName?: string | null;
        avatarUrl?: string | null;
    };
    content: string;
    rawContent?: string;
    isEncrypted?: boolean;
    replyToId?: string | null;
    replyTo?: {
        id: string;
        authorId?: string;
        authorName: string;
        content: string;
    } | null;
    isPinned?: boolean;
    reactions?: MessageReaction[];
    attachments?: Attachment[];
    embeds?: MessageEmbed[];
    components?: import("./interactions.js").MessageActionRow[];
    interaction?: import("./interactions.js").MessageInteractionMetadata | null;
    flags?: number;
    createdAt: string;
    updatedAt?: string;
    editedAt?: string | null;
    revision?: number;
    sequence?: number;
    nonce?: string;
    status?: "sending" | "sent" | "failed";
    errorMessage?: string;
}
export type CreateMessageAttachmentDTO = Pick<Attachment, "url" | "fileName" | "fileSize" | "mimeType" | "width" | "height">;
export interface CreateMessageDTO {
    content?: string;
    authorId?: string;
    isEncrypted?: boolean;
    replyToId?: string | null;
    attachments?: CreateMessageAttachmentDTO[];
    components?: import("./interactions.js").MessageActionRow[];
    interaction?: import("./interactions.js").MessageInteractionMetadata | null;
    nonce?: string;
}
export interface GatewayMessageSendRequest {
    requestId: string;
    channelId: string;
    content?: string;
    isEncrypted?: boolean;
    replyToId?: string | null;
    attachments?: CreateMessageAttachmentDTO[];
    nonce?: string;
}
export type GatewayMessageSendResult = {
    requestId: string;
    channelId: string;
    success: true;
    message: Message;
} | {
    requestId: string;
    channelId: string;
    success: false;
    status: number;
    code: ErrorCode;
    error: string;
};
export interface SearchMessagesQuery {
    guildId?: string;
    channelId?: string;
    query?: string;
    from?: string;
    mentions?: string;
    has?: "link" | "file" | "image" | "video" | "sound";
    pinned?: boolean;
    before?: string;
    after?: string;
    limit?: number;
    offset?: number;
}
export interface SearchMessageItem extends Message {
    channelName?: string;
}
export interface SearchMessagesResponse {
    total: number;
    messages: SearchMessageItem[];
    hasMore: boolean;
}
export declare enum GatewayOpCode {
    DISPATCH = 0,
    HEARTBEAT = 1,
    IDENTIFY = 2,
    STATUS_UPDATE = 3,
    VOICE_STATE_UPDATE = 4,
    RESUME = 6,
    RECONNECT = 7,
    INVALID_SESSION = 9,
    HELLO = 10,
    HEARTBEAT_ACK = 11,
    SERVER_PING = 12,
    CLIENT_PONG = 13
}
export declare enum GatewayCloseCode {
    NORMAL = 1000,
    TOKEN_EXPIRED = 4001,
    UNAUTHORIZED = 4002,
    ACCOUNT_BANNED = 4003,
    SESSION_INVALID = 4004,
    MAINTENANCE_MODE = 4013
}
export interface GatewayPayload<T = any> {
    op: GatewayOpCode;
    d?: T;
    s?: number;
    t?: string;
}
export interface HelloPayload {
    heartbeatInterval: number;
}
export interface HeartbeatData {
    clientTimestamp: number;
    serverTimestamp?: number;
}
export interface ServerPingData {
    timestamp: number;
}
export interface ClientPongData {
    timestamp: number;
}
export type GatewayConnectionState = "disconnected" | "connecting" | "connected" | "reconnecting";
export type VoiceConnectionStatus = "disconnected" | "connecting" | "connected" | "reconnecting" | "p2p_active";
export interface AudioPlaybackStatus {
    canPlay: boolean;
    isInterrupted: boolean;
    error?: string;
}
export interface GatewayPingStats {
    ping: number;
    lastAckTimestamp: number;
}
export type DeviceType = "phone" | "tablet" | "desktop" | "web";
export interface IdentifyPayload {
    supportedVoiceModes?: import("./voice-routing.js").ChannelVoiceMode[];
    token: string;
    sessionId?: string;
    properties: {
        os: string;
        browser: string;
        device: string;
        deviceType?: DeviceType;
    };
}
export type StreamTransmissionMode = "sfu" | "p2p_direct" | "p2p_relay";
export interface VoiceStateUpdatePayload {
    mediaEncryptionVersion?: number;
    guildId: string;
    channelId: string | null;
    previousChannelId?: string | null;
    sessionId?: string;
    connectionStatus?: "connecting" | "connected";
    selfMute?: boolean;
    selfDeaf?: boolean;
    selfVideo?: boolean;
    streaming?: boolean;
    streamMode?: StreamTransmissionMode;
    noAudioInput?: boolean;
}
export interface VoiceState {
    userId: string;
    guildId: string;
    channelId: string | null;
    previousChannelId?: string | null;
    sessionId?: string;
    revision?: number;
    platform?: string;
    connectionStatus?: "connecting" | "connected";
    selfMute: boolean;
    selfDeaf: boolean;
    selfVideo: boolean;
    streaming: boolean;
    streamMode?: StreamTransmissionMode;
    noAudioInput?: boolean;
    roomStartedAt?: number | null;
    user?: Omit<User, "email">;
}
export interface VoiceServerDisconnectPayload {
    channelId?: string;
    sessionId?: string;
    reason: "VOICE_TRANSFER" | "KICKED" | "CHANNEL_DELETED" | "MEDIA_NEGOTIATION_TIMEOUT" | "MEDIA_POLICY_CHANGED";
    newChannelId?: string | null;
    targetPlatform?: string;
}
export interface ReadyPayload {
    voiceRouting?: import("./voice-routing.js").VoiceRoutingCapabilities;
    sessionId?: string;
    /** Advertises correlated media snapshot requests over this Gateway. */
    mediaEncryptionSync?: true;
    messageSendOverGateway?: true;
    user: Partial<User>;
    guilds: Guild[];
    voiceStates: VoiceState[];
    voiceChannelSessions?: Record<string, number>;
}
export interface StatusUpdatePayload {
    status: UserStatus;
    customStatus?: string | null;
    activities?: Activity[];
    /** 是否为用户显式手动在设置/菜单中切换状态 (true: 持久化偏好; false 或未传: 客户端会话活跃度变更) */
    isManual?: boolean;
}
export interface SystemIdlePayload {
    isIdle: boolean;
    idleTime: number;
}
export interface UserPresence {
    userId: string;
    status: UserStatus;
    customStatus?: string | null;
    activities?: Activity[];
    clientStatus?: {
        web?: UserStatus;
        desktop?: UserStatus;
        mobile?: UserStatus;
    };
    deviceType?: DeviceType;
    lastActiveAt?: string;
}
export interface PresenceUpdateEvent {
    userId: string;
    status: UserStatus;
    customStatus?: string | null;
    activities?: Activity[];
    clientStatus?: {
        web?: UserStatus;
        desktop?: UserStatus;
        mobile?: UserStatus;
    };
    deviceType?: DeviceType;
    lastActiveAt?: string;
}
export type LiveKitPublishSource = "microphone" | "camera" | "screen_share" | "screen_share_audio";
export interface LiveKitTokenRequest {
    roomName: string;
    identity: string;
    gatewaySessionId?: string;
    name?: string;
    isPublisher?: boolean;
    publishSources?: LiveKitPublishSource[];
    bitrate?: number;
}
export interface LiveKitTokenResponse {
    requiresE2EE?: boolean;
    token: string;
    url: string;
}
export type AudioInputMode = "VAD" | "PTT";
export type NoiseSuppressionMode = "off" | "rnnoise" | "dtln" | "dfn3";
export type NoiseEngineBackend = "web-wasm" | "desktop-native" | "bypass";
export type NoiseEnginePhase = "idle" | "loading" | "ready" | "failed";
/** Requested mode is persisted; effective mode describes the PCM actually sent. */
export interface NoiseEngineStatus {
    requestedMode: NoiseSuppressionMode;
    effectiveMode: NoiseSuppressionMode;
    backend: NoiseEngineBackend;
    phase: NoiseEnginePhase;
    reason?: string;
    sampleRate: number;
    processedFrames?: number;
    queueMs?: number;
    processingMs?: number;
    processingP50Ms?: number;
    processingP95Ms?: number;
    processingP99Ms?: number;
    capture?: {
        requestedEchoCancellation: boolean;
        actualEchoCancellation?: boolean;
        actualNoiseSuppression?: boolean;
        actualAutoGainControl?: boolean;
        actualSampleRate?: number;
        actualChannelCount?: number;
        contextSampleRate: number;
        warnings: string[];
    };
}
export interface DesktopNoiseFrame {
    sessionId: string;
    sequence: number;
    sampleCount: number;
    mode: Exclude<NoiseSuppressionMode, "off">;
    sampleRate: 48000;
    pcm: Float32Array;
}
export interface DesktopNoiseFrameResult {
    sessionId: string;
    sequence: number;
    sampleCount: number;
    pcm: Float32Array;
    processingMs: number;
    error?: string;
}
export interface DesktopAudioInferenceStart {
    mode: Exclude<NoiseSuppressionMode, "off">;
    requestId: string;
    strength?: number;
}
/** Stops only the inference process owned by the calling main window. */
export interface DesktopAudioInferenceStop {
    requestId: string;
}
export interface DesktopAudioInferenceFailure {
    requestId: string;
    reason: string;
}
export type SoundEffectType = "MUTE" | "UNMUTE" | "DEAFEN" | "UNDEAFEN" | "VOICE_JOIN" | "VOICE_LEAVE" | "USER_JOIN" | "USER_LEAVE" | "CALL_RINGING" | "CALL_CALLING" | "CALL_CONNECT" | "CALL_DISCONNECT" | "MESSAGE_NOTIFICATION" | "MESSAGE_MENTION";
export type ClientCallState = "idle" | "outgoing_calling" | "incoming_ringing" | "connecting" | "connected" | "ended";
export interface DMCallEventMetadata {
    callId: string;
    callType: "voice" | "video";
    status: "completed" | "missed" | "declined" | "canceled";
    durationSeconds?: number;
    startedAt: string;
    endedAt: string;
}
export interface AudioProcessingConfig {
    noiseSuppression: boolean;
    noiseSuppressionMode?: NoiseSuppressionMode;
    echoCancellation: boolean;
    autoGainControl: boolean;
    highFidelityMusic: boolean;
    inputMode: AudioInputMode;
    pushToTalk: boolean;
    pushToTalkKey?: string;
    pushToTalkReleaseDelay?: number;
    vadSensitivity: number;
    audioBitrate: number;
    manualGain?: number;
    agcGainRange?: number;
    noiseSuppressionStrength?: number;
    inputDeviceId?: string;
    outputDeviceId?: string;
}
export type VideoCodecType = "h264" | "av1" | "vp9" | "vp8" | "h265";
export interface CodecCapabilityInfo {
    codec: VideoCodecType;
    label: string;
    description: string;
    supported: boolean;
    isHardwareAccelerated?: boolean;
    reason?: string;
}
export declare const DEFAULT_VIDEO_CODEC: VideoCodecType;
export declare const MIN_CUSTOM_BITRATE = 500000;
export declare const MAX_CUSTOM_BITRATE = 25000000;
export interface VideoSettingsConfig {
    cameraDeviceId?: string;
    mirrorLocalPreview?: boolean;
    preferredVideoCodec?: VideoCodecType;
    customBitrate?: number;
    enableBackupCodec?: boolean;
}
export type ConnectionTopology = "SFU_SERVER" | "P2P_MESH" | "P2P_DIRECT" | "P2P_TREE_RELAY";
export interface ICEServerEntry {
    urls: string | string[];
    username?: string;
    credential?: string;
}
export interface ICEServerConfigResponse {
    iceServers: ICEServerEntry[];
    turnActive: boolean;
}
export interface StreamDetailedStats {
    audioReceiveQuality?: import("./media-encryption.js").AudioReceiveQuality[];
    participantIdentity: string;
    isLocal: boolean;
    mimeType: string;
    playerCore: string;
    videoInfo?: string;
    audioInfo: string;
    encoder: string;
    streamHost: string;
    connectionMode: string;
    topology: ConnectionTopology;
    protocol: string;
    bufferLength: string;
    decodedFrames?: string;
    encodedFrames?: string;
    droppedFrames?: string;
    scalabilityMode?: string;
    downloadBitrate: string;
    uploadBitrate?: string;
    rawDownloadBitrateBps?: number;
    rawUploadBitrateBps?: number;
    totalBytesReceived?: number;
    totalBytesSent?: number;
    rtt: string;
    packetLoss: string;
    jitter: string;
    holePunchStatus?: string;
    ipVersion?: "IPv4" | "IPv6";
    candidateType?: "host" | "srflx" | "prflx" | "relay";
    preferredVideoCodec?: VideoCodecType;
    actualSendCodec?: string;
    actualReceiveCodec?: string;
    codecFallbackReason?: string;
    transportVerified?: boolean;
}
export type VoiceTransmissionMode = import("./voice-routing.js").ChannelVoiceMode | "cloudflare_realtime";
export interface VoiceChannelStatusInfo {
    mode: VoiceTransmissionMode;
    isMeshActive: boolean;
    isFallbackToSFU: boolean;
    fallbackReason?: string;
    peerCount: number;
    rtt: number;
    jitter: number;
    packetLoss: number;
    bitrate: number;
    codec: string;
}
export interface VideoChannelStatusInfo {
    state: "idle" | "broadcasting" | "watching";
    transmissionMode: StreamTransmissionMode;
    codec?: string;
    hardwareAcceleration?: string;
    resolution?: string;
    framerate?: number;
    bitrate?: number;
    packetLoss?: number;
}
export interface PeerLatencyReport {
    targetUserId: string;
    rtt: number;
    jitter?: number;
    packetLoss?: number;
    connectionType: "LAN" | "P2P" | "RELAY" | "SFU";
    status: "connecting" | "connected" | "failed";
    localAddress?: string;
    remoteAddress?: string;
    candidateType?: string;
    updatedAt: number;
}
export interface ChannelMuteConfig {
    muted: boolean;
    mutedUntil: number | null;
}
export interface MuteDurationOption {
    label: string;
    durationMs: number | null;
    i18nKey: string;
}
export declare const CHANNEL_MUTE_DURATION_OPTIONS: MuteDurationOption[];
/**
 * 判定频道配置当前是否处于有效静音状态（毫秒级判断）
 */
export declare function isChannelMuted(config?: ChannelMuteConfig | null): boolean;
export type GuildNotificationMode = "ALL" | "MENTIONS" | "NOTHING";
export interface GuildNotificationSettings {
    mode: GuildNotificationMode;
    suppressEveryone?: boolean;
    suppressRoles?: boolean;
}
export declare const GUILD_MUTE_DURATION_OPTIONS: MuteDurationOption[];
/**
 * 判定服务器配置当前是否处于有效静音状态（毫秒级判断）
 */
export declare function isGuildMuted(config?: ChannelMuteConfig | null): boolean;
export type MessageDisplayMode = "cozy" | "compact";
export interface UserSettingsDTO {
    audio: AudioProcessingConfig;
    video: VideoSettingsConfig;
    outputVolume: number;
    userVolumes: Record<string, number>;
    language?: SupportedLocale;
    voiceTransmissionMode?: VoiceTransmissionMode;
    mutedChannels?: Record<string, ChannelMuteConfig>;
    mutedGuilds?: Record<string, ChannelMuteConfig>;
    guildNotificationSettings?: Record<string, GuildNotificationSettings>;
    userNotificationSettings?: UserNotificationSettings;
    guildPositions?: string[];
    userNotes?: Record<string, string>;
    pinnedDMs?: string[];
    mutedUsers?: Record<string, number>;
    chatFontSize?: number;
    messageDisplayMode?: MessageDisplayMode;
}
export interface UpdateUserNoteDTO {
    note: string;
}
export interface CameraDeviceInfo {
    deviceId: string;
    label: string;
    groupId?: string;
}
export interface NetworkStats {
    identity: string;
    rtt?: number;
    packetLoss?: number;
    jitter?: number;
    bitrate?: number;
    codec?: string;
    videoCodec?: string;
    videoResolution?: string;
    videoFramerate?: number;
    videoBitrate?: number;
    quality: "excellent" | "good" | "poor" | "unknown";
    timestamp: number;
}
export interface ParticipantAudioSettings {
    participantId: string;
    volume: number;
    muted: boolean;
}
export interface AudioOutputState {
    deviceId: string;
    volume: number;
    deafened: boolean;
}
export type AudioDeviceSelectionResult = {
    success: true;
    deviceId: string;
} | {
    success: false;
    deviceId: string;
    code: "AUDIO_DEVICE_UNSUPPORTED" | "AUDIO_DEVICE_SWITCH_FAILED";
};
export declare function clampVolume(vol: number): number;
export declare function computeGain(volumePercent: number, isMuted: boolean): number;
export declare function evaluateNetworkQuality(rtt: number, packetLoss: number): "excellent" | "good" | "poor";
export declare function calculateSNRReduction(rawRms: number, cleanRms: number): number;
export interface TripleTrackSNRResult {
    rawRms: number;
    rnnoiseRms: number;
    dtlnRms: number;
    rnnoiseDbReduction: number;
    dtlnDbReduction: number;
}
export declare function calculateTripleSNRReduction(rawRms: number, rnnoiseRms: number, dtlnRms: number): TripleTrackSNRResult;
export interface QuadTrackSNRResult {
    rawRms: number;
    rnnoiseRms: number;
    dtlnRms: number;
    dfn3Rms: number;
    rnnoiseDbReduction: number;
    dtlnDbReduction: number;
    dfn3DbReduction: number;
}
export declare function calculateQuadSNRReduction(rawRms: number, rnnoiseRms: number, dtlnRms: number, dfn3Rms: number): QuadTrackSNRResult;
export interface PresignedUploadRequest {
    fileName: string;
    fileSize: number;
    mimeType: string;
    purpose?: "attachment" | "guild-icon" | "user-avatar" | "user-banner" | "custom-emoji";
    channelId?: string;
    guildId?: string;
    width?: number;
    height?: number;
}
export interface PresignedUploadResponse {
    uploadUrl: string;
    fileUrl: string;
    fileKey: string;
    requiresAuth?: boolean;
}
export interface UploadAttachmentResponse {
    success: boolean;
    converted?: boolean;
    fileName?: string;
    mimeType?: string;
    fileSize?: number;
    width?: number;
    height?: number;
}
export interface DiscardGuildIconUploadDTO {
    fileUrl: string;
}
export interface AttachmentUploadConfig {
    maxUploadBytes: number;
    blockedExtensions: string[];
    blockedMimeTypes: string[];
}
export interface LocalPendingAttachment {
    id: string;
    file: File;
    fileName: string;
    fileSize: number;
    mimeType: string;
    previewUrl?: string;
    width?: number;
    height?: number;
}
export interface AddReactionDTO {
    emoji: string;
}
export declare const GatewayEvents: {
    readonly READY: "READY";
    readonly BOT_CONFIG_UPDATE: "BOT_CONFIG_UPDATE";
    readonly BOT_COMMANDS_UPDATE: "BOT_COMMANDS_UPDATE";
    readonly INTERACTION_CREATE: "INTERACTION_CREATE";
    readonly INTERACTION_THINKING: "INTERACTION_THINKING";
    readonly INTERACTION_MODAL: "INTERACTION_MODAL";
    readonly EPHEMERAL_MESSAGE: "EPHEMERAL_MESSAGE";
    readonly EPHEMERAL_DELETE: "EPHEMERAL_DELETE";
    readonly MESSAGE_SEND: "MESSAGE_SEND";
    readonly MESSAGE_SEND_RESULT: "MESSAGE_SEND_RESULT";
    readonly MESSAGE_CREATE: "MESSAGE_CREATE";
    readonly MESSAGE_UPDATE: "MESSAGE_UPDATE";
    readonly MESSAGE_DELETE: "MESSAGE_DELETE";
    readonly MESSAGE_REACTION_ADD: "MESSAGE_REACTION_ADD";
    readonly MESSAGE_REACTION_REMOVE: "MESSAGE_REACTION_REMOVE";
    readonly MESSAGE_PIN_UPDATE: "MESSAGE_PIN_UPDATE";
    readonly VOICE_STATE_UPDATE: "VOICE_STATE_UPDATE";
    readonly VOICE_SERVER_DISCONNECT: "VOICE_SERVER_DISCONNECT";
    readonly CF_MEDIA_TRACKS: "CF_MEDIA_TRACKS";
    readonly CF_STREAM_VIEWERS: "CF_STREAM_VIEWERS";
    readonly USER_UPDATE: "USER_UPDATE";
    readonly PRESENCE_UPDATE: "PRESENCE_UPDATE";
    readonly GUILD_CREATE: "GUILD_CREATE";
    readonly GUILD_UPDATE: "GUILD_UPDATE";
    readonly GUILD_DELETE: "GUILD_DELETE";
    readonly GUILD_MEMBER_ADD: "GUILD_MEMBER_ADD";
    readonly GUILD_MEMBER_REMOVE: "GUILD_MEMBER_REMOVE";
    readonly GUILD_MEMBER_UPDATE: "GUILD_MEMBER_UPDATE";
    readonly GUILD_ROLE_CREATE: "GUILD_ROLE_CREATE";
    readonly GUILD_ROLE_UPDATE: "GUILD_ROLE_UPDATE";
    readonly GUILD_ROLE_DELETE: "GUILD_ROLE_DELETE";
    readonly GUILD_BAN_ADD: "GUILD_BAN_ADD";
    readonly GUILD_BAN_REMOVE: "GUILD_BAN_REMOVE";
    readonly CHANNEL_CREATE: "CHANNEL_CREATE";
    readonly CHANNEL_UPDATE: "CHANNEL_UPDATE";
    readonly CHANNEL_DELETE: "CHANNEL_DELETE";
    readonly CATEGORY_CREATE: "CATEGORY_CREATE";
    readonly CATEGORY_UPDATE: "CATEGORY_UPDATE";
    readonly CATEGORY_DELETE: "CATEGORY_DELETE";
    readonly CATEGORY_POSITIONS_UPDATE: "CATEGORY_POSITIONS_UPDATE";
    readonly CHANNEL_POSITIONS_UPDATE: "CHANNEL_POSITIONS_UPDATE";
    readonly STREAM_START: "STREAM_START";
    readonly STREAM_STOP: "STREAM_STOP";
    readonly E2EE_KEY_EXCHANGE: "E2EE_KEY_EXCHANGE";
    readonly E2EE_CHANNEL_UPDATE: "E2EE_CHANNEL_UPDATE";
    readonly TYPING_START: "TYPING_START";
    readonly TYPING_STOP: "TYPING_STOP";
    readonly MEDIA_KEY_ENVELOPE: "MEDIA_KEY_ENVELOPE";
    readonly MEDIA_KEY_ACK: "MEDIA_KEY_ACK";
    readonly MEDIA_EPOCH_UPDATE: "MEDIA_EPOCH_UPDATE";
    readonly MEDIA_MEMBER_LEFT: "MEDIA_MEMBER_LEFT";
    readonly MEDIA_KEY_RESYNC_REQUEST: "MEDIA_KEY_RESYNC_REQUEST";
    readonly MEDIA_ENCRYPTION_SYNC: "MEDIA_ENCRYPTION_SYNC";
    readonly MEDIA_ENCRYPTION_SYNC_RESULT: "MEDIA_ENCRYPTION_SYNC_RESULT";
    readonly P2P_SIGNAL: "P2P_SIGNAL";
    readonly P2P_TOPOLOGY_UPDATE: "P2P_TOPOLOGY_UPDATE";
    readonly P2P_QUALITY_REPORT: "P2P_QUALITY_REPORT";
    readonly P2P_FALLBACK_REQUEST: "P2P_FALLBACK_REQUEST";
    readonly DM_CHANNEL_CREATE: "DM_CHANNEL_CREATE";
    readonly DM_CHANNEL_UPDATE: "DM_CHANNEL_UPDATE";
    readonly DM_CHANNEL_DELETE: "DM_CHANNEL_DELETE";
    readonly CALL_OFFER: "CALL_OFFER";
    readonly CALL_ANSWER: "CALL_ANSWER";
    readonly CALL_REJECT: "CALL_REJECT";
    readonly CALL_END: "CALL_END";
    readonly CALL_STATE_UPDATE: "CALL_STATE_UPDATE";
    readonly CALL_MISSED: "CALL_MISSED";
    readonly RELATIONSHIP_ADD: "RELATIONSHIP_ADD";
    readonly RELATIONSHIP_REMOVE: "RELATIONSHIP_REMOVE";
    readonly RELATIONSHIP_UPDATE: "RELATIONSHIP_UPDATE";
    readonly ACCOUNT_SESSION_REVOKED: "ACCOUNT_SESSION_REVOKED";
    readonly AUTH_SESSION_EXPIRED: "AUTH_SESSION_EXPIRED";
    readonly MAINTENANCE_UPDATE: "MAINTENANCE_UPDATE";
    readonly SYSTEM_BROADCAST: "SYSTEM_BROADCAST";
    readonly VOICE_CHANNEL_EVENT: "VOICE_CHANNEL_EVENT";
    readonly P2P_FILE_OFFER: "P2P_FILE_OFFER";
    readonly P2P_FILE_RESPONSE: "P2P_FILE_RESPONSE";
    readonly P2P_FILE_SIGNAL: "P2P_FILE_SIGNAL";
    readonly P2P_FILE_CANCEL: "P2P_FILE_CANCEL";
};
export type GatewayEventType = (typeof GatewayEvents)[keyof typeof GatewayEvents];
export declare enum VoiceChannelEventType {
    JOIN = "JOIN",
    LEAVE = "LEAVE",
    KICKED = "KICKED"
}
export interface VoiceChannelEventDTO {
    id: string;
    guildId: string;
    channelId: string;
    userId: string;
    actorId?: string | null;
    type: VoiceChannelEventType;
    createdAt: string;
    user: {
        id: string;
        username: string;
        displayName?: string | null;
        avatarUrl?: string | null;
    };
    actor?: {
        id: string;
        username: string;
        displayName?: string | null;
        avatarUrl?: string | null;
    } | null;
}
export interface VoiceChannelEventsResponse {
    items: VoiceChannelEventDTO[];
    hasMore: boolean;
    nextCursor?: string;
}
export type P2PTransferStatus = "pending_approval" | "connecting" | "transferring" | "paused" | "verifying" | "completed" | "cancelled" | "failed";
export interface P2PFileOfferPayload {
    fileId: string;
    channelId: string;
    senderId: string;
    senderName: string;
    recipientId: string;
    fileName: string;
    fileSize: number;
    mimeType: string;
    sha256?: string;
    batchId?: string;
    batchTotalFiles?: number;
    batchTotalBytes?: number;
    createdAt: number;
}
export interface P2PFileResponsePayload {
    fileId: string;
    channelId: string;
    senderId: string;
    targetUserId: string;
    action: "accept" | "reject";
    receivedOffset: number;
}
export interface P2PIceCandidateInit {
    candidate?: string;
    sdpMid?: string | null;
    sdpMLineIndex?: number | null;
    usernameFragment?: string | null;
}
export interface P2PFileSignalData {
    type: "offer" | "answer" | "candidate" | "heartbeat";
    sdp?: string;
    candidate?: P2PIceCandidateInit;
}
export type P2PFileControlMessage = {
    type: "PAUSE" | "RESUME" | "COMPLETE";
} | {
    type: "COMPLETE_ACK";
    receivedBytes: number;
};
export interface P2PFileSignalPayload {
    fileId: string;
    channelId: string;
    senderId: string;
    targetUserId: string;
    signal: P2PFileSignalData;
}
export interface P2PFileCancelPayload {
    fileId: string;
    channelId: string;
    senderId: string;
    targetUserId: string;
    reason?: string;
}
export declare const P2P_IPC_CHANNELS: {
    readonly SELECT_SAVE_PATH: "desktop:p2p:select-save-path";
    readonly SELECT_SAVE_DIRECTORY: "desktop:p2p:select-save-directory";
    readonly START_WRITE_STREAM: "desktop:p2p:start-write-stream";
    readonly WRITE_CHUNK: "desktop:p2p:write-chunk";
    readonly CLOSE_STREAM: "desktop:p2p:close-stream";
    readonly CANCEL_STREAM: "desktop:p2p:cancel-stream";
};
export interface DesktopP2PFileAPI {
    selectSavePath: (defaultFilename: string) => Promise<string | null>;
    selectSaveDirectory?: () => Promise<string | null>;
    startWriteStream: (streamId: string, filePath: string, startOffset?: number) => Promise<{
        success: boolean;
        filePath?: string;
        error?: string;
    }>;
    writeChunk: (streamId: string, chunk: Uint8Array | number[]) => Promise<{
        success: boolean;
        error?: string;
    }>;
    closeStream: (streamId: string) => Promise<{
        success: boolean;
        error?: string;
    }>;
    cancelStream: (streamId: string) => Promise<{
        success: boolean;
    }>;
}
export declare const P2PErrorCode: {
    readonly ICE_TIMEOUT: "p2p_ice_timeout";
    readonly ICE_FAILED: "p2p_ice_failed";
    readonly CHANNEL_ERROR: "p2p_channel_error";
    readonly CHANNEL_CLOSED: "p2p_channel_closed";
    readonly PEER_REJECTED: "p2p_peer_rejected";
    readonly REJECTED_BY_SELF: "p2p_rejected_by_self";
    readonly PEER_CANCELLED: "p2p_peer_cancelled";
    readonly CANCELLED_BY_SELF: "p2p_cancelled_by_self";
};
export type P2PErrorCode = (typeof P2PErrorCode)[keyof typeof P2PErrorCode];
export interface P2PFileTask {
    fileId: string;
    channelId: string;
    direction: "send" | "receive";
    peerId: string;
    peerName: string;
    fileName: string;
    fileSize: number;
    mimeType: string;
    sha256?: string;
    status: P2PTransferStatus;
    transferredBytes: number;
    speedBytesPerSec: number;
    etaSeconds: number;
    progress: number;
    error?: string;
    savePath?: string;
    batchId?: string;
    batchTotalFiles?: number;
    batchTotalBytes?: number;
    createdAt: number;
    updatedAt: number;
}
export interface DMCallOfferPayload {
    mediaEncryptionVersion?: number;
    channelId: string;
    hasVideo: boolean;
}
export interface DMCallActionPayload {
    mediaEncryptionVersion?: number;
    callId: string;
    reason?: string;
}
export interface DMCallStatePayload {
    callId: string;
    channelId: string;
    callerId: string;
    hasVideo: boolean;
    state: "ringing" | "active";
}
export interface DMCallIncomingPayload {
    callId: string;
    channelId: string;
    caller: Pick<User, "id" | "username" | "avatarUrl">;
    hasVideo: boolean;
    expiresAt?: string;
    remainingMs?: number;
}
export interface DMCallMissedPayload {
    callId: string;
    channelId: string;
    caller: Pick<User, "id" | "username" | "avatarUrl">;
    missedAt: string;
}
export interface DMCallAnsweredPayload {
    callId: string;
    channelId: string;
}
export interface DMCallEndedPayload {
    callId: string;
    channelId: string;
    endedBy: string;
    reason: string;
}
export type NATType = "FullCone" | "RestrictedCone" | "PortRestrictedCone" | "Symmetric" | "IPv6Direct" | "Unknown";
export interface P2PSignalPayload {
    voiceRoute?: import("./voice-routing.js").VoiceRelayRoute;
    /** Gateway-authenticated origin; clients cannot choose this session identity. */
    senderSessionId?: string;
    /** Voice offer/answer correlation; echoes the initiating offer through retries. */
    negotiationId?: string;
    guildId: string;
    channelId: string;
    callId?: string;
    senderId: string;
    targetId?: string;
    streamOwnerId: string;
    type: "OFFER" | "ANSWER" | "ICE_CANDIDATE" | "REQUEST_STREAM" | "TOPOLOGY_SYNC" | "FALLBACK_TO_SFU" | "VOICE_OFFER" | "VOICE_ANSWER" | "VOICE_ICE_CANDIDATE" | "VOICE_LEAVE" | "VOICE_RECONNECT_REQUEST" | "STREAM_WATCH_START" | "STREAM_WATCH_STOP" | "STREAM_KICK" | "REQUEST_STREAM_VIEWERS";
    sdp?: any;
    candidate?: any;
    transmissionMode?: StreamTransmissionMode;
    timestamp?: number;
}
export interface P2PNodeMetrics {
    userId: string;
    natType: NATType;
    hasIPv6: boolean;
    rtt: number;
    packetLoss: number;
    downstreamCount: number;
    maxDownstream: number;
}
export interface P2PTopologyNode {
    peerId: string;
    parentId: string | null;
    childrenIds: string[];
    transmissionMode: StreamTransmissionMode;
    metrics?: P2PNodeMetrics;
}
export interface P2PTopologyUpdatePayload {
    streamOwnerId: string;
    channelId: string;
    transmissionMode: StreamTransmissionMode;
    nodes: Record<string, P2PTopologyNode>;
    myParentId?: string | null;
    myChildrenIds?: string[];
}
export interface P2PNetworkDiagnostics {
    transmissionMode: StreamTransmissionMode;
    natType: NATType;
    hasIPv6: boolean;
    activeCandidatePair?: {
        localCandidateType: string;
        remoteCandidateType: string;
        protocol: string;
        localAddress?: string;
        remoteAddress?: string;
    };
    rtt?: number;
    packetLoss?: number;
    relayParentName?: string;
    downstreamPeersCount: number;
}
export interface TypingIndicatorPayload {
    channelId: string;
    userId: string;
    user: {
        id: string;
        username: string;
        displayName?: string | null;
        nickname?: string | null;
        avatarUrl?: string | null;
        isBot?: boolean;
    };
    timestamp: number;
}
export interface TypingStopPayload {
    channelId: string;
    userId: string;
    timestamp: number;
}
export type ScreenShareResolution = "480p" | "720p" | "1080p" | "1440p" | "4k";
export type ScreenShareFps = 15 | 30 | 60;
export interface ScreenSharePreset {
    id: string;
    name: string;
    width: number;
    height: number;
    frameRate: ScreenShareFps;
    bitrate: number;
    description: string;
}
export interface ResolutionInfo {
    id: ScreenShareResolution;
    label: string;
    width: number;
    height: number;
    description: string;
}
export declare const RESOLUTION_OPTIONS: ResolutionInfo[];
export declare const FPS_OPTIONS: ScreenShareFps[];
export declare function getRecommendedBitrate(resolution: ScreenShareResolution, fps: ScreenShareFps): number;
/**
 * 根据屏幕物理像素尺寸 (宽, 高)，按 16:9 比例计算该屏幕所支持的最大标准 16:9 分辨率档位。
 * 支持 16:10、21:9、3:2 等非标比例屏幕安全等比内接映射。
 */
export declare function getMaxAllowed16x9Resolution(screenWidth?: number, screenHeight?: number): ScreenShareResolution;
/**
 * 判定目标分辨率是否被最大允许分辨率支持 (基于 480p < 720p < 1080p < 1440p < 4k 顺序)
 */
export declare function isResolutionAllowed(target: ScreenShareResolution, maxAllowed: ScreenShareResolution): boolean;
export declare const SCREEN_SHARE_PRESETS: Record<string, ScreenSharePreset>;
export interface SimulcastLayer {
    rid: "f" | "h" | "q";
    width: number;
    height: number;
    maxBitrate: number;
    maxFramerate: number;
}
export declare function computeSimulcastLayers(baseWidth: number, baseHeight: number, baseFps: number, baseBitrate: number): SimulcastLayer[];
export interface DesktopSource {
    id: string;
    name: string;
    thumbnail: string;
    type: "screen" | "window";
    appIcon?: string;
    displayDimensions?: {
        width: number;
        height: number;
    };
}
export interface ScreenShareOptions {
    sourceId?: string;
    sourceType?: "screen" | "window";
    preset: string;
    captureAudio: boolean;
    simulcast: boolean;
    mixedAudio?: boolean;
    videoCodec?: VideoCodecType;
    customBitrate?: number;
}
export interface DesktopToastPayload extends DesktopNotificationPayload {
    id: string;
    closeLabel: string;
}
export interface DesktopNotificationPayload {
    title: string;
    body: string;
    channelId?: string;
    guildId?: string;
    guildName?: string;
    channelName?: string;
    icon?: string;
    avatarUrl?: string;
    senderName?: string;
    timestamp?: number;
    silent?: boolean;
}
export interface DesktopQuitPromptPayload {
    inVoice: boolean;
    isUploading: boolean;
}
export interface UserNotificationSettings {
    enabled: boolean;
    directMessages: boolean;
    mentions: boolean;
    calls: boolean;
    p2pTransfers: boolean;
    soundEnabled: boolean;
}
export declare const DEFAULT_USER_NOTIFICATION_SETTINGS: UserNotificationSettings;
export interface DesktopUnreadStatePayload {
    hasUnread: boolean;
}
export interface AutoLaunchSettings {
    enabled: boolean;
    openAsHidden: boolean;
}
export type DesktopWindowMode = "auth" | "main";
export type DesktopWindowType = "auth" | "main";
export interface DesktopAuthSuccessPayload {
    userId?: string;
    username?: string;
}
export interface DesktopAuthSessionState {
    hasSession: boolean;
    lastUserId?: string;
    lastUsername?: string;
}
export interface DesktopWindowBounds {
    x?: number;
    y?: number;
    width: number;
    height: number;
    isMaximized?: boolean;
}
export interface DesktopWindowModeOptions {
    mode: DesktopWindowMode;
    animate?: boolean;
    center?: boolean;
}
export interface DesktopWindowState {
    isMaximized: boolean;
    platform: string;
    mode?: DesktopWindowMode;
}
export type WindowControlAction = "minimize" | "maximize" | "close";
export type VideoViewMode = "grid" | "theater" | "pip" | "fullscreen";
export interface PipStreamSource {
    id: string;
    userId: string;
    username: string;
    avatarUrl?: string;
    type: "screen" | "camera";
    streamMode?: StreamTransmissionMode;
    isLocal: boolean;
    codec?: string;
    title?: string;
}
export interface PipWindowGeometry {
    x: number;
    y: number;
    width: number;
    height: number;
}
export declare function bytesToBase64(bytes: Uint8Array): string;
export declare function base64ToBytes(base64: string): Uint8Array;
export declare function bytesToHex(bytes: Uint8Array): string;
export declare function hexToBytes(hex: string): Uint8Array;
export interface SecurityHeadersConfig {
    strictTransportSecurity: string;
    contentSecurityPolicy: string;
    xContentTypeOptions: string;
    xFrameOptions: string;
    referrerPolicy: string;
    permissionsPolicy: string;
}
export declare function buildSecurityHeaders(custom?: Partial<SecurityHeadersConfig>): Record<string, string>;
export interface DtlsSrtpConfig {
    cipherSuites: string[];
    dtlsRole: "auto" | "client" | "server";
    requireDtlsSrtp: boolean;
}
export declare function validateDtlsSrtpParameters(config: DtlsSrtpConfig): {
    valid: boolean;
    reasons: string[];
};
export interface SFrameConfig {
    enabled: boolean;
    keyId: number;
    passphrase?: string;
}
export interface SFrameHeader {
    kid: number;
    counter: bigint;
    headerLength: number;
}
/** RFC 9605 section 4.3 compact, unsigned, big-endian header. */
export declare function encodeSFrameHeader(kid: number, counter: bigint | number): Uint8Array;
export declare function decodeSFrameHeader(buffer: Uint8Array): SFrameHeader;
interface SFrameDerivedKey {
    key: CryptoKey;
    salt: Uint8Array;
}
/** AES_256_GCM_SHA512_128 (0x0005), RFC 9605 section 4.4.2. */
export declare function deriveSFrameKey(keyBuffer: Uint8Array, kid: number): Promise<SFrameDerivedKey>;
export declare function encryptSFramePacket(rawPcmOrOpus: Uint8Array, keyBuffer: Uint8Array, kid: number, counter: bigint | number, metadata?: Uint8Array<ArrayBuffer>): Promise<Uint8Array>;
export declare function decryptSFramePacket(sframePacket: Uint8Array, keyBuffer: Uint8Array, metadata?: Uint8Array<ArrayBuffer>): Promise<{
    decryptedPayload: Uint8Array;
    header: SFrameHeader;
}>;
export declare class SFrameReplayFilter {
    private windowSize;
    private maxCounter;
    private windowBitmask;
    constructor(windowSize?: number);
    checkAndAdd(counter: bigint | number): boolean;
}
export interface EncryptedMessageEnvelope {
    version: number;
    senderId: string;
    channelId: string;
    ephemeralPublicKey: string;
    sequenceNumber: number;
    previousChainLength: number;
    ciphertext: string;
    iv: string;
    tag: string;
    fingerprint: string;
}
export interface DevicePreKeyBundle {
    userId: string;
    identityKey: string;
    signedPreKey: string;
    signature: string;
    oneTimePreKeys: string[];
    createdAt: string;
}
export interface RegisterPreKeyDTO {
    identityKey: string;
    signedPreKey: string;
    signature: string;
    oneTimePreKeys?: string[];
}
export interface E2eeKeyExchangePayload {
    channelId: string;
    senderId: string;
    recipientId?: string;
    ephemeralKey: string;
    encryptedKeyData: string;
    timestamp: number;
}
export declare function generateDhKeyPair(): Promise<CryptoKeyPair>;
export declare function exportDhPublicKey(key: CryptoKey): Promise<string>;
export declare function importDhPublicKey(base64: string): Promise<CryptoKey>;
export declare function computeDhSecret(privateKey: CryptoKey, publicKey: CryptoKey): Promise<Uint8Array>;
export declare function kdfRootKey(rootKey: Uint8Array, dhSecret: Uint8Array): Promise<{
    nextRootKey: Uint8Array;
    chainKey: Uint8Array;
}>;
export declare function kdfChainKey(chainKey: Uint8Array): Promise<{
    nextChainKey: Uint8Array;
    messageKey: Uint8Array;
}>;
export declare function computeFingerprint(pubBase64: string): Promise<string>;
export interface SafetyNumberInfo {
    safetyNumber: string;
    formattedSafetyNumber: string;
    fingerprintA: string;
    fingerprintB: string;
}
export declare function computeSafetyNumber(pubKeyA: string, pubKeyB: string): Promise<SafetyNumberInfo>;
export declare function encryptMessageWithKey(plaintext: string, messageKey: Uint8Array, associatedData: Uint8Array): Promise<{
    ciphertext: string;
    iv: string;
    tag: string;
}>;
export declare function decryptMessageWithKey(ciphertextBase64: string, ivBase64: string, tagBase64: string, messageKey: Uint8Array, associatedData: Uint8Array): Promise<string>;
export declare class DoubleRatchetSession {
    localUserId: string;
    peerUserId: string;
    private rootKey;
    private sendingChainKey;
    private receivingChainKey;
    private localDhKeyPair;
    private localDhPublicKeyB64;
    private remoteDhPublicKey;
    private remoteDhPublicKeyB64;
    private sendingSeq;
    private receivingSeq;
    private previousChainLength;
    private skippedMessageKeys;
    private isChannelMode;
    private channelId;
    private channelReceivingChains;
    private cachedFingerprint;
    constructor(localUserId: string, peerUserId: string, rootKey: Uint8Array);
    initAsAlice(peerDhPublicKey: CryptoKey | string): Promise<void>;
    initAsBob(bobDhKeyPair: CryptoKeyPair): Promise<void>;
    initAsChannel(channelId: string, currentUserId: string): Promise<void>;
    ratchetEncrypt(plaintext: string, channelId?: string): Promise<EncryptedMessageEnvelope>;
    ratchetDecrypt(envelope: EncryptedMessageEnvelope): Promise<string>;
    private saveSkippedMessageKey;
    private skipMessageKeys;
    getFingerprint(): string;
    getSafetyNumber(): Promise<string>;
}
export interface FtsDocument {
    id: string;
    channelId: string;
    authorId: string;
    content: string;
    createdAt: string;
}
export interface FtsSearchResult extends FtsDocument {
    score: number;
}
export declare function tokenizeText(text: string): string[];
export declare class ClientSideFtsEngine {
    private documents;
    private invertedIndex;
    addDocument(doc: FtsDocument): void;
    removeDocument(id: string): void;
    search(query: string, filterChannelId?: string): FtsSearchResult[];
    clear(): void;
    get size(): number;
}
export type SupportedLocale = "zh-CN" | "en-US" | "ja-JP" | "zh-TW" | "zh-HK";
export interface LocaleOption {
    code: SupportedLocale;
    label: string;
    englishName: string;
    nativeName: string;
}
export declare const SUPPORTED_LOCALES: LocaleOption[];
export declare enum ErrorCode {
    INTERNAL_ERROR = "INTERNAL_ERROR",
    AUDIO_INPUT_SWITCH_FAILED = "AUDIO_INPUT_SWITCH_FAILED",
    AUDIO_DEVICE_SWITCH_FAILED = "AUDIO_DEVICE_SWITCH_FAILED",
    AUDIO_DEVICE_UNSUPPORTED = "AUDIO_DEVICE_UNSUPPORTED",
    AUDIO_PROCESSING_UNSUPPORTED = "AUDIO_PROCESSING_UNSUPPORTED",
    INVALID_PARAMS = "INVALID_PARAMS",
    NOT_FOUND = "NOT_FOUND",
    UNAUTHORIZED = "UNAUTHORIZED",
    FORBIDDEN = "FORBIDDEN",
    RATE_LIMITED = "RATE_LIMITED",
    BOT_REVOKED = "BOT_REVOKED",
    BOT_DEVICE_CONFLICT = "BOT_DEVICE_CONFLICT",
    BOT_DEVICE_REVOKED = "BOT_DEVICE_REVOKED",
    INTERACTION_EXPIRED = "INTERACTION_EXPIRED",
    INTERACTION_ALREADY_ACKNOWLEDGED = "INTERACTION_ALREADY_ACKNOWLEDGED",
    MESSAGE_EDIT_CONFLICT = "MESSAGE_EDIT_CONFLICT",
    AUTH_INVALID_CREDENTIALS = "AUTH_INVALID_CREDENTIALS",
    AUTH_TOKEN_EXPIRED = "AUTH_TOKEN_EXPIRED",
    AUTH_USER_NOT_FOUND = "AUTH_USER_NOT_FOUND",
    AUTH_USER_EXISTS = "AUTH_USER_EXISTS",
    AUTH_USERNAME_TAKEN = "AUTH_USERNAME_TAKEN",
    AUTH_EMAIL_TAKEN = "AUTH_EMAIL_TAKEN",
    AUTH_PASSWORD_TOO_WEAK = "AUTH_PASSWORD_TOO_WEAK",
    AUTH_ACCOUNT_DISABLED = "AUTH_ACCOUNT_DISABLED",
    AUTH_ACCOUNT_DELETION_PENDING = "AUTH_ACCOUNT_DELETION_PENDING",
    AUTH_REAUTH_REQUIRED = "AUTH_REAUTH_REQUIRED",
    WEBAUTHN_NOT_SUPPORTED = "WEBAUTHN_NOT_SUPPORTED",
    WEBAUTHN_CHALLENGE_EXPIRED = "WEBAUTHN_CHALLENGE_EXPIRED",
    WEBAUTHN_VERIFICATION_FAILED = "WEBAUTHN_VERIFICATION_FAILED",
    WEBAUTHN_CREDENTIAL_EXISTS = "WEBAUTHN_CREDENTIAL_EXISTS",
    WEBAUTHN_CREDENTIAL_NOT_FOUND = "WEBAUTHN_CREDENTIAL_NOT_FOUND",
    GUILD_NOT_FOUND = "GUILD_NOT_FOUND",
    GUILD_NAME_REQUIRED = "GUILD_NAME_REQUIRED",
    GUILD_PERMISSION_DENIED = "GUILD_PERMISSION_DENIED",
    GUILD_CREATION_RESTRICTED = "GUILD_CREATION_RESTRICTED",
    GUILD_INVITE_INVALID = "GUILD_INVITE_INVALID",
    GUILD_INVITE_EXPIRED = "GUILD_INVITE_EXPIRED",
    GUILD_ALREADY_MEMBER = "GUILD_ALREADY_MEMBER",
    GUILD_CANNOT_LEAVE_OWNER = "GUILD_CANNOT_LEAVE_OWNER",
    GUILD_ROLE_NOT_FOUND = "GUILD_ROLE_NOT_FOUND",
    GUILD_ROLE_CANNOT_DELETE_DEFAULT = "GUILD_ROLE_CANNOT_DELETE_DEFAULT",
    GUILD_ROLE_HIERARCHY_TOO_LOW = "GUILD_ROLE_HIERARCHY_TOO_LOW",
    CHANNEL_NOT_FOUND = "CHANNEL_NOT_FOUND",
    CHANNEL_NAME_REQUIRED = "CHANNEL_NAME_REQUIRED",
    CHANNEL_PERMISSION_DENIED = "CHANNEL_PERMISSION_DENIED",
    CHANNEL_OVERWRITE_NOT_FOUND = "CHANNEL_OVERWRITE_NOT_FOUND",
    CHANNEL_HIERARCHY_VIOLATION = "CHANNEL_HIERARCHY_VIOLATION",
    CATEGORY_NOT_FOUND = "CATEGORY_NOT_FOUND",
    CATEGORY_NAME_REQUIRED = "CATEGORY_NAME_REQUIRED",
    MESSAGE_NOT_FOUND = "MESSAGE_NOT_FOUND",
    MESSAGE_EMPTY = "MESSAGE_EMPTY",
    MESSAGE_TOO_LARGE = "MESSAGE_TOO_LARGE",
    FILE_TOO_LARGE = "FILE_TOO_LARGE",
    FILE_TYPE_UNSUPPORTED = "FILE_TYPE_UNSUPPORTED",
    ICON_PROCESS_TIMEOUT = "ICON_PROCESS_TIMEOUT",
    UPLOAD_FAILED = "UPLOAD_FAILED",
    EMOJI_NOT_FOUND = "EMOJI_NOT_FOUND",
    EMOJI_LIMIT_REACHED = "EMOJI_LIMIT_REACHED",
    EMOJI_NAME_INVALID = "EMOJI_NAME_INVALID",
    EMOJI_FILE_TOO_LARGE = "EMOJI_FILE_TOO_LARGE",
    STICKER_PACK_NOT_FOUND = "STICKER_PACK_NOT_FOUND",
    STICKER_NOT_FOUND = "STICKER_NOT_FOUND",
    STICKER_PARSE_FAILED = "STICKER_PARSE_FAILED",
    STICKER_URL_INVALID = "STICKER_URL_INVALID",
    STICKER_ALREADY_INSTALLED = "STICKER_ALREADY_INSTALLED",
    STICKER_LIMIT_REACHED = "STICKER_LIMIT_REACHED",
    STICKER_UPSTREAM_UNAVAILABLE = "STICKER_UPSTREAM_UNAVAILABLE",
    TELEGRAM_BOT_TOKEN_REQUIRED = "TELEGRAM_BOT_TOKEN_REQUIRED",
    MEDIA_E2EE_UNSUPPORTED = "MEDIA_E2EE_UNSUPPORTED",
    MEDIA_KEY_UNAVAILABLE = "MEDIA_KEY_UNAVAILABLE",
    MEDIA_CONTEXT_STALE = "MEDIA_CONTEXT_STALE",
    MEDIA_SESSION_UNAVAILABLE = "MEDIA_SESSION_UNAVAILABLE",
    MEDIA_KEY_INVALID = "MEDIA_KEY_INVALID",
    MEDIA_NEGOTIATION_TIMEOUT = "MEDIA_NEGOTIATION_TIMEOUT",
    VOICE_ROOM_FULL = "VOICE_ROOM_FULL",
    VOICE_JOIN_FAILED = "VOICE_JOIN_FAILED",
    VOICE_PERMISSION_DENIED = "VOICE_PERMISSION_DENIED",
    VOICE_USER_NOT_CONNECTED = "VOICE_USER_NOT_CONNECTED",
    CANNOT_MANAGE_MEMBER = "CANNOT_MANAGE_MEMBER",
    ADMIN_REQUIRED = "ADMIN_REQUIRED",
    ADMIN_CANNOT_BAN_SELF = "ADMIN_CANNOT_BAN_SELF",
    ADMIN_CANNOT_DELETE_SELF = "ADMIN_CANNOT_DELETE_SELF",
    ADMIN_PASSWORD_INVALID = "ADMIN_PASSWORD_INVALID",
    DATABASE_BACKUP_FAILED = "DATABASE_BACKUP_FAILED",
    DATABASE_OPTIMIZE_FAILED = "DATABASE_OPTIMIZE_FAILED",
    STORAGE_GC_FAILED = "STORAGE_GC_FAILED",
    OPERATION_CANCELLED = "OPERATION_CANCELLED"
}
export interface ApiErrorResponse {
    code?: ErrorCode | string;
    error: string;
    details?: Record<string, any>;
}
export declare const MAX_MESSAGE_CONTENT_LENGTH = 4000;
export declare const MAX_ENCRYPTED_ENVELOPE_LENGTH: number;
export interface CreateGuildRequest {
    name: string;
    iconUrl?: string | null;
    description?: string | null;
    isPublic?: boolean;
    locale?: SupportedLocale;
}
export interface AdminOverviewStats {
    totalUsers: number;
    onlineUsers: number;
    totalGuilds: number;
    totalMessages: number;
    uptimeSeconds: number;
    memoryUsageMb: number;
}
export interface AdminUserItem extends User {
    guildCount: number;
    messageCount: number;
    isBanned: boolean;
    role: SystemRole;
}
export interface AdminUpdateUserDTO {
    role?: SystemRole;
    isBanned?: boolean;
    resetPassword?: boolean;
}
export declare function isAdminUpdateUserDTO(value: unknown): value is AdminUpdateUserDTO;
export interface AdminUpdateUserResult {
    user: AdminUserItem;
    temporaryPassword?: string;
}
export interface PageInfo {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
}
export interface PaginatedResult<T> {
    items: T[];
    pageInfo: PageInfo;
}
export interface AdminGuildItem {
    id: string;
    name: string;
    iconUrl?: string | null;
    description?: string | null;
    ownerId: string;
    ownerName: string;
    memberCount: number;
    channelCount: number;
    createdAt: string;
}
export interface SystemBroadcastDTO {
    id: string;
    title: string;
    content: string;
    severity: "INFO" | "WARNING" | "CRITICAL";
    senderName: string;
    createdAt: string;
}
export interface SystemSettingsDTO {
    allowRegistration: boolean;
    requireInviteCode?: boolean;
    maintenanceMode?: boolean;
    systemAnnouncement?: string;
    allowNonSuperAdminCreateGuild?: boolean;
    trustedDomains?: string[];
}
export interface TrustedDomainsResponse {
    domains: string[];
}
export declare function parseTrustedDomains(value: unknown): string[] | null;
export interface RegistrationStatusResponse {
    allowRegistration: boolean;
    requireInviteCode: boolean;
    allowNonSuperAdminCreateGuild?: boolean;
}
export interface CustomEmoji {
    id: string;
    name: string;
    imageUrl: string;
    animated: boolean;
    guildId?: string | null;
    userId?: string | null;
    createdById?: string | null;
    createdAt: string;
    updatedAt?: string;
}
export interface CreateCustomEmojiDTO {
    name: string;
    imageUrl: string;
    animated?: boolean;
    guildId?: string;
}
export interface RegistrationInviteDTO {
    code: string;
    note?: string | null;
    createdById: string;
    createdByName?: string;
    maxUses: number;
    uses: number;
    isRevoked: boolean;
    expiresAt?: string | null;
    createdAt: string;
    updatedAt: string;
    registeredUserCount?: number;
}
export interface CreateRegistrationInviteDTO {
    note?: string;
    maxUses?: number;
    expiresInDays?: number | null;
    customCode?: string;
}
export interface RegistrationInviteListResponse {
    invites: RegistrationInviteDTO[];
    total: number;
    page: number;
    pageSize: number;
}
export interface MaintenanceUpdatePayload {
    enabled: boolean;
    announcement?: string;
    estimatedEndTime?: string | null;
    triggeredAt?: string;
}
export interface AdminStorageStats {
    totalUsedBytes: number;
    activeAttachmentBytes: number;
    activeAttachmentCount: number;
    orphanedAttachmentBytes: number;
    orphanedAttachmentCount: number;
    orphanedDraftBytes: number;
    orphanedDraftCount: number;
    lastGcTimestamp?: number | null;
}
export interface AdminGcResult {
    success: boolean;
    deletedAttachmentRecords: number;
    deletedPhysicalFiles: number;
    freedBytes: number;
    durationMs: number;
    executedAt: number;
}
export interface AdminUserGuildMembership {
    guildId: string;
    guildName: string;
    guildIconUrl?: string | null;
    isOwner: boolean;
    joinedAt: string;
}
export interface AdminUserBotItem {
    id: string;
    name: string;
    clientId?: string;
    createdAt: string;
}
export interface AdminUserDetailsResponse {
    user: AdminUserItem;
    createdAt: string;
    lastActiveAt?: string | null;
    ownedGuildCount: number;
    guilds: AdminUserGuildMembership[];
    bots: AdminUserBotItem[];
}
export interface AdminEditUserProfileDTO {
    email?: string;
    username?: string;
    displayName?: string | null;
    clearAvatar?: boolean;
}
export declare function isAdminEditUserProfileDTO(value: unknown): value is AdminEditUserProfileDTO;
export interface AdminSoftDeleteUserDTO {
    adminPassword?: string;
    securityCode?: string;
    deleteCreatedBots?: boolean;
    dissolveOwnedGuilds?: boolean;
}
export declare function isAdminSoftDeleteUserDTO(value: unknown): value is AdminSoftDeleteUserDTO;
export interface AdminDatabaseTableStat {
    tableName: string;
    rowCount: number;
}
export interface AdminDatabaseStats {
    databaseType: "sqlite" | "postgres";
    databaseSizeBytes: number;
    walSizeBytes?: number;
    tables: AdminDatabaseTableStat[];
    lastOptimizedAt?: number | null;
}
export interface AdminDatabaseOptimizeResult {
    success: boolean;
    message?: string;
    durationMs: number;
    executedAt: number;
}
export interface AdminCacheClearResult {
    success: boolean;
    clearedKeys?: number;
    durationMs: number;
    executedAt: number;
}
export interface AdminDataPruneDTO {
    retentionDays?: number;
    pruneOrphanDrafts?: boolean;
    pruneRevokedInvites?: boolean;
}
export declare function isAdminDataPruneDTO(value: unknown): value is AdminDataPruneDTO;
export interface AdminDataPruneResult {
    success: boolean;
    prunedInvites: number;
    prunedDrafts: number;
    durationMs: number;
    executedAt: number;
}
export interface CreateDMDTO {
    recipientId: string;
}
export interface ChannelRecipientInfo {
    userId: string;
    isClosed: boolean;
    lastReadAt: string;
    lastReadSequence: number;
    user: User;
}
export type DMCallState = "ringing" | "connecting" | "active" | "ended";
export interface DMCallSession {
    callId: string;
    channelId: string;
    callerId: string;
    calleeId: string;
    hasVideo: boolean;
    state: DMCallState;
    callerSessionId?: string;
    acceptedSessionId?: string;
    createdAt: string;
    expiresAt: string;
    endedReason?: string;
}
export interface CallOfferPayload {
    callId: string;
    channelId: string;
    caller: Pick<User, "id" | "username" | "avatarUrl">;
    hasVideo: boolean;
    expiresAt: string;
}
export interface CallAnswerPayload {
    callId: string;
    channelId: string;
    responderId: string;
    acceptedSessionId: string;
}
export interface CallRejectPayload {
    callId: string;
    channelId: string;
    rejecterId: string;
    reason?: string;
}
export interface CallEndPayload {
    callId: string;
    channelId: string;
    endedBy: string;
    reason?: string;
}
export interface DMCallTokenResponse {
    token: string;
    callId: string;
    roomName: string;
    serverUrl: string;
}
export interface RegisterDeviceKeyDTO {
    deviceId: string;
    signingPublicKey: string;
    agreementPublicKey: string;
    fingerprint: string;
}
export interface DevicePublicKey extends RegisterDeviceKeyDTO {
    userId: string;
    createdAt: string;
    updatedAt: string;
}
export interface MediaKeyEnvelopePayload {
    channelId: string;
    callId: string;
    senderId: string;
    senderDeviceId: string;
    recipientId: string;
    recipientDeviceId: string;
    ephemeralPublicKey: string;
    senderSigningPublicKey: string;
    senderFingerprint: string;
    iv: string;
    ciphertext: string;
    signature: string;
    createdAt: string;
}
export interface MarkDMReadDTO {
    lastReadSequence: number;
}
export interface GetMessagesQueryDTO {
    limit?: number | string;
    before?: number | string;
    after?: number | string;
    aroundMessageId?: string;
    unreadAfter?: number | string;
}
export interface ChannelMetaRecord {
    channelId: string;
    lastReadSequence: number;
    scrollTop: number;
    isNearBottom: boolean;
    lastVisitedAt: number;
    anchorMessageId?: string | null;
    anchorOffset?: number | null;
}
export type UpdaterState = "disabled" | "idle" | "checking" | "downloading" | "verifying" | "extracting" | "ready" | "error";
export interface UpdateManifest {
    version: string;
    releaseTag?: string;
    releaseDate: string;
    minHostVersion: string;
    webPackageUrl: string;
    webPackageSha256: string;
    changelog?: string;
    mandatory?: boolean;
    hostInstallers?: {
        windows?: {
            url: string;
            sha256?: string;
        };
        macOS?: {
            url: string;
            sha256?: string;
        };
        linux?: {
            url: string;
            sha256?: string;
        };
    };
}
export interface UpdateCheckResult {
    enabled: boolean;
    hasUpdate: boolean;
    currentHostVersion: string;
    currentWebVersion: string;
    latestVersion?: string;
    isHostUpdateRequired?: boolean;
    manifest?: UpdateManifest;
    error?: string;
}
export interface UpdateProgress {
    state: UpdaterState;
    percent: number;
    transferredBytes: number;
    totalBytes: number;
    speedBytesPerSec?: number;
    error?: string;
}
export interface UpdaterConfig {
    enabled: boolean;
    currentHostVersion: string;
    currentWebVersion: string;
    gitRepo: string | null;
    preferredProxy: string;
    customProxy?: string;
    lastCheckedAt?: string;
}
export interface SetCustomProxyDTO {
    proxyUrl: string;
}
export type VoiceMediaEngine = "livekit" | "cloudflare_realtime" | "p2p_mesh";
export interface CfCallsSessionDescription {
    type: "offer" | "answer";
    sdp: string;
}
export interface CfCallsTrackInfo {
    location: "local" | "remote";
    trackName: string;
    mid?: string;
    sessionId?: string;
    errorCode?: string;
    errorDescription?: string;
}
export interface CfCallsCreateSessionResponse {
    sessionId: string;
    tracks?: CfMediaPublication[];
    tracksRevision?: number;
    requiresE2EE?: boolean;
}
export interface CfCallsHeartbeatResponse {
    active: boolean;
}
export interface CfCallsCreateSessionRequest {
    channelId: string;
    /** Required for a DM call, omitted for a guild voice channel. */
    callId?: string;
    /** The identified Gateway connection that owns this DM call. */
    gatewaySessionId?: string;
}
export interface CfMediaPublication {
    sessionId: string;
    userId: string;
    channelId: string;
    trackName: string;
    mid?: string;
    kind: "audio" | "video";
    source: "microphone" | "camera" | "screen" | "screen-audio";
}
export interface CfMediaTracksEvent {
    revision?: number;
    channelId: string;
    tracks: CfMediaPublication[];
}
/** A stream is identified by the host's Cloudflare media session. */
export interface CfStreamWatchRequest {
    channelId: string;
    sessionId: string;
    publisherSessionId: string;
}
export interface CfStreamViewersEvent {
    channelId: string;
    publisherSessionId: string;
    hostUserId: string;
    viewerCount: number;
}
export interface CfStreamWatchState extends CfStreamViewersEvent {
    watching: boolean;
}
export interface CfCallsPublishTrackRequest {
    channelId: string;
    sessionId: string;
    sessionDescription: CfCallsSessionDescription;
    tracks: Array<{
        mid: string;
        trackName: string;
        kind: "audio" | "video";
        source: "microphone" | "camera" | "screen" | "screen-audio";
    }>;
}
export interface CfCallsPublishTrackResponse {
    sessionDescription: CfCallsSessionDescription;
    requiresImmediateRenegotiation?: boolean;
    tracks: CfCallsTrackInfo[];
}
export interface CfCallsSubscribeTrackRequest {
    channelId: string;
    sessionId: string;
    tracks: Array<{
        publisherSessionId: string;
        trackName: string;
    }>;
}
export interface CfCallsSubscribeTrackResponse {
    sessionDescription?: CfCallsSessionDescription;
    requiresImmediateRenegotiation?: boolean;
    tracks: CfCallsTrackInfo[];
}
export interface CfCallsRenegotiateRequest {
    sessionId: string;
    sessionDescription: CfCallsSessionDescription;
}
export interface CfCallsCloseTracksRequest {
    sessionId: string;
    tracks: Array<{
        mid?: string;
        trackName?: string;
    }>;
    sessionDescription?: CfCallsSessionDescription;
}
export interface CfCallsUnsubscribeRequest {
    channelId: string;
    sessionId: string;
    tracks: Array<{
        mid: string;
    }>;
}
export interface CfRealtimeConfigResponse {
    enabled: boolean;
    sfuEnabled: boolean;
    turnEnabled: boolean;
}
export interface CfTurnIceServersResponse {
    iceServers: Array<{
        urls: string | string[];
        username?: string;
        credential?: string;
    }>;
    expiresAt: number;
}
export interface StoredActiveTokens {
    accessToken: string;
    refreshToken: string;
    user: User;
    remember: boolean;
    updatedAt: number;
}
export interface StorageSearchMessagesQuery {
    keyword: string;
    channelId?: string;
    limit?: number;
}
export interface StorageChannelSnapshot {
    messages: Message[];
    meta: ChannelMetaRecord;
}
export interface StorageStats {
    adapterType: "sqlite" | "indexeddb";
    appDbSize?: number;
    userDbSize?: number;
    messageCount?: number;
    isEncryptionAvailable?: boolean;
}
export type StorageItemId = "chromium_cache" | "offline_messages" | "ai_models" | "update_packages" | "local_storage";
export interface StorageItemDetail {
    id: StorageItemId;
    bytes: number;
    itemCount?: number;
    isAvailableOnPlatform: boolean;
    isSafeToClear: boolean;
}
export interface ClientStorageDetailedStats {
    totalBytes: number;
    items: {
        chromiumCache?: StorageItemDetail;
        offlineMessages: StorageItemDetail;
        aiModels: StorageItemDetail;
        updatePackages?: StorageItemDetail;
        localStorage?: StorageItemDetail;
    };
    quotaBytes?: number;
    isElectron: boolean;
}
export interface StorageClearOptions {
    clearChromiumCache?: boolean;
    clearOfflineMessages?: boolean;
    clearAiModels?: boolean;
    clearUpdatePackages?: boolean;
    vacuumDatabase?: boolean;
}
export declare function isStorageClearOptions(value: unknown): value is StorageClearOptions;
export interface StorageClearResult {
    freedBytes: number;
    clearedItems: StorageItemId[];
    success: boolean;
    error?: string;
}
export interface IStorageAdapter {
    getPreference<T = any>(key: string): Promise<T | null>;
    setPreference<T = any>(key: string, value: T): Promise<void>;
    removePreference(key: string): Promise<void>;
    getSavedAccounts(): Promise<SavedAccount[]>;
    saveSavedAccounts(accounts: SavedAccount[]): Promise<void>;
    getActiveTokens(): Promise<StoredActiveTokens | null>;
    setActiveTokens(tokens: {
        accessToken: string;
        refreshToken: string;
        user: User;
    }, remember: boolean): Promise<void>;
    clearActiveTokens(): Promise<void>;
    switchUser(userId: string | null): Promise<void>;
    saveMessages(channelId: string, messages: Message[]): Promise<void>;
    saveMessage(msg: Message): Promise<void>;
    reconcileChannelMessages(channelId: string, authoritativeMessages: Message[], range: {
        minSequence: number;
        maxSequence: number;
    }): Promise<void>;
    getLatestMessages(channelId: string, limit?: number): Promise<Message[]>;
    getChannelSnapshot(channelId: string, limit?: number): Promise<StorageChannelSnapshot>;
    deleteMessage(messageId: string): Promise<void>;
    saveChannelMeta(channelId: string, meta: Partial<ChannelMetaRecord>): Promise<void>;
    getChannelMeta(channelId: string): Promise<ChannelMetaRecord | null>;
    clearChannel(channelId: string): Promise<void>;
    clearAllMessages(): Promise<void>;
    searchMessages(query: StorageSearchMessagesQuery): Promise<Message[]>;
    getStorageStats?(): Promise<StorageStats>;
    getDetailedStorageStats?(): Promise<ClientStorageDetailedStats>;
    clearStorageBatch?(options: StorageClearOptions): Promise<StorageClearResult>;
    vacuumDatabase?(): Promise<void>;
}
export declare const STORAGE_IPC_CHANNELS: {
    readonly PREF_GET: "storage:pref-get";
    readonly PREF_SET: "storage:pref-set";
    readonly PREF_REMOVE: "storage:pref-remove";
    readonly ACCOUNTS_GET: "storage:accounts-get";
    readonly ACCOUNTS_SAVE: "storage:accounts-save";
    readonly TOKENS_GET: "storage:tokens-get";
    readonly TOKENS_SET: "storage:tokens-set";
    readonly TOKENS_CLEAR: "storage:tokens-clear";
    readonly USER_SWITCH: "storage:user-switch";
    readonly MESSAGES_SAVE_BATCH: "storage:messages-save-batch";
    readonly MESSAGES_RECONCILE: "storage:messages-reconcile";
    readonly MESSAGE_SAVE_SINGLE: "storage:message-save-single";
    readonly MESSAGES_GET_LATEST: "storage:messages-get-latest";
    readonly CHANNEL_SNAPSHOT_GET: "storage:channel-snapshot-get";
    readonly MESSAGE_DELETE: "storage:message-delete";
    readonly CHANNEL_META_SAVE: "storage:channel-meta-save";
    readonly CHANNEL_META_GET: "storage:channel-meta-get";
    readonly CHANNEL_CLEAR: "storage:channel-clear";
    readonly MESSAGES_CLEAR_ALL: "storage:messages-clear-all";
    readonly MESSAGES_SEARCH_FTS: "storage:messages-search-fts";
    readonly STATS_GET: "storage:stats-get";
    readonly STATS_DETAILED_GET: "storage:stats-detailed-get";
    readonly CACHE_BATCH_CLEAR: "storage:cache-batch-clear";
    readonly DATABASE_VACUUM: "storage:database-vacuum";
};
export type StorageIpcChannel = (typeof STORAGE_IPC_CHANNELS)[keyof typeof STORAGE_IPC_CHANNELS];
export type ChangelogCategory = "features" | "improvements" | "fixes";
export interface ChangelogItem {
    id: string;
    category: ChangelogCategory;
    titleKey?: string;
    rawTitle?: string;
    descriptionKey?: string;
    rawDescription?: string;
}
export interface VersionChangelog {
    version: string;
    releaseDate: string;
    items: ChangelogItem[];
    bannerGradient?: string;
    releaseUrl?: string;
}
export type WhatsNewModalMode = "view" | "ready_to_restart";
export interface WhatsNewModalOptions {
    version?: string;
    mode?: WhatsNewModalMode;
    changelogOverride?: string;
    onRestartApply?: () => void | Promise<void>;
}
export * from "./communication.js";
export * from "./desktop-capture.js";
export * from "./media-encryption.js";
export * from "./media-frame.js";
export type KeybindAction = "TOGGLE_MUTE" | "TOGGLE_DEAFEN" | "SCREEN_CAPTURE";
export interface KeybindConfig {
    id: KeybindAction;
    shortcut: string;
    enabled: boolean;
}
export type KeybindConflictType = "INTERNAL_CONFLICT" | "SYSTEM_OCCUPIED";
export interface KeybindConflictResult {
    conflict: boolean;
    type?: KeybindConflictType;
    conflictingAction?: KeybindAction;
    shortcut?: string;
}
export interface KeybindRegisterResponse {
    success: boolean;
    conflicts: Array<{
        id: KeybindAction;
        shortcut: string;
        reason: KeybindConflictType;
    }>;
}
export * from "./proxy.js";
export * from "./voice-routing.js";
export * from "./sticker.js";
//# sourceMappingURL=index.d.ts.map