"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BOT_MAX_CONTEXT_LIMIT = exports.USER_MENTION_TOKEN_REGEX_SOURCE = exports.TYPING_TIMEOUT_MS = exports.BOT_TYPING_INTERVAL_MS = exports.BOT_DEFAULT_CONTEXT_LIMIT = void 0;
exports.isUpdateIntegrationSettingsDTO = isUpdateIntegrationSettingsDTO;
exports.applyMessageUpdate = applyMessageUpdate;
exports.isContextLimit = isContextLimit;
exports.effectiveContextLimit = effectiveContextLimit;
exports.BOT_DEFAULT_CONTEXT_LIMIT = 5;
exports.BOT_TYPING_INTERVAL_MS = 3000;
exports.TYPING_TIMEOUT_MS = 7000;
exports.USER_MENTION_TOKEN_REGEX_SOURCE = "<@!?([A-Za-z0-9_-]{1,160})>";
exports.BOT_MAX_CONTEXT_LIMIT = 100;
function isUpdateIntegrationSettingsDTO(value) {
    if (!value || typeof value !== "object" || Array.isArray(value))
        return false;
    const dto = value;
    return (Object.keys(dto).length > 0 &&
        Object.keys(dto).every((key) => ["botsEnabled", "maxBotsPerGuild", "webhooksEnabled"].includes(key)) &&
        (dto.botsEnabled === undefined || typeof dto.botsEnabled === "boolean") &&
        (dto.webhooksEnabled === undefined ||
            typeof dto.webhooksEnabled === "boolean") &&
        (dto.maxBotsPerGuild === undefined ||
            (typeof dto.maxBotsPerGuild === "number" &&
                Number.isSafeInteger(dto.maxBotsPerGuild) &&
                dto.maxBotsPerGuild >= 1 &&
                dto.maxBotsPerGuild <= 100)));
}
function applyMessageUpdate(message, update) {
    if ((update.revision ?? message.revision ?? 0) < (message.revision ?? 0))
        return message;
    return {
        ...message,
        ...update,
        ...(update.content !== undefined && update.content !== message.content
            ? { rawContent: undefined }
            : {}),
    };
}
function isContextLimit(value) {
    return (Number.isSafeInteger(value) &&
        Number(value) >= 0 &&
        Number(value) <= exports.BOT_MAX_CONTEXT_LIMIT);
}
function effectiveContextLimit(application, channelId) {
    return (application.channelSettings.find((setting) => setting.channelId === channelId)?.contextLimit ?? application.defaultContextLimit);
}
//# sourceMappingURL=bot.js.map