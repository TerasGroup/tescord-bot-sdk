import type { Channel, Message, SupportedLocale } from "./index.js";
import type { MessageDeviceIdentity } from "./message-encryption.js";
import type { BotCommand } from "./interactions.js";
export declare const BOT_DEFAULT_CONTEXT_LIMIT = 5;
export declare const BOT_TYPING_INTERVAL_MS = 3000;
export declare const TYPING_TIMEOUT_MS = 7000;
export declare const USER_MENTION_TOKEN_REGEX_SOURCE = "<@!?([A-Za-z0-9_-]{1,160})>";
export declare const BOT_MAX_CONTEXT_LIMIT = 100;
export type BotLocalizations = Record<SupportedLocale, string>;
export interface BotIdentity {
    id: string;
    name: string;
    avatarUrl: string | null;
    createdAt?: string;
}
export interface BotMember {
    id: string;
    applicationId: string;
    guildId: string;
    nickname?: string | null;
    identity: BotIdentity;
    joinedAt: string;
}
export interface BotChannelSetting {
    channelId: string;
    contextLimit: number | null;
    respondToAll: boolean;
}
export interface BotApplication {
    id: string;
    identityId: string;
    userId: string;
    identity?: BotIdentity;
    guildId: string;
    ownerId?: string | null;
    createdById?: string | null;
    name: string;
    avatarUrl?: string | null;
    managedRoleId: string;
    defaultContextLimit: number;
    configVersion: number;
    device: MessageDeviceIdentity | null;
    channelSettings: BotChannelSetting[];
    commands?: BotCommand[];
    createdAt: string;
}
export interface CreateBotDTO {
    name: string;
    avatarUrl?: string | null;
    defaultContextLimit?: number;
}
export interface UpdateBotDTO {
    name?: string;
    avatarUrl?: string | null;
    defaultContextLimit?: number;
}
export interface BotTokenResponse {
    application: BotApplication;
    token: string;
}
export interface BotReadyPayload {
    sessionId: string;
    application: BotApplication;
    channels: Channel[];
    commands: BotCommand[];
}
export interface BotConfigUpdatePayload {
    application: BotApplication;
    channels: Channel[];
    commands: BotCommand[];
}
export interface BotIdentifyPayload {
    token: string;
    bot: true;
    deviceId: string;
}
export type ApiPrincipal = {
    kind: "user";
    userId: string;
    sessionId: string;
    sessionVersion: number;
} | {
    kind: "bot";
    botId?: string;
    userId: string;
    applicationId: string;
    guildId: string;
    tokenVersion: number;
};
export interface IntegrationSettings {
    botsEnabled: boolean;
    maxBotsPerGuild: number;
    webhooksEnabled: boolean;
}
export interface UpdateIntegrationSettingsDTO {
    botsEnabled?: boolean;
    maxBotsPerGuild?: number;
    webhooksEnabled?: boolean;
}
export declare function isUpdateIntegrationSettingsDTO(value: unknown): value is UpdateIntegrationSettingsDTO;
export interface AdminIntegrationStats {
    totalBots: number;
    activeBots: number;
    revokedBots: number;
    guildDistribution: {
        guildId: string;
        guildName: string;
        botCount: number;
    }[];
}
export interface AdminBotListItem {
    id: string;
    name: string;
    avatarUrl: string | null;
    guildId: string;
    guildName: string;
    createdById: string | null;
    createdByName: string | null;
    revokedAt: string | null;
    createdAt: string;
    commandCount: number;
}
export interface AdminBotListResponse {
    bots: AdminBotListItem[];
    total: number;
    page: number;
    pageSize: number;
}
export interface EditMessageDTO {
    content: string;
    isEncrypted: boolean;
    expectedRevision: number;
    components?: import("./interactions.js").MessageActionRow[];
}
export type MessageBodyUpdate = Message & {
    revision: number;
    editedAt: string;
};
export interface RegisterBotDeviceDTO extends Omit<MessageDeviceIdentity, "userId"> {
    proof: string;
}
export declare function applyMessageUpdate(message: Message, update: Partial<Message>): Message;
export declare function isContextLimit(value: unknown): value is number;
export declare function effectiveContextLimit(application: Pick<BotApplication, "defaultContextLimit" | "channelSettings">, channelId: string): number;
//# sourceMappingURL=bot.d.ts.map